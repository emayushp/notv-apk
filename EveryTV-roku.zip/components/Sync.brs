' Cross-device sync (render thread). The Backend task only does the HTTP call;
' everything that touches saved data happens here so nothing races.
'
' Record keys (same on phone, PC and Roku):
'   p|<personId>                              a person
'   f|<personId>|<sourceFp>|<TYPE>|<itemId>    My List entry
'   w|<personId>|<sourceFp>|<m|l|e>|<id>[|ep]  where you were

function canonItem(it as object) as object
    return { id: toStr(it.id), name: toStr(it.name), "type": toStr(it.ty), categoryId: toStr(it.cat), poster: it.poster, year: it.year, url: it.url, ext: it.ext, extra: it.extra, number: toInt(it.number, 0), epgId: it.epg }
end function

function rokuItem(it as object, fallbackTy as string) as object
    return { id: toStr(it.id), name: toStr(it.name), ty: orStr(it["type"], fallbackTy), cat: toStr(it.categoryId), poster: orStr(it.poster, ""), url: orStr(it.url, ""), ext: it.ext, extra: it.extra, year: it.year, number: toInt(it.number, 0), epg: it.epgId }
end function

function progToCanon(e as object) as object
    ep = invalid
    if isAA(e.ep) then ep = { id: toStr(e.ep.id), seriesId: toStr(e.it.id), season: toInt(e.ep.season, 1), episode: toInt(e.ep.episode, 1), title: toStr(e.ep.title), url: e.ep.url, ext: e.ep.ext, durationSecs: toInt(e.ep.dur, 0) }
    at = e.at
    if at = invalid then at = 0
    return { "type": toStr(e.ty), item: canonItem(e.it), episode: ep, positionMs: toInt(e.ps, 0) * 1000, durationMs: toInt(e.dur, 0) * 1000, updatedAt: at * 1000&, finished: isTrue(e.fin) }
end function

function canonToProg(localKey as string, scope as string, v as object) as dynamic
    if not isAA(v.item) then return invalid
    ty = orStr(v["type"], "MOVIE")
    e = { k: localKey, pid: scope, ty: ty, it: rokuItem(v.item, ty), ps: msToSec(v.positionMs), dur: msToSec(v.durationMs), at: msToSec(v.updatedAt), fin: isTrue(v.finished) }
    if isAA(v.episode) then
        o = { id: toStr(v.episode.id), season: toInt(v.episode.season, 1), episode: toInt(v.episode.episode, 1), title: Left(toStr(v.episode.title), 60), url: v.episode.url, dur: toInt(v.episode.durationSecs, 0) }
        if v.episode.ext <> invalid then o.ext = v.episode.ext
        e.ep = o
    end if
    return e
end function

' What to send: the queued keys, with their current values.
function buildOutgoing() as object
    q = getSyncQueue()
    changes = []
    sent = []
    if q.Count() = 0 then return { changes: changes, sent: sent }
    progByKey = {}
    for each e in getProgressList()
        progByKey[syncKeyForLocal(toStr(e.k))] = e
    end for
    favByKey = {}
    for each f in getFavs()
        t = Instr(1, toStr(f.pid), "~")
        if t > 0 then favByKey["f|" + Left(f.pid, t - 1) + "|" + Mid(f.pid, t + 1) + "|" + toStr(f.it.ty) + "|" + toStr(f.it.id)] = f
    end for
    people = {}
    for each p in getPeople()
        people["p|" + p.id] = p
    end for
    for each k in q
        rec = q[k]
        c = { k: k, ct: rec.ct, del: isTrue(rec.del) }
        if not c.del then
            v = invalid
            if startsWith(k, "w|") and progByKey[k] <> invalid then v = progToCanon(progByKey[k])
            if startsWith(k, "f|") and favByKey[k] <> invalid then
                at = favByKey[k].at
                if at = invalid then at = rec.ct
                v = { item: canonItem(favByKey[k].it), addedAt: at }
            end if
            if startsWith(k, "p|") and people[k] <> invalid then v = people[k]
            if v <> invalid then c.v = v
        end if
        if c.del or c.v <> invalid then changes.Push(c)
        sent.Push({ k: k, ct: rec.ct })
    end for
    return { changes: changes, sent: sent }
end function

sub clearSent(sent as object)
    q = getSyncQueue()
    for each s in sent
        if q[s.k] <> invalid and q[s.k].ct = s.ct then q.Delete(s.k)
    end for
    regSet("syncq", q)
end sub

' Put every local record in the queue (used when joining a household).
sub queueAll()
    if toStr(getSettings().syncCode) = "" then return
    q = {}
    t = nowMs()
    for each p in getPeople()
        q["p|" + p.id] = { ct: toLong(p.updatedAt, t), del: false }
    end for
    n = 0
    for each e in getProgressList()
        k = syncKeyForLocal(toStr(e.k))
        if k <> "" and n < 40 then
            at = e.at
            if at = invalid then at = 0
            q[k] = { ct: at * 1000&, del: false }
            n = n + 1
        end if
    end for
    for each f in getFavs()
        tt = Instr(1, toStr(f.pid), "~")
        if tt > 0 then q["f|" + Left(f.pid, tt - 1) + "|" + Mid(f.pid, tt + 1) + "|" + toStr(f.it.ty) + "|" + toStr(f.it.id)] = { ct: t, del: false }
    end for
    regSet("syncq", q)
end sub

function toLong(v as dynamic, fallback as dynamic) as dynamic
    if v = invalid then return fallback
    return v
end function

' Write other devices' changes into the registry (newest wins). Returns true if anything changed.
function applySync(changes as object) as boolean
    if not isArray(changes) or changes.Count() = 0 then return false
    q = getSyncQueue()
    people = {}
    for each p in getPeople()
        people[p.id] = p
    end for
    favs = getFavs()
    prog = getProgressList()
    removedPeople = false
    any = false
    for each c in changes
        k = toStr(c.k)
        pend = q[k]
        skip = false
        if pend <> invalid and c.ct <> invalid and pend.ct > c.ct then skip = true
        parts = k.Split("|")
        if not skip and parts.Count() >= 2 then
            if parts[0] = "p" then
                if isTrue(c.del) then
                    people.Delete(parts[1])
                    removedPeople = true
                else if isAA(c.v) and c.v.id <> invalid then
                    people[c.v.id] = c.v
                end if
                any = true
            else if parts[0] = "f" and parts.Count() >= 5 then
                scope = parts[1] + "~" + parts[2]
                out = []
                for each f in favs
                    if not (f.pid = scope and toStr(f.it.id) = parts[4] and toStr(f.it.ty) = parts[3]) then out.Push(f)
                end for
                if not isTrue(c.del) and isAA(c.v) and isAA(c.v.item) then
                    out.Unshift({ pid: scope, it: rokuItem(c.v.item, parts[3]), at: c.v.addedAt })
                end if
                favs = out
                any = true
            else if parts[0] = "w" and parts.Count() >= 5 then
                scope = parts[1] + "~" + parts[2]
                tail = parts[3]
                for i = 4 to parts.Count() - 1
                    tail = tail + "|" + parts[i]
                end for
                localKey = scope + "|" + tail
                existing = invalid
                out = []
                for each e in prog
                    if toStr(e.k) = localKey then
                        existing = e
                    else
                        out.Push(e)
                    end if
                end for
                if isTrue(c.del) then
                    prog = out
                    any = true
                else if isAA(c.v) then
                    e = canonToProg(localKey, scope, c.v)
                    if e <> invalid and (existing = invalid or existing.at = invalid or e.at >= existing.at) then
                        out.Push(e)
                        prog = out
                        any = true
                    end if
                end if
            end if
        end if
    end for
    if not any then return false
    pl = []
    for each id in people
        pl.Push(people[id])
    end for
    regSet("people", pl)
    if removedPeople then
        for each e in prog
            if Instr(1, toStr(e.pid), "~") > 0 and people[e.pid.Split("~")[0]] = invalid then e.gone = true
        end for
    end if
    keep = []
    for each e in prog
        if not isTrue(e.gone) then keep.Push(e)
    end for
    keep.SortBy("at", "r")
    saveProgressList(keep)
    saveFavList(favs)
    cur = toStr(getSettings().person)
    if cur <> "" and people[cur] = invalid then patchSettings({ person: "" })
    return true
end function
