sub init()
    m.top.functionName = "runLoop"
end sub

sub runLoop()
    port = CreateObject("roMessagePort")
    m.top.observeField("request", port)
    m.prov = invalid
    m.pid = ""
    m.cacheDays = 7
    m.lastKeepAlive = nowSec()
    while true
        msg = wait(30000, port)
        if msg = invalid then
            keepAlive()
        else if type(msg) = "roSGNodeEvent" and msg.getField() = "request" then
            req = msg.getData()
            if isAA(req) and req.cmd <> invalid then
                res = invalid
                res = handle(req.cmd, req.args)
                if not isAA(res) then res = { error: "Unexpected error" }
                res.id = req.id
                res.cmd = req.cmd
                res.ok = (res.error = invalid)
                m.top.response = res
            end if
        end if
    end while
end sub

sub keepAlive()
    if m.prov = invalid or m.prov.kind <> "STALKER" or m.prov.endpoint = "" then return
    if nowSec() - m.lastKeepAlive < 110 then return
    m.lastKeepAlive = nowSec()
    stalkerCall(m.prov, "type=watchdog&action=get_events&cur_play_type=1&event_active_id=0&init=0")
end sub

function ttl() as integer
    return m.cacheDays * 86400
end function

function handle(cmd as string, args as dynamic) as object
    if args = invalid then args = {}
    if cmd = "connect" then return doConnect(args)
    if m.prov = invalid then return { error: "Not connected" }
    if cmd = "cats" then return doCats(args.ty, isTrue(args.hideAdult))
    if cmd = "items" then return doItems(args.ty, args.cat, args.page, isTrue(args.force))
    if cmd = "home" then return doHome(args)
    if cmd = "search" then return doSearch(args.q)
    if cmd = "details" then return doDetails(args.item)
    if cmd = "series" then return doSeries(args.item)
    if cmd = "resolve" then return doResolve(args.item, args.ep)
    if cmd = "epg" then return doEpg(args.item)
    if cmd = "account" then return doAccount()
    if cmd = "refresh" then
        cacheClearAll()
        if m.prov.kind = "STALKER" then
            m.prov.channels = invalid
            m.prov.vodCats = invalid
        else if m.prov.kind = "XTREAM" then
            m.prov.all = {}
        end if
        return {}
    end if
    return { error: "Unknown command " + cmd }
end function

function doConnect(args as object) as object
    p = args.profile
    if args.cacheDays <> invalid then m.cacheDays = args.cacheDays
    if not isAA(p) then return { error: "No source" }
    kind = orStr(sv(p, "type"), "STALKER")
    if kind = "XTREAM" then
        s = xtreamNew(p)
        e = xtreamConnect(s)
    else if kind = "M3U" then
        s = m3uNew(p)
        e = m3uConnect(s)
    else
        s = stalkerNew(p)
        e = stalkerConnect(s)
    end if
    if e <> "" then return { error: e }
    m.prov = s
    m.pid = orStr(sv(p, "id"), "p")
    m.lastKeepAlive = nowSec()
    return {}
end function

function doAccount() as object
    a = invalid
    if m.prov.kind = "STALKER" then a = stalkerAccount(m.prov)
    if m.prov.kind = "XTREAM" then a = xtreamAccount(m.prov)
    if a = invalid then return { data: {} }
    return { data: a }
end function

' ----- categories & items (cached on disk) -----

function getCats(ty as string) as object
    key = m.pid + "|cats|" + ty
    if m.prov.kind <> "M3U" then
        c = cacheGet(key, ttl())
        if c <> invalid then return { list: c }
    end if
    if m.prov.kind = "STALKER" then
        r = stalkerCategories(m.prov, ty)
    else if m.prov.kind = "XTREAM" then
        r = xtreamCategories(m.prov, ty)
    else
        r = m3uCategories(m.prov, ty)
    end if
    if r.err <> invalid then return r
    if m.prov.kind <> "M3U" then cachePut(key, r.list)
    return r
end function

function doCats(ty as string, hideAdult as boolean) as object
    r = getCats(ty)
    if r.err <> invalid then return { error: r.err }
    out = []
    for each c in r.list
        if not hideAdult or not isAdultName(c.name) then out.Push(c)
    end for
    return { data: out }
end function

function getItems(ty as string, cat as string, page as integer, force as boolean) as object
    key = m.pid + "|items|" + ty + "|" + cat + "|" + page.ToStr()
    if m.prov.kind <> "M3U" and not force then
        c = cacheGet(key, ttl())
        if c <> invalid then return c
    end if
    if m.prov.kind = "STALKER" then
        if ty = "LIVE" and m.prov.channels = invalid and not force then
            ch = cacheGet(m.pid + "|channels", ttl())
            if ch <> invalid then m.prov.channels = ch
        end if
        if force and ty = "LIVE" then m.prov.channels = invalid
        hadChannels = m.prov.channels <> invalid
        r = stalkerItems(m.prov, ty, cat, page)
        if ty = "LIVE" and not hadChannels and m.prov.channels <> invalid then cachePut(m.pid + "|channels", m.prov.channels)
    else if m.prov.kind = "XTREAM" then
        r = xtreamItems(m.prov, ty, cat, page)
    else
        r = m3uItems(m.prov, ty, cat, page)
    end if
    if r.err <> invalid then return r
    out = { list: r.list, hasMore: isTrue(r.hasMore) }
    if m.prov.kind <> "M3U" then cachePut(key, out)
    return out
end function

function itemNode(it as object) as object
    n = CreateObject("roSGNode", "ContentNode")
    n.title = it.name
    n.HDPosterUrl = it.poster
    n.FHDPosterUrl = it.poster
    n.description = it.plot
    n.addFields({ item: it })
    return n
end function

function listNode(list as object, limit = 100000 as integer) as object
    root = CreateObject("roSGNode", "ContentNode")
    n = 0
    for each it in list
        root.appendChild(itemNode(it))
        n = n + 1
        if n >= limit then exit for
    end for
    return root
end function

function doItems(ty as string, cat as string, page as dynamic, force as boolean) as object
    pg = 1
    if page <> invalid then pg = page
    r = getItems(ty, cat, pg, force)
    if r.err <> invalid then return { error: r.err }
    return { node: listNode(r.list), hasMore: r.hasMore, count: r.list.Count() }
end function

' ----- home rows: categories you actually watch first -----

function doHome(args as object) as object
    scores = args.scores
    if not isAA(scores) then scores = {}
    hideAdult = isTrue(args.hideAdult)
    labels = { MOVIE: "Movies", SERIES: "Series", LIVE: "Live TV" }
    root = CreateObject("roSGNode", "ContentNode")
    rowTypes = []
    for each ty in ["MOVIE", "SERIES", "LIVE"]
        r = getCats(ty)
        if r.err = invalid and r.list.Count() > 0 then
            scored = []
            rest = []
            for each c in r.list
                if not hideAdult or not isAdultName(c.name) then
                    sc = scores[ty + "|" + c.id]
                    if sc <> invalid and sc > 0 then
                        c.score = sc
                        scored.Push(c)
                    else
                        rest.Push(c)
                    end if
                end if
            end for
            scored.SortBy("score", "r")
            picks = []
            for each c in scored
                if picks.Count() < 3 then picks.Push(c)
            end for
            if picks.Count() = 0 then
                for each c in rest
                    if picks.Count() < 2 then picks.Push(c)
                end for
            end if
            for each c in picks
                it = getItems(ty, c.id, 1, false)
                if it.err = invalid and it.list.Count() > 0 then
                    row = listNode(it.list, 24)
                    if c.score <> invalid then
                        row.title = "Because you watch " + c.name
                    else
                        row.title = labels[ty] + ": " + c.name
                    end if
                    root.appendChild(row)
                    rowTypes.Push(ty)
                end if
            end for
        end if
    end for
    return { node: root, rowTypes: rowTypes }
end function

function doSearch(q as dynamic) as object
    if q = invalid or q.Trim() = "" then return { node: CreateObject("roSGNode", "ContentNode"), count: 0 }
    if m.prov.kind = "STALKER" then
        if m.prov.channels = invalid then
            ch = cacheGet(m.pid + "|channels", ttl())
            if ch <> invalid then m.prov.channels = ch
        end if
        r = stalkerSearch(m.prov, q)
    else if m.prov.kind = "XTREAM" then
        r = xtreamSearch(m.prov, q)
    else
        r = m3uSearch(m.prov, q)
    end if
    return { node: listNode(r.list, 150), count: r.list.Count() }
end function

function doDetails(it as object) as object
    if m.prov.kind = "XTREAM" and it.ty = "MOVIE" then return { data: xtreamMovie(m.prov, it) }
    return { data: it }
end function

function doSeries(it as object) as object
    if m.prov.kind = "STALKER" then
        r = stalkerSeries(m.prov, it)
    else if m.prov.kind = "XTREAM" then
        r = xtreamSeries(m.prov, it)
    else
        r = m3uSeries(m.prov, it)
    end if
    if r.err <> invalid then return { error: r.err }
    eps = r.eps
    eps.SortBy("episode")
    eps.SortBy("season")
    out = { eps: eps }
    if r.item <> invalid then out.item = r.item
    return out
end function

function doResolve(it as object, ep as dynamic) as object
    if m.prov.kind = "STALKER" then
        r = stalkerResolve(m.prov, it, ep)
        headers = ["User-Agent: " + m.prov.ua]
    else if m.prov.kind = "XTREAM" then
        r = xtreamResolve(m.prov, it, ep)
        headers = []
        if m.prov.ua <> "" then headers.Push("User-Agent: " + m.prov.ua)
    else
        r = m3uResolve(m.prov, it, ep)
        headers = []
        if m.prov.ua <> "" then headers.Push("User-Agent: " + m.prov.ua)
    end if
    if r.err <> invalid then return { error: r.err }
    return { url: r.url, headers: headers }
end function

function doEpg(it as object) as object
    if m.prov.kind = "STALKER" then return { data: stalkerEpg(m.prov, it) }
    if m.prov.kind = "XTREAM" then return { data: xtreamEpg(m.prov, it) }
    return { data: [] }
end function
