' HTTP + disk cache (task thread only).

function httpGet(url as string, headers as object, timeoutMs = 15000 as integer) as object
    x = CreateObject("roUrlTransfer")
    p = CreateObject("roMessagePort")
    x.SetMessagePort(p)
    x.SetUrl(url)
    x.SetCertificatesFile("common:/certs/ca-bundle.crt")
    x.InitClientCertificates()
    x.EnableEncodings(true)
    x.RetainBodyOnError(true)
    if headers <> invalid then
        for each k in headers
            x.AddHeader(k, headers[k])
        end for
    end if
    if not x.AsyncGetToString() then return { ok: false, code: 0, body: "", error: "could not start request" }
    msg = wait(timeoutMs, p)
    if msg = invalid then
        x.AsyncCancel()
        return { ok: false, code: 0, body: "", error: "timed out" }
    end if
    if type(msg) <> "roUrlEvent" then return { ok: false, code: 0, body: "", error: "no response" }
    code = msg.GetResponseCode()
    body = msg.GetString()
    if body = invalid then body = ""
    reason = msg.GetFailureReason()
    if reason = invalid then reason = ""
    return { ok: (code >= 200 and code < 300), code: code, body: body, error: reason }
end function

function httpErrorText(r as object) as string
    if r.code > 0 then return "HTTP " + r.code.ToStr()
    if r.error <> "" then return r.error
    return "network error"
end function

' ----- disk cache (cachefs: survives restarts unless the Roku needs the space) -----

function cachePath(key as string) as string
    return "cachefs:/etv_" + md5Hex(key) + ".json"
end function

function cacheGet(key as string, maxAgeSec as integer) as dynamic
    path = cachePath(key)
    fs = CreateObject("roFileSystem")
    if not fs.Exists(path) then return invalid
    txt = ReadAsciiFile(path)
    if txt = "" then return invalid
    rec = ParseJson(txt)
    if rec = invalid or rec.t = invalid then return invalid
    if nowSec() - rec.t > maxAgeSec then return invalid
    return rec.d
end function

sub cachePut(key as string, data as dynamic)
    WriteAsciiFile(cachePath(key), FormatJson({ t: nowSec(), d: data }))
end sub

sub cacheClearAll()
    fs = CreateObject("roFileSystem")
    for each f in fs.GetDirectoryListing("cachefs:/")
        if startsWith(f, "etv_") then fs.Delete("cachefs:/" + f)
    end for
end sub
