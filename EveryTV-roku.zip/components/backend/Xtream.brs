' Xtream Codes client.

function xtreamNew(p as object) as object
    u = stripTrailingSlashes(orStr(sv(p, "url"), ""))
    user = orStr(sv(p, "username"), "")
    pass = orStr(sv(p, "password"), "")
    q = Instr(1, u, "?")
    if q > 0 then
        for each kv in Mid(u, q + 1).Split("&")
            eq = Instr(1, kv, "=")
            if eq > 0 then
                k = LCase(Left(kv, eq - 1))
                v = Mid(kv, eq + 1).DecodeUriComponent()
                if k = "username" and user = "" then user = v
                if k = "password" and pass = "" then pass = v
            end if
        end for
        u = Left(u, q - 1)
    end if
    for each tail in ["/get.php", "/player_api.php", "/xmltv.php"]
        if endsWith(u, tail) then u = Left(u, Len(u) - Len(tail))
    end for
    u = stripTrailingSlashes(u)
    if not startsWith(LCase(u), "http") then u = "http://" + u
    ua = orStr(sv(p, "userAgent"), "")
    return { kind: "XTREAM", profile: p, base: u, user: user, pass: pass, ua: ua, api: u + "/player_api.php?username=" + enc(user) + "&password=" + enc(pass), info: invalid, all: {} }
end function

function xtreamHeaders(s as object) as object
    h = {}
    if s.ua <> "" then h["User-Agent"] = s.ua
    return h
end function

function xtreamCall(s as object, params as string) as object
    url = s.api
    if params <> "" then url = url + "&" + params
    r = httpGet(url, xtreamHeaders(s), 30000)
    if r.code = 401 or r.code = 403 then return { err: "Login rejected by the server (HTTP " + r.code.ToStr() + "). Check username and password." }
    if not r.ok then return { err: "Couldn't reach the Xtream server: " + httpErrorText(r) }
    return { js: parseJsonLoose(r.body) }
end function

function xtreamConnect(s as object) as string
    if s.user = "" or s.pass = "" then return "Username and password are required for Xtream Codes."
    r = xtreamCall(s, "")
    if r.err <> invalid then return r.err
    if not isAA(r.js) then return "The server did not return valid Xtream data. Check the server URL."
    ui = r.js.user_info
    if not isAA(ui) then return "Server did not return account info. Check the URL."
    if sv(ui, "auth") = "0" then return "Wrong username or password."
    st = sv(ui, "status")
    if st <> invalid and LCase(st) <> "active" then return "Account status: " + st
    s.info = ui
    return ""
end function

function xtreamAccount(s as object) as dynamic
    ui = s.info
    if ui = invalid then return invalid
    expStr = "Unlimited"
    e = toInt(sv(ui, "exp_date"), 0)
    if e > 0 then
        d = CreateObject("roDateTime")
        d.FromSeconds(e)
        expStr = d.AsDateString("short-month-no-weekday")
    end if
    return { status: orStr(sv(ui, "status"), ""), expires: expStr, extra: orStr(sv(ui, "active_cons"), "0") + " / " + orStr(sv(ui, "max_connections"), "?") + " connections" }
end function

function xtreamCategories(s as object, ty as string) as object
    action = "get_live_categories"
    if ty = "MOVIE" then action = "get_vod_categories"
    if ty = "SERIES" then action = "get_series_categories"
    r = xtreamCall(s, "action=" + action)
    if r.err <> invalid then return r
    out = []
    if isArray(r.js) then
        for each o in r.js
            id = sv(o, "category_id")
            if id <> invalid then out.Push({ id: id, name: orStr(sv(o, "category_name"), "Category"), ty: ty })
        end for
    end if
    return { list: out }
end function

function xtreamBackdrop(o as dynamic) as string
    if not isAA(o) then return ""
    bp = o.backdrop_path
    if isArray(bp) then
        for each x in bp
            if (type(x) = "String" or type(x) = "roString") and startsWith(x, "http") then return x
        end for
    else if (type(bp) = "String" or type(bp) = "roString") and startsWith(bp, "http") then
        return bp
    end if
    return ""
end function

function xtreamFetch(s as object, ty as string, cat as dynamic) as object
    action = "get_live_streams"
    if ty = "MOVIE" then action = "get_vod_streams"
    if ty = "SERIES" then action = "get_series"
    params = "action=" + action
    if cat <> invalid then params = params + "&category_id=" + enc(cat)
    r = xtreamCall(s, params)
    if r.err <> invalid then return r
    out = []
    if not isArray(r.js) then return { list: out }
    for each o in r.js
        if ty = "SERIES" then
            id = sv(o, "series_id")
        else
            id = sv(o, "stream_id")
        end if
        if id <> invalid then
            it = newItem(id, orStr(sv(o, "name"), id), ty)
            it.cat = orStr(sv(o, "category_id"), "")
            rating = sv(o, "rating")
            if rating <> invalid and rating <> "0" then it.rating = rating
            if ty = "LIVE" then
                it.poster = orStr(sv(o, "stream_icon"), "")
                it.number = toInt(sv(o, "num"), 0)
                it.epg = orStr(sv(o, "epg_channel_id"), "")
            else if ty = "MOVIE" then
                it.poster = orStr(sv(o, "stream_icon"), "")
                it.ext = orStr(sv(o, "container_extension"), "mp4")
                it.year = orStr(sv(o, "year"), "")
                it.plot = orStr(sv(o, "plot"), "")
            else
                it.poster = orStr(sv(o, "cover"), "")
                it.plot = orStr(sv(o, "plot"), "")
                it.genre = orStr(sv(o, "genre"), "")
                it.cast = orStr(sv(o, "cast"), "")
                it.year = Left(orStr(firstStr(o, ["year", "releaseDate", "release_date"]), ""), 4)
            end if
            out.Push(it)
        end if
    end for
    return { list: out }
end function

function xtreamItems(s as object, ty as string, cat as string, page as integer) as object
    if page > 1 then return { list: [], hasMore: false }
    r = xtreamFetch(s, ty, cat)
    if r.err <> invalid then return r
    return { list: r.list, hasMore: false }
end function

function xtreamAll(s as object, ty as string) as object
    if s.all[ty] = invalid then
        r = xtreamFetch(s, ty, invalid)
        if r.err <> invalid then return []
        s.all[ty] = r.list
    end if
    return s.all[ty]
end function

function xtreamSearch(s as object, q as string) as object
    out = []
    for each ty in ["MOVIE", "SERIES", "LIVE"]
        n = 0
        for each it in xtreamAll(s, ty)
            if searchMatch(it.name, q) then
                out.Push(it)
                n = n + 1
                if n >= 80 then exit for
            end if
        end for
    end for
    return { list: out }
end function

function xtreamMovie(s as object, it as object) as object
    r = xtreamCall(s, "action=get_vod_info&vod_id=" + enc(it.id))
    if r.err <> invalid or not isAA(r.js) or not isAA(r.js.info) then return it
    info = r.js.info
    setIf(it, "plot", firstStr(info, ["plot", "description"]))
    b = xtreamBackdrop(info)
    if b <> "" then it.backdrop = b
    setIf(it, "cast", firstStr(info, ["cast", "actors"]))
    setIf(it, "director", sv(info, "director"))
    setIf(it, "genre", sv(info, "genre"))
    y = firstStr(info, ["releasedate", "release_date", "year"])
    if y <> invalid then it.year = Left(y, 4)
    setIf(it, "duration", sv(info, "duration"))
    rating = sv(info, "rating")
    if rating <> invalid and rating <> "0" then it.rating = rating
    if isAA(r.js.movie_data) then setIf(it, "ext", sv(r.js.movie_data, "container_extension"))
    return it
end function

function xtreamSeries(s as object, it as object) as object
    r = xtreamCall(s, "action=get_series_info&series_id=" + enc(it.id))
    if r.err <> invalid then return r
    if not isAA(r.js) then return { err: "Couldn't load episodes." }
    info = r.js.info
    if isAA(info) then
        setIf(it, "plot", sv(info, "plot"))
        b = xtreamBackdrop(info)
        if b <> "" then it.backdrop = b
        setIf(it, "cast", sv(info, "cast"))
        setIf(it, "genre", sv(info, "genre"))
    end if
    covers = {}
    if isArray(r.js.seasons) then
        for each sn in r.js.seasons
            c = firstStr(sn, ["cover_big", "cover"])
            n = sv(sn, "season_number")
            if c <> invalid and n <> invalid then covers[n] = c
        end for
    end if
    eps = []
    e = r.js.episodes
    if isAA(e) then
        for each k in e
            if isArray(e[k]) then
                for each o in e[k]
                    xtreamAddEp(eps, o, toInt(k, 1), covers)
                end for
            end if
        end for
    else if isArray(e) then
        for each x in e
            if isArray(x) then
                for each o in x
                    xtreamAddEp(eps, o, 1, covers)
                end for
            else if isAA(x) then
                xtreamAddEp(eps, x, 1, covers)
            end if
        end for
    end if
    return { eps: eps, item: it }
end function

sub xtreamAddEp(eps as object, o as dynamic, seasonKey as integer, covers as object)
    id = sv(o, "id")
    if id = invalid then return
    season = toInt(sv(o, "season"), seasonKey)
    num = toInt(sv(o, "episode_num"), eps.Count() + 1)
    e = newEp(id, season, num, orStr(sv(o, "title"), "Episode"), "")
    inf = o.info
    if isAA(inf) then
        e.plot = orStr(firstStr(inf, ["plot", "description"]), "")
        e.image = orStr(sv(inf, "movie_image"), "")
        e.dur = toInt(sv(inf, "duration_secs"), 0)
    end if
    if e.image = "" and covers[season.ToStr()] <> invalid then e.image = covers[season.ToStr()]
    e.ext = orStr(sv(o, "container_extension"), "mp4")
    eps.Push(e)
end sub

function xtreamResolve(s as object, it as object, ep as dynamic) as object
    u = enc(s.user)
    p = enc(s.pass)
    if ep <> invalid then return { url: s.base + "/series/" + u + "/" + p + "/" + ep.id + "." + orStr(sv(ep, "ext"), "mp4") }
    if it.ty = "MOVIE" then
        ext = it.ext
        if ext = "" then ext = "mp4"
        return { url: s.base + "/movie/" + u + "/" + p + "/" + it.id + "." + ext }
    end if
    return { url: s.base + "/live/" + u + "/" + p + "/" + it.id + ".m3u8" }
end function

function xtreamEpg(s as object, ch as object) as object
    out = []
    r = xtreamCall(s, "action=get_short_epg&stream_id=" + enc(ch.id) + "&limit=6")
    if r.err <> invalid or not isAA(r.js) or not isArray(r.js.epg_listings) then return out
    now = nowSec()
    for each o in r.js.epg_listings
        a = toInt(sv(o, "start_timestamp"), -1)
        b = toInt(sv(o, "stop_timestamp"), -1)
        if a > 0 and b > now then out.Push({ title: b64decode(sv(o, "title")), start: a, endt: b, desc: b64decode(sv(o, "description")) })
    end for
    out.SortBy("start")
    return out
end function
