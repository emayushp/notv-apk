' Shared helpers (safe on any thread).

function toStr(v as dynamic) as string
    t = type(v)
    if t = "String" or t = "roString" then return v
    if t = "Integer" or t = "roInt" or t = "roInteger" or t = "LongInteger" or t = "roLongInteger" then return v.ToStr()
    if t = "Float" or t = "roFloat" or t = "Double" or t = "roDouble" then
        if v = Int(v) and Abs(v) < 2000000000 then return Int(v).ToStr()
        return Str(v).Trim()
    end if
    if t = "Boolean" or t = "roBoolean" then
        if v then return "true"
        return "false"
    end if
    return ""
end function

' Trimmed string value of o[key], or invalid when missing/empty/"null".
function sv(o as dynamic, key as string) as dynamic
    if type(o) <> "roAssociativeArray" then return invalid
    v = o[key]
    if v = invalid then return invalid
    s = toStr(v).Trim()
    if s = "" or s = "null" then return invalid
    return s
end function

function firstStr(o as dynamic, keys as object) as dynamic
    for each k in keys
        v = sv(o, k)
        if v <> invalid then return v
    end for
    return invalid
end function

function orStr(v as dynamic, fallback as string) as string
    if v = invalid then return fallback
    return v
end function

function toInt(v as dynamic, fallback as integer) as integer
    if v = invalid then return fallback
    s = toStr(v).Trim()
    if s = "" then return fallback
    re = CreateObject("roRegex", "^-?[0-9]+", "")
    m = re.Match(s)
    if m.Count() = 0 then return fallback
    return m[0].ToInt()
end function

' First number found inside a string ("Season 3" -> 3)
function numberIn(s as dynamic) as dynamic
    if s = invalid then return invalid
    re = CreateObject("roRegex", "([0-9]+)", "")
    m = re.Match(s)
    if m.Count() < 2 then return invalid
    return m[1].ToInt()
end function

function enc(s as dynamic) as string
    if s = invalid then return ""
    return toStr(s).EncodeUriComponent()
end function

function nowSec() as integer
    return CreateObject("roDateTime").AsSeconds()
end function

function md5Hex(s as string) as string
    ba = CreateObject("roByteArray")
    ba.FromAsciiString(s)
    d = CreateObject("roEVPDigest")
    d.Setup("md5")
    return LCase(d.Process(ba))
end function

function sha256Hex(s as string) as string
    ba = CreateObject("roByteArray")
    ba.FromAsciiString(s)
    d = CreateObject("roEVPDigest")
    d.Setup("sha256")
    return LCase(d.Process(ba))
end function

function isArray(v as dynamic) as boolean
    return type(v) = "roArray"
end function

function isAA(v as dynamic) as boolean
    return type(v) = "roAssociativeArray"
end function

' Parses JSON; also copes with junk around the object (some portals wrap it).
function parseJsonLoose(body as string) as dynamic
    t = body.Trim()
    if t = "" then return invalid
    c = Left(t, 1)
    if c = "{" or c = "[" then
        v = ParseJson(t)
        if v <> invalid then return v
    end if
    i = Instr(1, t, "{")
    j = 0
    k = Instr(1, t, "}")
    while k > 0
        j = k
        k = Instr(k + 1, t, "}")
    end while
    if i > 0 and j > i then return ParseJson(Mid(t, i, j - i + 1))
    return invalid
end function

function isAdultName(n as dynamic) as boolean
    if n = invalid then return false
    re = CreateObject("roRegex", "(adult|xxx|18\+|\+18|porn|for adults|erotic|\bsex\b)", "i")
    return re.IsMatch(n)
end function

function isSeriesCategoryName(n as dynamic) as boolean
    if n = invalid then return false
    s = CreateObject("roRegex", "(\bseries\b|\bserials?\b|web ?series|tv ?shows?|\bshows?\b|\bdramas?\b|\bseasons?\b|\bepisodes?\b|\bnovelas?\b|\bsitcoms?\b|\bdizi\b|\bserie\b|\bkdrama|\banime\b|\bcartoons?\b)", "i")
    if not s.IsMatch(n) then return false
    notS = CreateObject("roRegex", "(stage ?shows?|award ?shows?|movies?|films?|cinema)", "i")
    keep = CreateObject("roRegex", "(series|drama|serial|season)", "i")
    if notS.IsMatch(n) and not keep.IsMatch(n) then return false
    return true
end function

function searchMatch(name as dynamic, q as string) as boolean
    if name = invalid then return false
    n = LCase(name)
    parts = LCase(q).Split(" ")
    found = false
    for each p in parts
        if p <> "" then
            if Instr(1, n, p) = 0 then return false
            found = true
        end if
    end for
    return found
end function

function newItem(id as string, name as string, ty as string) as object
    return { id: id, name: name, ty: ty, cat: "", poster: "", plot: "", year: "", rating: "", genre: "", cast: "", director: "", duration: "", url: "", ext: "", extra: "", number: 0, epg: "" }
end function

function setIf(o as object, key as string, v as dynamic)
    if v <> invalid then o[key] = v
end function

function normalizeMac(mac as dynamic) as string
    if mac = invalid then return ""
    u = UCase(toStr(mac)).Trim()
    re = CreateObject("roRegex", "[^0-9A-F]", "")
    hex = re.ReplaceAll(u, "")
    if Len(hex) <> 12 then return u
    out = ""
    for i = 0 to 10 step 2
        if out <> "" then out = out + ":"
        out = out + Mid(hex, i + 1, 2)
    end for
    return out
end function

function hostRoot(u as string) as string
    re = CreateObject("roRegex", "^(https?://[^/]+)", "i")
    m = re.Match(u)
    if m.Count() > 1 then return m[1]
    return u
end function

function startsWith(s as string, prefix as string) as boolean
    return Left(s, Len(prefix)) = prefix
end function

function endsWith(s as string, suffix as string) as boolean
    if Len(suffix) > Len(s) then return false
    return Right(s, Len(suffix)) = suffix
end function

function stripTrailingSlashes(s as string) as string
    while Len(s) > 0 and Right(s, 1) = "/"
        s = Left(s, Len(s) - 1)
    end while
    return s
end function

function b64decode(s as dynamic) as string
    if s = invalid or s = "" then return ""
    ba = CreateObject("roByteArray")
    ba.FromBase64String(s)
    out = ba.ToAsciiString()
    if out = "" then return s
    return out
end function

' True only for a real boolean true (safe when the value is missing).
function isTrue(v as dynamic) as boolean
    t = type(v)
    if t = "Boolean" or t = "roBoolean" then return v
    return false
end function
