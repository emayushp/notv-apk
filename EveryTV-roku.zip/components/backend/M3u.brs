' M3U playlist client.

function m3uNew(p as object) as object
    return { kind: "M3U", profile: p, ua: orStr(sv(p, "userAgent"), ""), items: [], cats: {}, eps: {} }
end function

function m3uConnect(s as object) as string
    url = orStr(sv(s.profile, "url"), "")
    if not startsWith(LCase(url), "http") then return "Playlist URL must start with http:// or https://"
    h = {}
    if s.ua <> "" then h["User-Agent"] = s.ua
    r = httpGet(url, h, 60000)
    if not r.ok then return "Couldn't load the playlist: " + httpErrorText(r)
    m3uParse(s, r.body)
    if s.items.Count() = 0 then return "The playlist loaded but contains no channels."
    return ""
end function

function m3uAttrs(line as string) as object
    a = {}
    re = CreateObject("roRegex", "([a-zA-Z0-9_-]+)=" + Chr(34) + "([^" + Chr(34) + "]*)" + Chr(34), "")
    for each m in re.MatchAll(line)
        a[LCase(m[1])] = m[2]
    end for
    return a
end function

function m3uClassify(url as string, group as string, name as string, seRe as object) as string
    u = LCase(url)
    if Instr(1, u, "/series/") > 0 then return "SERIES"
    if Instr(1, u, "/movie/") > 0 or Instr(1, u, "/movies/") > 0 then return "MOVIE"
    g = LCase(group)
    path = u
    q = Instr(1, path, "?")
    if q > 0 then path = Left(path, q - 1)
    vodExt = endsWith(path, ".mp4") or endsWith(path, ".mkv") or endsWith(path, ".avi")
    if CreateObject("roRegex", "\b(series|shows|tv shows|serie)\b", "").IsMatch(g) then return "SERIES"
    if CreateObject("roRegex", "\b(vod|movie|movies|film|films|cinema)\b", "").IsMatch(g) or vodExt then
        if seRe.IsMatch(name) then return "SERIES"
        return "MOVIE"
    end if
    return "LIVE"
end function

sub m3uParse(s as object, text as string)
    seRe = CreateObject("roRegex", "^(.*?)[\s._\-|:]*\(?S(\d{1,2})\s*[ ._-]?\s*E(\d{1,4})\)?(.*)$", "i")
    items = []
    cats = {}
    eps = {}
    seriesSeen = {}
    name = invalid
    attrs = {}
    group = invalid
    counter = 0
    lines = text.Split(Chr(10))
    for each raw in lines
        line = raw.Trim()
        if line = "" then
            ' skip
        else if startsWith(line, "#EXTINF") then
            inQ = false
            idx = 0
            for i = 1 to Len(line)
                c = Mid(line, i, 1)
                if c = Chr(34) then
                    inQ = not inQ
                else if c = "," and not inQ then
                    idx = i
                    exit for
                end if
            end for
            if idx > 0 then
                name = Mid(line, idx + 1).Trim()
                attrs = m3uAttrs(Left(line, idx))
            else
                name = ""
                attrs = m3uAttrs(line)
            end if
        else if startsWith(line, "#EXTGRP:") then
            group = Mid(line, 9).Trim()
        else if startsWith(line, "#") then
            ' other directives
        else
            counter = counter + 1
            nm = name
            if nm = invalid or nm = "" then nm = orStr(sv(attrs, "tvg-name"), "Channel " + counter.ToStr())
            grp = orStr(sv(attrs, "group-title"), orStr(group, "Uncategorized"))
            logo = orStr(sv(attrs, "tvg-logo"), "")
            ty = m3uClassify(line, grp, nm, seRe)
            catId = ty + ":" + grp
            if cats[catId] = invalid then cats[catId] = { id: catId, name: grp, ty: ty }
            if ty = "SERIES" then
                m = seRe.Match(nm)
                sname = nm
                season = 1
                epn = 0
                rest = ""
                if m.Count() > 4 then
                    sname = m[1].Trim()
                    if sname = "" then sname = nm
                    season = m[2].ToInt()
                    epn = m[3].ToInt()
                    rest = m[4].Trim()
                end if
                sid = "s:" + LCase(sname)
                if eps[sid] = invalid then eps[sid] = []
                if epn = 0 then epn = eps[sid].Count() + 1
                if not seriesSeen.DoesExist(sid) then
                    seriesSeen[sid] = true
                    it = newItem(sid, sname, "SERIES")
                    it.cat = catId
                    it.poster = logo
                    items.Push(it)
                end if
                title = rest
                if title = "" then title = "Episode " + epn.ToStr()
                e = newEp("e" + counter.ToStr(), season, epn, title, line)
                e.image = logo
                eps[sid].Push(e)
            else
                it = newItem("i" + counter.ToStr(), nm, ty)
                it.cat = catId
                it.poster = logo
                it.url = line
                it.number = toInt(sv(attrs, "tvg-chno"), counter)
                it.epg = orStr(firstStr(attrs, ["tvg-id", "tvg-name"]), "")
                items.Push(it)
            end if
            name = invalid
            attrs = {}
            group = invalid
        end if
    end for
    s.items = items
    s.cats = cats
    s.eps = eps
end sub

function m3uCategories(s as object, ty as string) as object
    out = []
    for each k in s.cats
        c = s.cats[k]
        if c.ty = ty then out.Push(c)
    end for
    out.SortBy("name")
    return { list: out }
end function

function m3uItems(s as object, ty as string, cat as string, page as integer) as object
    out = []
    if page = 1 then
        for each it in s.items
            if it.cat = cat then out.Push(it)
        end for
    end if
    return { list: out, hasMore: false }
end function

function m3uSearch(s as object, q as string) as object
    out = []
    for each it in s.items
        if searchMatch(it.name, q) then out.Push(it)
        if out.Count() >= 200 then exit for
    end for
    return { list: out }
end function

function m3uSeries(s as object, it as object) as object
    list = s.eps[it.id]
    if list = invalid then return { err: "No episodes found." }
    return { eps: list }
end function

function m3uResolve(s as object, it as object, ep as dynamic) as object
    if ep <> invalid then return { url: ep.url }
    if it.url = "" then return { err: "No stream URL for " + it.name }
    return { url: it.url }
end function
