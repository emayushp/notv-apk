' MAG / Stalker (Ministra) portal client. Ported from the Android app.

function stalkerNew(p as object) as object
    mac = normalizeMac(p.mac)
    serial = orStr(sv(p, "serial"), "")
    if serial = "" then serial = UCase(Left(md5Hex(mac), 13))
    devId = orStr(sv(p, "deviceId"), "")
    if devId = "" then devId = UCase(sha256Hex(mac))
    devId2 = orStr(sv(p, "deviceId2"), "")
    if devId2 = "" then devId2 = devId
    sig = orStr(sv(p, "signature"), "")
    if sig = "" then sig = UCase(sha256Hex(serial + mac))
    ua = orStr(sv(p, "userAgent"), "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
    tz = CreateObject("roDeviceInfo").GetTimeZone()
    if tz = invalid or tz = "" then tz = "UTC"
    return { kind: "STALKER", profile: p, mac: mac, serial: serial, devId: devId, devId2: devId2, sig: sig, ua: ua, tz: tz, endpoint: "", referer: "", token: "", attempts: [], lastBody: "", channels: invalid, vodCats: invalid, hasSeries: "" }
end function

function stalkerHeaders(s as object, withAuth as boolean) as object
    h = {}
    h["User-Agent"] = s.ua
    h["X-User-Agent"] = "Model: MAG250; Link: WiFi"
    h["Referer"] = s.referer
    h["Accept"] = "*/*"
    h["Cookie"] = "mac=" + enc(s.mac) + "; stb_lang=en; timezone=" + enc(s.tz)
    if withAuth and s.token <> "" then h["Authorization"] = "Bearer " + s.token
    return h
end function

' Returns { js, err } where err = "" on success, "auth" when the token expired.
function stalkerRaw(s as object, ep as string, params as string, withAuth as boolean, timeoutMs = 15000 as integer) as object
    r = httpGet(ep + "?" + params + "&JsHttpRequest=1-xml", stalkerHeaders(s, withAuth), timeoutMs)
    s.lastBody = Left(r.body, 300)
    if r.code = 401 or r.code = 403 then return { js: invalid, err: "auth" }
    if not r.ok then return { js: invalid, err: httpErrorText(r) }
    parsed = parseJsonLoose(r.body)
    if parsed = invalid then
        if Instr(1, LCase(r.body), "authorization failed") > 0 then return { js: invalid, err: "auth" }
        return { js: invalid, err: "" }
    end if
    if isAA(parsed) then
        if parsed.DoesExist("js") and parsed.js <> invalid then return { js: parsed.js, err: "" }
    end if
    return { js: parsed, err: "" }
end function

function stalkerCall(s as object, params as string) as object
    r = stalkerRaw(s, s.endpoint, params, true)
    if r.err = "auth" then
        if stalkerHandshake(s, s.endpoint) = "" then r = stalkerRaw(s, s.endpoint, params, true)
    end if
    if r.err = "auth" then r.err = "The portal ended the session. Try again."
    return r
end function

function stalkerHandshake(s as object, ep as string) as string
    s.token = ""
    r = stalkerRaw(s, ep, "type=stb&action=handshake&token=&prehash=0", false, 9000)
    if r.err <> "" then return r.err
    hs = r.js
    if not isAA(hs) then return "Portal handshake failed"
    tok = sv(hs, "token")
    if tok = invalid then return "Portal didn't return a token"
    s.token = tok
    random = sv(hs, "random")
    if random = invalid then random = Left(sha256Hex(nowSec().ToStr() + Rnd(1000000).ToStr()), 40)
    ver = "ImageDescription: 0.2.18-r23-250; ImageDate: Fri Jan 15 15:20:44 EET 2016; PORTAL version: 5.6.1; API Version: JS API version: 343; STB API version: 146; Player Engine version: 0x566"
    metrics = FormatJson({ mac: s.mac, sn: s.serial, "type": "STB", model: "MAG250", uid: s.devId, random: random })
    params = "type=stb&action=get_profile&hd=1&ver=" + enc(ver) + "&num_banks=2&sn=" + enc(s.serial) + "&stb_type=MAG250&client_type=STB&image_version=218&video_out=hdmi&device_id=" + enc(s.devId) + "&device_id2=" + enc(s.devId2) + "&signature=" + enc(s.sig) + "&auth_second_step=1&hw_version=1.7-BD-00&not_valid_token=0&metrics=" + enc(metrics) + "&hw_version_2=" + Left(sha256Hex(s.mac), 40) + "&timestamp=" + nowSec().ToStr() + "&api_signature=262&prehash="
    r = stalkerRaw(s, ep, params, true, 12000)
    if r.err <> "" then
        if r.err = "auth" then return "The portal refused this MAC."
        return r.err
    end if
    p = r.js
    if not isAA(p) then return "Portal profile request failed"
    block = sv(p, "block_msg")
    if block <> invalid then return block
    status = sv(p, "status")
    if sv(p, "id") = invalid and sv(p, "name") = invalid and status <> invalid and status <> "0" then
        msg = sv(p, "msg")
        if msg = invalid then msg = "This MAC is not activated on the portal (status " + status + ")."
        return msg
    end if
    return ""
end function

function stalkerCandidates(input as string) as object
    u = input.Trim()
    i = Instr(1, u, "?")
    if i > 0 then u = Left(u, i - 1)
    i = Instr(1, u, "#")
    if i > 0 then u = Left(u, i - 1)
    u = stripTrailingSlashes(u)
    if not startsWith(LCase(u), "http") then u = "http://" + u
    root = hostRoot(u)
    out = []
    if endsWith(u, ".php") then
        slash = 0
        k = Instr(1, u, "/")
        while k > 0
            slash = k
            k = Instr(k + 1, u, "/")
        end while
        out.Push([u, Left(u, slash) + "c/"])
    end if
    sp = Instr(1, u, "/stalker_portal")
    if sp > 0 then
        base = Left(u, sp - 1) + "/stalker_portal"
        out.Push([base + "/server/load.php", base + "/c/"])
    end if
    if endsWith(u, "/c") then
        r = Left(u, Len(u) - 2)
        out.Push([r + "/portal.php", r + "/c/"])
        out.Push([r + "/server/load.php", r + "/c/"])
        out.Push([r + "/stalker_portal/server/load.php", r + "/stalker_portal/c/"])
    end if
    out.Push([root + "/portal.php", root + "/c/"])
    out.Push([root + "/stalker_portal/server/load.php", root + "/stalker_portal/c/"])
    out.Push([root + "/server/load.php", root + "/c/"])
    ' same list with the other scheme
    all = []
    seen = {}
    for pass = 0 to 1
        for each c in out
            e = c[0]
            ref = c[1]
            if pass = 1 then
                e = swapScheme(e)
                ref = swapScheme(ref)
            end if
            if not seen.DoesExist(e) then
                seen[e] = true
                all.Push([e, ref])
            end if
        end for
    end for
    return all
end function

function swapScheme(u as string) as string
    if startsWith(u, "https://") then return "http://" + Mid(u, 9)
    if startsWith(u, "http://") then return "https://" + Mid(u, 8)
    return u
end function

function stalkerConnect(s as object) as string
    if Len(s.mac) <> 17 then return "MAC address must look like 00:1A:79:12:34:56"
    s.attempts = []
    rejected = ""
    for each c in stalkerCandidates(s.profile.url)
        s.referer = c[1]
        e = stalkerHandshake(s, c[0])
        if e = "" then
            s.endpoint = c[0]
            return ""
        end if
        s.attempts.Push(c[0] + "  ->  " + e)
        if s.token <> "" then
            s.endpoint = c[0]
            rejected = e
            exit for
        end if
    end for
    lines = ""
    start = s.attempts.Count() - 10
    if start < 0 then start = 0
    for i = start to s.attempts.Count() - 1
        lines = lines + Chr(10) + "- " + s.attempts[i]
    end for
    if rejected <> "" then return "The portal rejected the login: " + rejected + Chr(10) + lines
    return "Couldn't find the portal. Check the portal URL (use the address your provider gave you, e.g. http://host/stalker_portal/c/) and that this MAC is registered." + Chr(10) + lines
end function

function stalkerAccount(s as object) as dynamic
    r = stalkerCall(s, "type=account_info&action=get_main_info")
    if r.err <> "" or not isAA(r.js) then return invalid
    return { status: orStr(sv(r.js, "status"), "Active"), expires: orStr(firstStr(r.js, ["end_date", "phone", "expire_billing_date"]), "Unknown"), extra: orStr(sv(r.js, "tariff_plan"), "MAC " + s.mac) }
end function

function stalkerAbs(s as object, u as dynamic) as string
    if u = invalid then return ""
    if startsWith(LCase(u), "http") then return u
    root = hostRoot(s.endpoint)
    if startsWith(u, "/") then return root + u
    return root + "/" + u
end function

function stalkerGenres(js as dynamic, ty as string, prefix as string) as object
    arr = js
    if isAA(js) then arr = js.data
    out = []
    if not isArray(arr) then return out
    for each o in arr
        id = sv(o, "id")
        if id <> invalid and id <> "*" then
            name = firstStr(o, ["title", "name"])
            if name = invalid then name = id
            out.Push({ id: prefix + id, name: name, ty: ty })
        end if
    end for
    return out
end function

function stalkerCategories(s as object, ty as string) as object
    if ty = "LIVE" then
        r = stalkerCall(s, "type=itv&action=get_genres")
        if r.err <> "" then return { err: r.err }
        return { list: stalkerGenres(r.js, "LIVE", "") }
    end if
    if s.vodCats = invalid then
        r = stalkerCall(s, "type=vod&action=get_categories")
        if r.err <> "" then return { err: r.err }
        s.vodCats = stalkerGenres(r.js, "MOVIE", "vod:")
    end if
    if ty = "MOVIE" then
        movies = []
        for each c in s.vodCats
            if not isSeriesCategoryName(c.name) then movies.Push(c)
        end for
        if movies.Count() = 0 then movies = s.vodCats
        return { list: movies }
    end if
    out = []
    r = stalkerCall(s, "type=series&action=get_categories")
    if r.err = "" then out = stalkerGenres(r.js, "SERIES", "series:")
    if out.Count() > 0 then s.hasSeries = "yes" else s.hasSeries = "no"
    for each c in s.vodCats
        if isSeriesCategoryName(c.name) then out.Push({ id: c.id, name: c.name, ty: "SERIES" })
    end for
    return { list: out }
end function

function stalkerChannels(s as object) as object
    if s.channels <> invalid then return { list: s.channels }
    r = stalkerCall(s, "type=itv&action=get_all_channels")
    if r.err <> "" then return { err: r.err }
    arr = r.js
    if isAA(arr) then arr = arr.data
    out = []
    if isArray(arr) then
        for each o in arr
            id = sv(o, "id")
            if id <> invalid then
                it = newItem(id, orStr(sv(o, "name"), id), "LIVE")
                it.cat = orStr(sv(o, "tv_genre_id"), "")
                it.poster = stalkerAbs(s, sv(o, "logo"))
                it.url = orStr(sv(o, "cmd"), "")
                it.number = toInt(sv(o, "number"), 0)
                it.epg = orStr(sv(o, "xmltv_id"), "")
                out.Push(it)
            end if
        end for
    end if
    out.SortBy("number")
    ' channels without a number go last
    numbered = []
    rest = []
    for each c in out
        if c.number > 0 then numbered.Push(c) else rest.Push(c)
    end for
    numbered.Append(rest)
    s.channels = numbered
    return { list: numbered }
end function

function stalkerItems(s as object, ty as string, cat as string, page as integer) as object
    if ty = "LIVE" then
        ch = stalkerChannels(s)
        if ch.err <> invalid then return ch
        out = []
        if page = 1 then
            for each c in ch.list
                if c.cat = cat then out.Push(c)
            end for
        end if
        return { list: out, hasMore: false }
    end if
    colon = Instr(1, cat, ":")
    module = Left(cat, colon - 1)
    c = Mid(cat, colon + 1)
    r = stalkerCall(s, "type=" + module + "&action=get_ordered_list&category=" + enc(c) + "&genre=*&p=" + page.ToStr() + "&sortby=added&fav=0&hd=0&not_ended=0&abc=*&years=*")
    if r.err <> "" then return { err: r.err }
    if not isAA(r.js) then return { list: [], hasMore: false }
    forced = ""
    if module = "series" then forced = "SERIES"
    list = stalkerVodList(s, r.js, module, cat, forced)
    total = toInt(sv(r.js, "total_items"), 0)
    per = toInt(sv(r.js, "max_page_items"), 14)
    if per <= 0 then per = 14
    return { list: list, hasMore: page * per < total }
end function

function stalkerVodList(s as object, r as object, module as string, cat as string, forced as string) as object
    out = []
    if not isArray(r.data) then return out
    for each o in r.data
        id = sv(o, "id")
        if id <> invalid then
            isSeries = forced = "SERIES" or sv(o, "is_series") = "1" or sv(o, "is_series") = "true"
            ty = "MOVIE"
            if isSeries then ty = "SERIES"
            it = newItem(id, orStr(firstStr(o, ["name", "o_name"]), id), ty)
            it.cat = cat
            it.poster = stalkerAbs(s, firstStr(o, ["screenshot_uri", "cover_big", "pic"]))
            it.plot = orStr(sv(o, "description"), "")
            it.year = Left(orStr(sv(o, "year"), ""), 4)
            rating = firstStr(o, ["rating_imdb", "rating_kinopoisk"])
            if rating <> invalid and rating <> "0" and rating <> "N/A" then it.rating = rating
            it.genre = orStr(sv(o, "genres_str"), "")
            it.cast = orStr(sv(o, "actors"), "")
            it.director = orStr(sv(o, "director"), "")
            t = sv(o, "time")
            if t <> invalid and t <> "0" then it.duration = t + " min"
            it.url = orStr(sv(o, "cmd"), "")
            it.extra = module
            if isArray(o.series) and o.series.Count() > 0 then
                eps = ""
                for each e in o.series
                    if eps <> "" then eps = eps + ","
                    eps = eps + toStr(e)
                end for
                it.extra = module + ";eps=" + eps
            end if
            out.Push(it)
        end if
    end for
    return out
end function

function stalkerSearch(s as object, q as string) as object
    out = []
    ch = stalkerChannels(s)
    if ch.err = invalid then
        for each c in ch.list
            if searchMatch(c.name, q) then out.Push(c)
            if out.Count() >= 60 then exit for
        end for
    end if
    vod = []
    r = stalkerCall(s, "type=vod&action=get_ordered_list&search=" + enc(q) + "&p=1&sortby=added")
    if r.err = "" and isAA(r.js) then vod = stalkerVodList(s, r.js, "vod", "vod:*", "")
    if s.hasSeries <> "no" then
        r = stalkerCall(s, "type=series&action=get_ordered_list&search=" + enc(q) + "&p=1&sortby=added")
        if r.err = "" and isAA(r.js) then vod.Append(stalkerVodList(s, r.js, "series", "series:*", "SERIES"))
    end if
    vod.Append(out)
    return { list: vod }
end function

function stalkerOrdered(s as object, module as string, movieId as string, seasonId as string, debug as object, episodeId = "0" as string) as object
    out = []
    for page = 1 to 15
        r = stalkerCall(s, "type=" + module + "&action=get_ordered_list&movie_id=" + enc(movieId) + "&season_id=" + enc(seasonId) + "&episode_id=" + enc(episodeId) + "&p=" + page.ToStr() + "&sortby=added")
        if page = 1 then
            if r.err <> "" then
                debug.Push("[" + module + " s=" + seasonId + "] " + r.err)
            else
                debug.Push("[" + module + " s=" + seasonId + "] " + Left(FormatJson(r.js), 300))
            end if
        end if
        if r.err <> "" then exit for
        obj = invalid
        arr = invalid
        if isAA(r.js) then
            obj = r.js
            arr = r.js.data
        else if isArray(r.js) then
            arr = r.js
        end if
        if not isArray(arr) then exit for
        for each x in arr
            if isAA(x) then out.Push(x)
        end for
        total = 0
        per = 14
        if obj <> invalid then
            total = toInt(sv(obj, "total_items"), 0)
            per = toInt(sv(obj, "max_page_items"), 14)
        end if
        if per <= 0 then per = 14
        if arr.Count() = 0 or page * per >= total then exit for
    end for
    return out
end function

function newEp(id as string, season as integer, num as integer, title as string, url as string) as object
    return { id: id, season: season, episode: num, title: title, url: url, plot: "", image: "", dur: 0 }
end function

function stalkerSeries(s as object, it as object) as object
    extra = it.extra
    if extra = invalid or extra = "" then extra = "vod"
    module = extra
    semi = Instr(1, extra, ";")
    if semi > 0 then module = Left(extra, semi - 1)
    inline = []
    k = Instr(1, extra, ";eps=")
    if k > 0 then
        for each x in Mid(extra, k + 5).Split(",")
            n = toInt(x, -1)
            if n >= 0 then inline.Push(n)
        end for
    end if
    debug = []
    eps = []
    stalkerCollect(s, it, module, eps, debug)
    if eps.Count() = 0 then
        other = "series"
        if module = "series" then other = "vod"
        stalkerCollect(s, it, other, eps, debug)
    end if
    if eps.Count() = 0 and inline.Count() > 0 and it.url <> "" then
        for each n in inline
            eps.Push(newEp(it.id + "_" + n.ToStr(), 1, n, "Episode " + n.ToStr(), module + "|" + it.url + "|" + n.ToStr()))
        end for
    end if
    if eps.Count() = 0 then
        txt = ""
        for each d in debug
            txt = txt + Chr(10) + d
        end for
        return { err: "No episodes found for " + it.name + "." + Chr(10) + Left(txt, 700) }
    end if
    return { eps: eps }
end function

sub stalkerCollect(s as object, it as object, module as string, eps as object, debug as object)
    level1 = stalkerOrdered(s, module, it.id, "0", debug)
    idx = 0
    for each sn in level1
        idx = idx + 1
        sid = sv(sn, "id")
        seasonNum = toInt(sv(sn, "season_number"), -1)
        if seasonNum < 0 then
            nn = numberIn(firstStr(sn, ["name", "o_name"]))
            if nn <> invalid then seasonNum = nn else seasonNum = idx
        end if
        cmd = sv(sn, "cmd")
        isEpisode = sv(sn, "is_episode") = "1" or sv(sn, "is_episode") = "true" or sn.DoesExist("series_number")
        if isArray(sn.series) and sn.series.Count() > 0 and cmd <> invalid then
            i = 0
            for each x in sn.series
                i = i + 1
                n = toInt(x, i)
                e = newEp(orStr(sid, seasonNum.ToStr()) + "_" + n.ToStr(), seasonNum, n, "Episode " + n.ToStr(), module + "|" + cmd + "|" + n.ToStr())
                e.image = stalkerAbs(s, sv(sn, "screenshot_uri"))
                eps.Push(e)
            end for
        else if isEpisode and cmd <> invalid then
            n = toInt(sv(sn, "series_number"), -1)
            if n < 0 then
                nn = numberIn(sv(sn, "name"))
                if nn <> invalid then n = nn else n = eps.Count() + 1
            end if
            e = newEp(orStr(sid, "e" + n.ToStr()), toInt(sv(sn, "season_number"), 1), n, orStr(firstStr(sn, ["name", "o_name"]), "Episode " + n.ToStr()), module + "|" + cmd + "|" + orStr(sv(sn, "series_number"), ""))
            e.plot = orStr(sv(sn, "description"), "")
            e.image = stalkerAbs(s, sv(sn, "screenshot_uri"))
            eps.Push(e)
        else if sid <> invalid then
            level2 = stalkerOrdered(s, module, it.id, sid, debug)
            for each ep in level2
                epId = sv(ep, "id")
                ecmd = sv(ep, "cmd")
                ' Ministra 5.x: episodes carry no cmd; the file is fetched at play time
                if ecmd = invalid and epId <> invalid then ecmd = "@ep:" + it.id + "~" + sid + "~" + epId
                if ecmd <> invalid then
                    n = toInt(sv(ep, "series_number"), -1)
                    if n < 0 then
                        nn = numberIn(sv(ep, "name"))
                        if nn <> invalid then
                            n = nn
                        else
                            n = 1
                            for each pe in eps
                                if pe.season = seasonNum then n = n + 1
                            end for
                        end if
                    end if
                    e = newEp(orStr(epId, sid + "_" + n.ToStr()), seasonNum, n, orStr(firstStr(ep, ["series_name", "name", "o_name"]), "Episode " + n.ToStr()), module + "|" + ecmd + "|" + orStr(sv(ep, "series_number"), ""))
                    e.plot = orStr(firstStr(ep, ["description", "series_description"]), "")
                    e.image = stalkerAbs(s, firstStr(ep, ["screenshot_uri", "cover_big"]))
                    e.dur = toInt(sv(ep, "time"), 0) * 60
                    eps.Push(e)
                end if
            end for
            if level2.Count() = 0 and cmd <> invalid then eps.Push(newEp(sid, seasonNum, 1, orStr(sv(sn, "name"), "Season " + seasonNum.ToStr()), module + "|" + cmd + "|"))
        end if
    end for
end sub

function stalkerStrip(cmd as string) as string
    re = CreateObject("roRegex", "^(ffmpeg|ffrt|ffrt2|ffrt3|auto)\s+", "")
    return re.Replace(cmd.Trim(), "").Trim()
end function

function stalkerCreateLink(s as object, ty as string, cmd as string, series as string) as object
    r = stalkerCall(s, "type=" + ty + "&action=create_link&cmd=" + enc(cmd) + "&series=" + enc(series) + "&forced_storage=undefined&disable_ad=0&download=0&force_ch_link_check=0")
    link = invalid
    if r.err = "" then
        if isAA(r.js) then
            link = sv(r.js, "cmd")
        else if type(r.js) = "String" or type(r.js) = "roString" then
            link = r.js
        end if
    end if
    u = ""
    if link <> invalid then u = stalkerStrip(link)
    re = CreateObject("roRegex", "^(http|rtmp|rtsp|udp)", "i")
    if u = "" or not re.IsMatch(u) then
        fb = stalkerStrip(cmd)
        if startsWith(fb, "http") and Instr(1, fb, "localhost") = 0 then return { url: fb }
        if r.err <> "" then return { err: r.err }
        return { err: "The portal didn't return a playable link." }
    end if
    return { url: u }
end function

function stalkerResolve(s as object, it as object, ep as dynamic) as object
    if ep <> invalid then
        parts = ep.url.Split("|")
        module = "vod"
        if parts.Count() > 0 and parts[0] <> "" then module = parts[0].Split(";")[0]
        cmd = ""
        if parts.Count() > 1 then cmd = parts[1]
        series = ""
        if parts.Count() > 2 then series = parts[2]
        if cmd = "" then return { err: "Episode has no link" }
        if startsWith(cmd, "@ep:") then
            ids = Mid(cmd, 5).Split("~")
            dbg = []
            files = stalkerOrdered(s, module, ids[0], ids[1], dbg, ids[2])
            fileCmd = invalid
            for each f in files
                if fileCmd = invalid then fileCmd = sv(f, "cmd")
            end for
            if fileCmd = invalid then
                for each f in files
                    fid = sv(f, "id")
                    if fileCmd = invalid and fid <> invalid then fileCmd = "/media/file_" + fid + ".mpg"
                end for
            end if
            if fileCmd = invalid then return { err: "The portal didn't return a file for this episode." }
            r = stalkerCreateLink(s, module, fileCmd, "")
            if r.err <> invalid then r = stalkerCreateLink(s, module, fileCmd, series)
            return r
        end if
        ty = module
        if module = "series" then ty = "vod"
        r = stalkerCreateLink(s, ty, cmd, series)
        if r.err <> invalid and module = "series" then r = stalkerCreateLink(s, "series", cmd, series)
        return r
    end if
    if it.url = "" then return { err: "No link for " + it.name }
    ty = "vod"
    if it.ty = "LIVE" then ty = "itv"
    return stalkerCreateLink(s, ty, it.url, "")
end function

function stalkerEpg(s as object, ch as object) as object
    r = stalkerCall(s, "type=itv&action=get_short_epg&ch_id=" + enc(ch.id) + "&size=6")
    arr = r.js
    if isAA(arr) then arr = arr.data
    out = []
    if not isArray(arr) then return out
    now = nowSec()
    for each o in arr
        a = toInt(sv(o, "start_timestamp"), -1)
        b = toInt(sv(o, "stop_timestamp"), -1)
        if a > 0 and b > now then out.Push({ title: orStr(firstStr(o, ["name", "title"]), ""), start: a, endt: b, desc: orStr(sv(o, "descr"), "") })
    end for
    out.SortBy("start")
    return out
end function
