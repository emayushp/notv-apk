sub init()
    m.cats = m.top.findNode("cats")
    m.channels = m.top.findNode("channels")
    m.status = m.top.findNode("status")
    m.catTitle = m.top.findNode("catTitle")
    m.logo = m.top.findNode("logo")
    m.chName = m.top.findNode("chName")
    m.chNum = m.top.findNode("chNum")
    m.epg = m.top.findNode("epg")
    m.catTimer = m.top.findNode("catTimer")
    m.epgTimer = m.top.findNode("epgTimer")
    m.catTimer.observeField("fire", "onCatTimer")
    m.epgTimer.observeField("fire", "onEpgTimer")
    m.cats.observeField("itemFocused", "onCatFocused")
    m.cats.observeField("itemSelected", "onCatSelected")
    m.channels.observeField("itemFocused", "onChFocused")
    m.channels.observeField("itemSelected", "onChSelected")
    m.top.observeField("focusedChild", "onFocusChild")
    m.catList = []
    m.current = -1
    m.items = []
    m.token = 0
end sub

sub onFocusChild()
    if m.top.hasFocus() then
        if m.items.Count() > 0 then m.channels.setFocus(true) else m.cats.setFocus(true)
    end if
end sub

sub onStart()
    m.status.text = "Loading channels..."
    api("cats", { ty: "LIVE", hideAdult: isTrue(getSettings().hideAdult) }, onCats)
end sub

sub onRefresh()
    ' refresh stars and the virtual lists after coming back from the player
    if m.current >= 0 and m.current < 2 then loadCat(m.current)
end sub

sub onCats(r as object)
    if not r.ok then
        m.status.text = r.error
        return
    end if
    scores = categoryScores()
    scored = []
    rest = []
    for each c in r.data
        sc = scores["LIVE|" + c.id]
        if sc <> invalid and sc > 0 then
            c.score = sc
            scored.Push(c)
        else
            rest.Push(c)
        end if
    end for
    scored.SortBy("score", "r")
    m.catList = [{ id: "__fav", name: "★ My channels" }, { id: "__recent", name: "Recent" }]
    m.catList.Append(scored)
    m.catList.Append(rest)
    content = CreateObject("roSGNode", "ContentNode")
    for each c in m.catList
        n = content.createChild("ContentNode")
        n.title = c.name
    end for
    m.cats.content = content
    st = getSettings()
    want = invalid
    if isAA(st.lastCat) then want = st.lastCat[currentPid() + "|LIVE"]
    idx = 2
    if m.catList.Count() <= 2 then idx = 0
    if want <> invalid then
        for i = 0 to m.catList.Count() - 1
            if m.catList[i].id = want then idx = i
        end for
    end if
    m.cats.jumpToItem = idx
    loadCat(idx)
end sub

sub onCatFocused()
    m.catTimer.control = "stop"
    m.catTimer.control = "start"
end sub

sub onCatTimer()
    if m.cats.itemFocused <> m.current then loadCat(m.cats.itemFocused)
end sub

sub onCatSelected()
    if m.cats.itemSelected <> m.current then loadCat(m.cats.itemSelected)
    if m.items.Count() > 0 then m.channels.setFocus(true)
end sub

sub loadCat(i as integer)
    if i < 0 or i >= m.catList.Count() then return
    m.current = i
    c = m.catList[i]
    m.catTitle.text = c.name
    m.token = m.token + 1
    if c.id = "__fav" or c.id = "__recent" then
        list = []
        seen = {}
        pid = currentPid()
        if c.id = "__fav" then
            for each f in getFavs()
                if f.pid = pid and f.it.ty = "LIVE" then list.Push(f.it)
            end for
        else
            for each e in getProgressList()
                if e.pid = pid and e.ty = "LIVE" and not seen.DoesExist(e.it.id) then
                    seen[e.it.id] = true
                    list.Push(e.it)
                end if
            end for
        end if
        showList(list)
        if list.Count() = 0 then
            if c.id = "__fav" then
                m.status.text = "Press * on a channel to add it here."
            else
                m.status.text = "Channels you watch show up here."
            end if
        end if
        return
    end if
    lc = getSettings().lastCat
    if not isAA(lc) then lc = {}
    lc[currentPid() + "|LIVE"] = c.id
    patchSettings({ lastCat: lc })
    m.status.text = "Loading..."
    m.status.visible = true
    m.channels.content = CreateObject("roSGNode", "ContentNode")
    m.items = []
    m.wantToken = m.token
    api("items", { ty: "LIVE", cat: c.id, page: 1, force: false }, onItems)
end sub

sub onItems(r as object)
    if m.wantToken <> m.token then return
    if not r.ok then
        m.status.text = r.error
        return
    end if
    list = []
    src = r.node
    for i = 0 to src.getChildCount() - 1
        list.Push(src.getChild(i).item)
    end for
    showList(list)
    if list.Count() = 0 then m.status.text = "No channels."
end sub

sub showList(list as object)
    favIds = {}
    pid = currentPid()
    for each f in getFavs()
        if f.pid = pid and f.it.ty = "LIVE" then favIds[f.it.id] = true
    end for
    m.items = list
    content = CreateObject("roSGNode", "ContentNode")
    for each it in list
        content.appendChild(itemToNode(it, { fav: favIds.DoesExist(it.id) }))
    end for
    m.channels.content = content
    m.status.visible = list.Count() = 0
    onChFocused()
end sub

sub onChFocused()
    i = m.channels.itemFocused
    if i < 0 or i >= m.items.Count() then
        m.chName.text = ""
        m.chNum.text = ""
        m.epg.text = ""
        m.logo.uri = ""
        return
    end if
    it = m.items[i]
    m.chName.text = it.name
    if it.number <> invalid and it.number > 0 then m.chNum.text = "Channel " + toStr(it.number) else m.chNum.text = ""
    m.logo.uri = it.poster
    m.epg.text = ""
    m.epgTimer.control = "stop"
    m.epgTimer.control = "start"
end sub

sub onEpgTimer()
    i = m.channels.itemFocused
    if i < 0 or i >= m.items.Count() then return
    m.epgFor = m.items[i].id
    api("epg", { item: m.items[i] }, onEpg)
end sub

sub onEpg(r as object)
    i = m.channels.itemFocused
    if i < 0 or i >= m.items.Count() or m.items[i].id <> m.epgFor then return
    if not r.ok or not isArray(r.data) or r.data.Count() = 0 then
        m.epg.text = "No programme guide for this channel."
        return
    end if
    now = CreateObject("roDateTime").AsSeconds()
    t = ""
    n = 0
    for each e in r.data
        if n < 4 then
            label = fmtClock(e.start) + " - " + fmtClock(e.endt)
            if e.start <= now and e.endt > now then label = "NOW  " + label
            t = t + label + Chr(10) + e.title + Chr(10) + Chr(10)
            n = n + 1
        end if
    end for
    m.epg.text = t
end sub

sub onChSelected()
    i = m.channels.itemSelected
    if i < 0 or i >= m.items.Count() then return
    m.top.action = { kind: "live", list: m.items, index: i }
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "right" and m.cats.hasFocus() and m.items.Count() > 0 then
        m.channels.setFocus(true)
        return true
    end if
    if (key = "left" or key = "back") and m.channels.hasFocus() then
        m.cats.setFocus(true)
        return true
    end if
    if key = "options" and m.channels.hasFocus() then
        i = m.channels.itemFocused
        if i >= 0 and i < m.items.Count() then
            nowFav = toggleFav(m.items[i])
            m.channels.content.replaceChild(itemToNode(m.items[i], { fav: nowFav }), i)
        end if
        return true
    end if
    return false
end function
