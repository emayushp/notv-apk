sub init()
    m.kb = m.top.findNode("kb")
    m.grid = m.top.findNode("grid")
    m.status = m.top.findNode("status")
    m.timer = m.top.findNode("timer")
    m.kb.observeField("text", "onText")
    m.timer.observeField("fire", "doSearch")
    m.grid.observeField("itemSelected", "onSelected")
    m.top.observeField("focusedChild", "onFocusChild")
    m.lastQ = ""
end sub

sub onFocusChild()
    if m.top.hasFocus() then m.kb.setFocus(true)
end sub

sub onStart()
end sub

sub onRefresh()
end sub

sub onText()
    m.timer.control = "stop"
    m.timer.control = "start"
end sub

sub doSearch()
    q = m.kb.text.Trim()
    if q = m.lastQ then return
    m.lastQ = q
    if Len(q) < 2 then
        m.grid.content = CreateObject("roSGNode", "ContentNode")
        m.status.text = "Type a title or channel name."
        m.status.visible = true
        return
    end if
    m.status.text = "Searching..."
    m.status.visible = true
    m.qFor = q
    api("search", { q: q }, onResults)
end sub

sub onResults(r as object)
    if m.qFor <> m.lastQ then return
    if not r.ok then
        m.status.text = r.error
        return
    end if
    if r.count = 0 then
        m.status.text = "Nothing found for " + Chr(34) + m.lastQ + Chr(34) + "."
        m.grid.content = CreateObject("roSGNode", "ContentNode")
        return
    end if
    m.status.visible = false
    m.grid.content = r.node
end sub

sub onSelected()
    n = m.grid.content.getChild(m.grid.itemSelected)
    if n = invalid or n.item = invalid then return
    it = n.item
    if it.ty = "LIVE" then
        m.top.action = { kind: "live", list: [it], index: 0 }
    else
        m.top.action = { kind: "details", item: it }
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "right" and not m.grid.hasFocus() and m.grid.content <> invalid and m.grid.content.getChildCount() > 0 then
        m.grid.setFocus(true)
        return true
    end if
    if (key = "left" or key = "back") and m.grid.hasFocus() then
        m.kb.setFocus(true)
        return true
    end if
    return false
end function
