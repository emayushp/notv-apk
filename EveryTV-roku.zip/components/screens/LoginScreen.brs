sub init()
    m.list = m.top.findNode("list")
    m.status = m.top.findNode("status")
    m.hint = m.top.findNode("hint")
    m.heading = m.top.findNode("heading")
    m.f = { id: "", "type": "STALKER", name: "", url: "", mac: "", serial: "", username: "", password: "", userAgent: "" }
    m.typeNames = { STALKER: "MAG / Stalker portal", XTREAM: "Xtream Codes", M3U: "M3U playlist" }
    m.list.observeField("itemSelected", "onSelect")
    m.top.observeField("focusedChild", "onFocusChild")
    draw()
end sub

sub onFocusChild()
    if m.top.hasFocus() then m.list.setFocus(true)
end sub

sub onProfile()
    p = m.top.profile
    if not isAA(p) then return
    for each k in p
        m.f[k] = p[k]
    end for
    m.heading.text = "Edit source"
    draw()
end sub

sub onError()
    m.status.color = "0xFF7A7AFF"
    m.status.text = m.top.errorText
end sub

sub onBusy()
    if m.top.busy then
        m.status.color = "0xAAAAAAFF"
        m.status.text = "Connecting... (this can take up to a minute while EveryTV finds the portal)"
    end if
end sub

function shown(v as dynamic, secret as boolean) as string
    if v = invalid or v = "" then return "-"
    if secret then return String(Len(v), "*")
    return v
end function

sub draw()
    f = m.f
    rows = [["type", "Source type:  " + m.typeNames[f["type"]]], ["name", "Name:  " + shown(f.name, false)]]
    if f["type"] = "STALKER" then
        rows.Push(["url", "Portal URL:  " + shown(f.url, false)])
        rows.Push(["mac", "MAC address:  " + shown(f.mac, false)])
        rows.Push(["serial", "Serial (optional):  " + shown(f.serial, false)])
        m.hint.text = "Portal URL: the address from your provider, for example http://portal.example.com/stalker_portal/c/" + Chr(10) + Chr(10) + "If that address forwards somewhere else, enter the final address." + Chr(10) + Chr(10) + "MAC: the MAC your provider activated, like 00:1A:79:12:34:56"
    else if f["type"] = "XTREAM" then
        rows.Push(["url", "Server URL:  " + shown(f.url, false)])
        rows.Push(["username", "Username:  " + shown(f.username, false)])
        rows.Push(["password", "Password:  " + shown(f.password, true)])
        m.hint.text = "Server URL like http://server.example.com:8080 - or paste the whole get.php link."
    else
        rows.Push(["url", "Playlist URL:  " + shown(f.url, false)])
        m.hint.text = "A link to an .m3u / .m3u8 playlist."
    end if
    rows.Push(["connect", "Connect"])
    if m.top.canCancel then rows.Push(["cancel", "Cancel"])
    m.rows = rows
    c = CreateObject("roSGNode", "ContentNode")
    for each r in rows
        n = c.createChild("ContentNode")
        n.title = r[1]
    end for
    focused = m.list.itemFocused
    m.list.content = c
    if focused >= 0 and focused < rows.Count() then m.list.jumpToItem = focused
end sub

sub onSelect()
    key = m.rows[m.list.itemSelected][0]
    if key = "type" then
        order = ["STALKER", "XTREAM", "M3U"]
        i = 0
        for j = 0 to 2
            if order[j] = m.f["type"] then i = j
        end for
        m.f["type"] = order[(i + 1) mod 3]
        draw()
    else if key = "connect" then
        submit()
    else if key = "cancel" then
        m.top.action = { kind: "close" }
    else
        labels = { name: "Name for this source", url: "URL", mac: "MAC address", serial: "Serial number (leave empty to derive it from the MAC)", username: "Username", password: "Password" }
        m.editing = key
        d = CreateObject("roSGNode", "StandardKeyboardDialog")
        d.title = labels[key]
        cur = m.f[key]
        if cur = invalid then cur = ""
        if key = "url" and cur = "" then cur = "http://"
        d.text = cur
        d.buttons = ["OK", "Cancel"]
        d.observeFieldScoped("buttonSelected", "onKbButton")
        m.dialog = d
        m.top.getScene().dialog = d
    end if
end sub

sub onKbButton()
    d = m.dialog
    if d = invalid then return
    if d.buttonSelected = 0 then
        v = d.text.Trim()
        if m.editing = "mac" then v = normalizeMac(v)
        m.f[m.editing] = v
    end if
    d.close = true
    m.dialog = invalid
    draw()
    m.list.setFocus(true)
end sub

sub submit()
    f = m.f
    if f.url = "" or f.url = "http://" then
        m.top.errorText = "Please enter the URL."
        return
    end if
    if f["type"] = "STALKER" and Len(normalizeMac(f.mac)) <> 17 then
        m.top.errorText = "The MAC address must look like 00:1A:79:12:34:56"
        return
    end if
    if f["type"] = "XTREAM" and Instr(1, f.url, "username=") = 0 and (f.username = "" or f.password = "") then
        m.top.errorText = "Username and password are required."
        return
    end if
    if f.name = "" then
        if f["type"] = "STALKER" then f.name = "MAG portal"
        if f["type"] = "XTREAM" then f.name = "Xtream"
        if f["type"] = "M3U" then f.name = "Playlist"
    end if
    if f.id = invalid or f.id = "" then f.id = "p" + CreateObject("roDateTime").AsSeconds().ToStr() + Rnd(9999).ToStr()
    p = {}
    p.Append(f)
    m.top.busy = true
    m.top.action = { kind: "connect", profile: p }
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back" and not m.top.canCancel then return true
    return false
end function
