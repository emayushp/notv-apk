sub init()
    m.rows = m.top.findNode("rows")
    m.title = m.top.findNode("title")
    m.meta = m.top.findNode("meta")
    m.plot = m.top.findNode("plot")
    m.backdrop = m.top.findNode("backdrop")
    m.loading = m.top.findNode("loading")
    m.rows.observeField("rowItemFocused", "onFocused")
    m.rows.observeField("rowItemSelected", "onSelected")
    m.top.observeField("focusedChild", "onFocusChild")
    m.rowTypes = []
end sub

sub onFocusChild()
    if m.top.hasFocus() then m.rows.setFocus(true)
end sub

sub onStart()
    build()
end sub

sub onRefresh()
    build()
end sub

sub build()
    root = CreateObject("roSGNode", "ContentNode")
    m.rowTypes = []
    pid = currentPid()
    cont = CreateObject("roSGNode", "ContentNode")
    cont.title = "Continue watching"
    recent = CreateObject("roSGNode", "ContentNode")
    recent.title = "Recent channels"
    seenSeries = {}
    seenLive = {}
    for each e in getProgressList()
        if e.pid = pid and e.it <> invalid then
            if e.ty = "LIVE" then
                if not seenLive.DoesExist(e.it.id) and recent.getChildCount() < 20 then
                    seenLive[e.it.id] = true
                    recent.appendChild(itemToNode(e.it))
                end if
            else if not isTrue(e.fin) and e.ps > 10 and cont.getChildCount() < 20 then
                ok = true
                if e.ty = "SERIES" then
                    if seenSeries.DoesExist(e.it.id) then ok = false
                    seenSeries[e.it.id] = true
                end if
                if ok then
                    extra = { frac: 0 }
                    if e.dur > 0 then extra.frac = e.ps / e.dur
                    if e.ep <> invalid then extra.label = "S" + toStr(e.ep.season) + ":E" + toStr(e.ep.episode) + "  " + fmtTime(e.ps)
                    if e.ep = invalid then extra.label = "Resume " + fmtTime(e.ps)
                    cont.appendChild(itemToNode(e.it, extra))
                end if
            end if
        end if
    end for
    if cont.getChildCount() > 0 then
        root.appendChild(cont)
        m.rowTypes.Push("MOVIE")
    end if
    favs = CreateObject("roSGNode", "ContentNode")
    favs.title = "My List"
    for each f in getFavs()
        if f.pid = pid and favs.getChildCount() < 30 then favs.appendChild(itemToNode(f.it))
    end for
    if favs.getChildCount() > 0 then
        root.appendChild(favs)
        m.rowTypes.Push("MOVIE")
    end if
    if recent.getChildCount() > 0 then
        root.appendChild(recent)
        m.rowTypes.Push("LIVE")
    end if
    m.root = root
    applyRows()
    st = getSettings()
    api("home", { scores: categoryScores(), hideAdult: isTrue(st.hideAdult) }, onHome)
end sub

sub onHome(r as object)
    m.loading.visible = false
    if not r.ok then
        if m.root.getChildCount() = 0 then
            m.loading.text = r.error
            m.loading.visible = true
        end if
        return
    end if
    remote = r.node
    types = r.rowTypes
    i = 0
    while remote.getChildCount() > 0
        row = remote.getChild(0)
        remote.removeChild(row)
        m.root.appendChild(row)
        m.rowTypes.Push(types[i])
        i = i + 1
    end while
    applyRows()
end sub

sub applyRows()
    sizes = []
    heights = []
    for each t in m.rowTypes
        if t = "LIVE" then
            sizes.Push([340, 280])
            heights.Push(350)
        else
            sizes.Push([260, 450])
            heights.Push(520)
        end if
    end for
    if sizes.Count() = 0 then return
    m.loading.visible = false
    focus = m.rows.rowItemFocused
    m.rows.rowItemSize = sizes
    m.rows.rowHeights = heights
    m.rows.content = m.root
    if isArray(focus) and focus.Count() = 2 and focus[0] >= 0 and focus[0] < m.root.getChildCount() then m.rows.jumpToRowItem = focus
    onFocused()
end sub

function focusedNode() as dynamic
    f = m.rows.rowItemFocused
    if not isArray(f) or f.Count() < 2 or m.rows.content = invalid then return invalid
    row = m.rows.content.getChild(f[0])
    if row = invalid then return invalid
    return row.getChild(f[1])
end function

sub onFocused()
    n = focusedNode()
    if n = invalid then return
    it = n.item
    m.title.text = n.title
    meta = ""
    if it <> invalid then
        if it.year <> invalid and it.year <> "" then meta = it.year
        if it.rating <> invalid and it.rating <> "" then meta = meta + "   Rating " + it.rating
        if it.ty = "LIVE" then meta = "Live channel"
    end if
    m.meta.text = meta
    m.plot.text = n.description
    m.backdrop.uri = n.HDPosterUrl
end sub

sub onSelected()
    f = m.rows.rowItemSelected
    row = m.rows.content.getChild(f[0])
    n = row.getChild(f[1])
    it = n.item
    if it = invalid then return
    if it.ty = "LIVE" then
        list = []
        for i = 0 to row.getChildCount() - 1
            list.Push(row.getChild(i).item)
        end for
        m.top.action = { kind: "live", list: list, index: f[1] }
    else
        m.top.action = { kind: "details", item: it }
    end if
end sub
