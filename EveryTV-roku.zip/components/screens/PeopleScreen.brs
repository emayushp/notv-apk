sub init()
    m.grid = m.top.findNode("grid")
    m.status = m.top.findNode("status")
    m.colors = ["0x7B2FF7FF", "0xF107A3FF", "0xFF8A00FF", "0x2E86DEFF", "0x10AC84FF", "0xE5484DFF", "0x16A085FF", "0x5B6CFFFF"]
    m.grid.observeField("itemSelected", "onSelect")
    m.top.observeField("focusedChild", "onFocusChild")
end sub

sub onFocusChild()
    if m.top.hasFocus() then m.grid.setFocus(true)
end sub

sub onStatus()
    m.status.text = m.top.statusText
end sub

function colorOf(i as dynamic) as string
    n = toInt(i, 0) mod m.colors.Count()
    if n < 0 then n = n + m.colors.Count()
    return m.colors[n]
end function

sub draw()
    m.entries = []
    c = CreateObject("roSGNode", "ContentNode")
    for each p in getPeople()
        n = c.createChild("ContentNode")
        n.title = toStr(p.name)
        n.shortDescriptionLine1 = UCase(Left(toStr(p.name), 1))
        n.shortDescriptionLine2 = colorOf(p.color)
        m.entries.Push({ kind: "person", person: p })
    end for
    if m.entries.Count() < 7 then
        n = c.createChild("ContentNode")
        n.title = "Add profile"
        n.shortDescriptionLine1 = "+"
        n.shortDescriptionLine2 = "0x2A2A33FF"
        m.entries.Push({ kind: "add" })
    end if
    n = c.createChild("ContentNode")
    n.title = "IPTV sources"
    n.shortDescriptionLine1 = "TV"
    n.shortDescriptionLine2 = "0x1C1C22FF"
    m.entries.Push({ kind: "sources" })
    ' centre the row
    count = m.entries.Count()
    if count > 5 then count = 5
    m.grid.numColumns = count
    m.grid.translation = [(1920 - (count * 220 + (count - 1) * 60)) / 2, 360]
    focused = m.grid.itemFocused
    m.grid.content = c
    if focused > 0 and focused < m.entries.Count() then m.grid.jumpToItem = focused
end sub

sub onSelect()
    e = m.entries[m.grid.itemSelected]
    if e.kind = "person" then
        m.top.action = { kind: "person", person: e.person }
    else if e.kind = "add" then
        askName(invalid)
    else
        m.top.action = { kind: "sources" }
    end if
end sub

sub askName(p as dynamic)
    m.editing = p
    d = CreateObject("roSGNode", "StandardKeyboardDialog")
    d.title = "Name"
    if p <> invalid then d.text = toStr(p.name)
    d.message = ["Use the same name on your other devices and their history joins up."]
    d.buttons = ["Save", "Cancel"]
    d.observeFieldScoped("buttonSelected", "onNameButton")
    m.dialog = d
    m.top.getScene().dialog = d
end sub

sub onNameButton()
    d = m.dialog
    choice = d.buttonSelected
    name = d.text.Trim()
    d.close = true
    m.dialog = invalid
    if choice = 0 and name <> "" then
        p = m.editing
        if p = invalid then
            p = { id: newId(), name: Left(name, 20), color: getPeople().Count() mod 8, updatedAt: nowMs() }
        else
            p.name = Left(name, 20)
            p.updatedAt = nowMs()
        end if
        savePerson(p)
        m.top.action = { kind: "peopleChanged" }
    end if
    draw()
    m.grid.setFocus(true)
end sub

sub editMenu(p as object)
    m.target = p
    d = CreateObject("roSGNode", "StandardMessageDialog")
    d.title = toStr(p.name)
    d.message = ["What would you like to change?"]
    btns = ["Rename", "Change colour"]
    if getPeople().Count() > 1 then btns.Push("Delete")
    btns.Push("Cancel")
    d.buttons = btns
    m.menuButtons = btns
    d.observeFieldScoped("buttonSelected", "onEditButton")
    m.dialog = d
    m.top.getScene().dialog = d
end sub

sub onEditButton()
    d = m.dialog
    choice = m.menuButtons[d.buttonSelected]
    d.close = true
    m.dialog = invalid
    p = m.target
    if choice = "Rename" then
        askName(p)
        return
    else if choice = "Change colour" then
        p.color = (toInt(p.color, 0) + 1) mod 8
        p.updatedAt = nowMs()
        savePerson(p)
        m.top.action = { kind: "peopleChanged" }
    else if choice = "Delete" then
        d2 = CreateObject("roSGNode", "StandardMessageDialog")
        d2.title = "Delete " + toStr(p.name) + "?"
        d2.message = ["Their history and My List go too, on every synced device."]
        d2.buttons = ["Delete", "Cancel"]
        d2.observeFieldScoped("buttonSelected", "onDeleteButton")
        m.dialog = d2
        m.top.getScene().dialog = d2
        return
    end if
    draw()
    m.grid.setFocus(true)
end sub

sub onDeleteButton()
    d = m.dialog
    choice = d.buttonSelected
    d.close = true
    m.dialog = invalid
    if choice = 0 then
        deletePerson(m.target.id)
        m.top.action = { kind: "peopleChanged" }
    end if
    draw()
    m.grid.setFocus(true)
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "options" then
        i = m.grid.itemFocused
        if i >= 0 and i < m.entries.Count() and m.entries[i].kind = "person" then editMenu(m.entries[i].person)
        return true
    end if
    return false
end function
