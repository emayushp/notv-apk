sub init()
    m.list = m.top.findNode("list")
    m.account = m.top.findNode("account")
    m.list.observeField("itemSelected", "onSelect")
    m.top.observeField("focusedChild", "onFocusChild")
end sub

sub onFocusChild()
    if m.top.hasFocus() then m.list.setFocus(true)
end sub

sub onStart()
    draw()
    m.account.text = "Checking account..."
    api("account", {}, onAccount)
end sub

sub onRefresh()
    draw()
end sub

sub onAccount(r as object)
    p = m.global.profile
    t = "Using: " + p.name
    if r.ok and isAA(r.data) and r.data.status <> invalid then
        t = t + Chr(10) + "Status: " + toStr(r.data.status) + Chr(10) + "Expires: " + toStr(r.data.expires) + Chr(10) + toStr(r.data.extra)
    end if
    m.account.text = t
end sub

function onOff(v as dynamic) as string
    if isTrue(v) then return "On"
    return "Off"
end function

sub draw()
    st = getSettings()
    pid = toStr(m.global.profile.id)
    rows = []
    for each p in getProfiles()
        if p.id = pid then
            rows.Push(["edit", "Source: " + p.name + "   (in use - select to edit)"])
        else
            rows.Push(["use:" + p.id, "Switch to " + p.name])
        end if
    end for
    rows.Push(["add", "+  Add a source"])
    person = currentPerson()
    pname = ""
    if person <> invalid then pname = toStr(person.name)
    rows.Push(["people", "Switch person  (" + pname + ")"])
    if toStr(st.syncCode) = "" then
        rows.Push(["syncJoin", "Sync across devices:  join with a code"])
        rows.Push(["syncCreate", "Sync across devices:  make a new code"])
    else
        code = toStr(st.syncCode)
        rows.Push(["noop", "Household code:  " + Left(code, 4) + "-" + Mid(code, 5, 4) + "-" + Mid(code, 9)])
        state = "waiting"
        if toStr(st.syncError) <> "" then
            state = toStr(st.syncError)
        else if st.syncLastOk <> invalid and st.syncLastOk > 0 then
            mins = Int((nowMs() - st.syncLastOk) / 60000)
            if mins < 1 then state = "synced just now" else state = "synced " + mins.ToStr() + " min ago"
        end if
        rows.Push(["syncNow", "Sync now  (" + state + ")"])
        rows.Push(["syncLeave", "Stop syncing on this Roku"])
    end if
    if toStr(st.syncCode) = "" and toStr(st.syncError) <> "" then rows.Push(["noop", "Sync: " + toStr(st.syncError)])
    rows.Push(["remove", "Remove the current source"])
    rows.Push(["autoResume", "Resume where I left off:  " + onOff(st.autoResume)])
    rows.Push(["autoplayNext", "Play next episode automatically:  " + onOff(st.autoplayNext)])
    rows.Push(["hideAdult", "Hide adult categories:  " + onOff(st.hideAdult)])
    rows.Push(["cacheDays", "Keep category lists for:  " + toStr(st.cacheDays) + " days"])
    rows.Push(["refreshLists", "Refresh lists now"])
    m.rows = rows
    c = CreateObject("roSGNode", "ContentNode")
    for each r in rows
        n = c.createChild("ContentNode")
        n.title = r[1]
    end for
    f = m.list.itemFocused
    m.list.content = c
    if f > 0 and f < rows.Count() then m.list.jumpToItem = f
end sub

sub onSelect()
    key = m.rows[m.list.itemSelected][0]
    st = getSettings()
    if key = "noop" then
        return
    else if key = "people" then
        m.top.action = { kind: "people" }
        return
    else if key = "syncCreate" then
        m.top.action = { kind: "syncCreate" }
        return
    else if key = "syncNow" then
        m.top.action = { kind: "syncNow" }
        return
    else if key = "syncLeave" then
        m.top.action = { kind: "syncLeave" }
        return
    else if key = "syncJoin" then
        d = CreateObject("roSGNode", "StandardKeyboardDialog")
        d.title = "Household code"
        d.message = ["The code shown in Settings on your phone or PC, e.g. ABCD-EFGH-JKMN"]
        d.buttons = ["Join", "Cancel"]
        d.observeFieldScoped("buttonSelected", "onJoinButton")
        m.dialog = d
        m.top.getScene().dialog = d
        return
    end if
    if startsWith(key, "use:") then
        id = Mid(key, 5)
        for each p in getProfiles()
            if p.id = id then m.top.action = { kind: "switch", profile: p }
        end for
    else if key = "edit" then
        m.top.action = { kind: "editSource", profile: m.global.profile }
    else if key = "add" then
        m.top.action = { kind: "addSource" }
    else if key = "remove" then
        d = CreateObject("roSGNode", "StandardMessageDialog")
        d.title = "Remove " + m.global.profile.name + "?"
        d.message = ["Watch history stays on this Roku."]
        d.buttons = ["Remove", "Cancel"]
        d.observeFieldScoped("buttonSelected", "onRemoveButton")
        m.dialog = d
        m.top.getScene().dialog = d
    else if key = "cacheDays" then
        opts = [1, 3, 7, 14, 30]
        nxt = 7
        for i = 0 to opts.Count() - 1
            if opts[i] = st.cacheDays then nxt = opts[(i + 1) mod opts.Count()]
        end for
        patchSettings({ cacheDays: nxt })
        draw()
    else if key = "refreshLists" then
        m.account.text = "Refreshing..."
        api("refresh", {}, onRefreshed)
    else
        p = {}
        p[key] = not isTrue(st[key])
        patchSettings(p)
        draw()
    end if
end sub

sub onJoinButton()
    d = m.dialog
    choice = d.buttonSelected
    code = d.text.Trim()
    d.close = true
    m.dialog = invalid
    m.list.setFocus(true)
    if choice = 0 and code <> "" then m.top.action = { kind: "syncJoin", code: code }
end sub

sub onRefreshed(r as object)
    m.account.text = "Lists will reload from your provider."
end sub

sub onRemoveButton()
    d = m.dialog
    choice = d.buttonSelected
    d.close = true
    m.dialog = invalid
    m.list.setFocus(true)
    if choice <> 0 then return
    removeProfile(toStr(m.global.profile.id))
    remaining = getProfiles()
    if remaining.Count() > 0 then
        m.top.action = { kind: "switch", profile: remaining[0] }
    else
        m.top.action = { kind: "noSources" }
    end if
end sub
