sub init()
    m.list = m.top.findNode("list")
    m.account = m.top.findNode("account")
    m.list.observeField("itemSelected", "onSelect")
    m.top.observeField("focusedChild", "onFocusChild")
end sub

sub onFocusChild()
    if m.top.hasFocus() then m.list.setFocus(true)
end sub

sub onStart()
    draw()
    m.account.text = "Checking account..."
    api("account", {}, onAccount)
end sub

sub onRefresh()
    draw()
end sub

sub onAccount(r as object)
    p = m.global.profile
    t = "Using: " + p.name
    if r.ok and isAA(r.data) and r.data.status <> invalid then
        t = t + Chr(10) + "Status: " + toStr(r.data.status) + Chr(10) + "Expires: " + toStr(r.data.expires) + Chr(10) + toStr(r.data.extra)
    end if
    m.account.text = t
end sub

function onOff(v as dynamic) as string
    if isTrue(v) then return "On"
    return "Off"
end function

sub draw()
    st = getSettings()
    pid = currentPid()
    rows = []
    for each p in getProfiles()
        if p.id = pid then
            rows.Push(["edit", "Source: " + p.name + "   (in use - select to edit)"])
        else
            rows.Push(["use:" + p.id, "Switch to " + p.name])
        end if
    end for
    rows.Push(["add", "+  Add a source"])
    rows.Push(["remove", "Remove the current source"])
    rows.Push(["autoResume", "Resume where I left off:  " + onOff(st.autoResume)])
    rows.Push(["autoplayNext", "Play next episode automatically:  " + onOff(st.autoplayNext)])
    rows.Push(["hideAdult", "Hide adult categories:  " + onOff(st.hideAdult)])
    rows.Push(["cacheDays", "Keep category lists for:  " + toStr(st.cacheDays) + " days"])
    rows.Push(["refreshLists", "Refresh lists now"])
    m.rows = rows
    c = CreateObject("roSGNode", "ContentNode")
    for each r in rows
        n = c.createChild("ContentNode")
        n.title = r[1]
    end for
    f = m.list.itemFocused
    m.list.content = c
    if f > 0 and f < rows.Count() then m.list.jumpToItem = f
end sub

sub onSelect()
    key = m.rows[m.list.itemSelected][0]
    st = getSettings()
    if startsWith(key, "use:") then
        id = Mid(key, 5)
        for each p in getProfiles()
            if p.id = id then m.top.action = { kind: "switch", profile: p }
        end for
    else if key = "edit" then
        m.top.action = { kind: "editSource", profile: m.global.profile }
    else if key = "add" then
        m.top.action = { kind: "addSource" }
    else if key = "remove" then
        d = CreateObject("roSGNode", "StandardMessageDialog")
        d.title = "Remove " + m.global.profile.name + "?"
        d.message = ["Watch history stays on this Roku."]
        d.buttons = ["Remove", "Cancel"]
        d.observeFieldScoped("buttonSelected", "onRemoveButton")
        m.dialog = d
        m.top.getScene().dialog = d
    else if key = "cacheDays" then
        opts = [1, 3, 7, 14, 30]
        nxt = 7
        for i = 0 to opts.Count() - 1
            if opts[i] = st.cacheDays then nxt = opts[(i + 1) mod opts.Count()]
        end for
        patchSettings({ cacheDays: nxt })
        draw()
    else if key = "refreshLists" then
        m.account.text = "Refreshing..."
        api("refresh", {}, onRefreshed)
    else
        p = {}
        p[key] = not isTrue(st[key])
        patchSettings(p)
        draw()
    end if
end sub

sub onRefreshed(r as object)
    m.account.text = "Lists will reload from your provider."
end sub

sub onRemoveButton()
    d = m.dialog
    choice = d.buttonSelected
    d.close = true
    m.dialog = invalid
    m.list.setFocus(true)
    if choice <> 0 then return
    removeProfile(currentPid())
    remaining = getProfiles()
    if remaining.Count() > 0 then
        m.top.action = { kind: "switch", profile: remaining[0] }
    else
        m.top.action = { kind: "noSources" }
    end if
end sub
