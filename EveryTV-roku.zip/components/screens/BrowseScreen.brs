sub init()
    m.cats = m.top.findNode("cats")
    m.grid = m.top.findNode("grid")
    m.status = m.top.findNode("status")
    m.heading = m.top.findNode("heading")
    m.catTitle = m.top.findNode("catTitle")
    m.timer = m.top.findNode("catTimer")
    m.timer.observeField("fire", "onCatTimer")
    m.cats.observeField("itemFocused", "onCatFocused")
    m.cats.observeField("itemSelected", "onCatSelected")
    m.grid.observeField("itemSelected", "onItemSelected")
    m.grid.observeField("itemFocused", "onItemFocused")
    m.top.observeField("focusedChild", "onFocusChild")
    m.catList = []
    m.current = -1
    m.page = 1
    m.hasMore = false
    m.loadingMore = false
    m.reqToken = 0
end sub

sub onFocusChild()
    if m.top.hasFocus() then m.cats.setFocus(true)
end sub

sub onStart()
    if m.top.ty = "SERIES" then m.heading.text = "Series" else m.heading.text = "Movies"
    m.status.text = "Loading categories..."
    api("cats", { ty: m.top.ty, hideAdult: isTrue(getSettings().hideAdult) }, onCats)
end sub

sub onRefresh()
end sub

sub onCats(r as object)
    if not r.ok then
        m.status.text = r.error
        return
    end if
    scores = categoryScores()
    scored = []
    rest = []
    for each c in r.data
        sc = scores[m.top.ty + "|" + c.id]
        if sc <> invalid and sc > 0 then
            c.score = sc
            scored.Push(c)
        else
            rest.Push(c)
        end if
    end for
    scored.SortBy("score", "r")
    m.catList = scored
    m.catList.Append(rest)
    if m.catList.Count() = 0 then
        m.status.text = "No categories were found on this source."
        return
    end if
    content = CreateObject("roSGNode", "ContentNode")
    for each c in m.catList
        n = content.createChild("ContentNode")
        if c.score <> invalid then n.title = "* " + c.name else n.title = c.name
    end for
    m.cats.content = content
    st = getSettings()
    want = invalid
    if isAA(st.lastCat) then want = st.lastCat[currentPid() + "|" + m.top.ty]
    idx = 0
    if want <> invalid then
        for i = 0 to m.catList.Count() - 1
            if m.catList[i].id = want then idx = i
        end for
    end if
    m.cats.jumpToItem = idx
    loadCat(idx)
end sub

sub onCatFocused()
    m.timer.control = "stop"
    m.timer.control = "start"
end sub

sub onCatTimer()
    if m.cats.itemFocused <> m.current then loadCat(m.cats.itemFocused)
end sub

sub onCatSelected()
    if m.cats.itemSelected <> m.current then loadCat(m.cats.itemSelected)
    if m.grid.content <> invalid and m.grid.content.getChildCount() > 0 then m.grid.setFocus(true)
end sub

sub loadCat(i as integer)
    if i < 0 or i >= m.catList.Count() then return
    m.current = i
    c = m.catList[i]
    m.catTitle.text = c.name
    m.status.text = "Loading..."
    m.status.visible = true
    m.grid.content = CreateObject("roSGNode", "ContentNode")
    m.page = 1
    m.hasMore = false
    m.loadingMore = true
    lc = getSettings().lastCat
    if not isAA(lc) then lc = {}
    lc[currentPid() + "|" + m.top.ty] = c.id
    patchSettings({ lastCat: lc })
    m.reqToken = m.reqToken + 1
    m.catToken = m.reqToken
    api("items", { ty: m.top.ty, cat: c.id, page: 1, force: false }, onItems)
end sub

sub onItems(r as object)
    m.loadingMore = false
    if m.catToken <> m.reqToken then return
    if not r.ok then
        m.status.text = r.error
        return
    end if
    if r.count = 0 and m.page = 1 then
        m.status.text = "Nothing in this category."
        return
    end if
    m.status.visible = false
    m.hasMore = isTrue(r.hasMore)
    content = m.grid.content
    src = r.node
    while src.getChildCount() > 0
        n = src.getChild(0)
        src.removeChild(n)
        content.appendChild(n)
    end while
    if m.page = 1 then m.grid.content = content
end sub

sub onItemFocused()
    if not m.hasMore or m.loadingMore then return
    total = m.grid.content.getChildCount()
    if m.grid.itemFocused >= total - 8 then
        m.loadingMore = true
        m.page = m.page + 1
        api("items", { ty: m.top.ty, cat: m.catList[m.current].id, page: m.page, force: false }, onItems)
    end if
end sub

sub onItemSelected()
    n = m.grid.content.getChild(m.grid.itemSelected)
    if n = invalid or n.item = invalid then return
    m.top.action = { kind: "details", item: n.item }
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "right" and m.cats.hasFocus() then
        if m.grid.content <> invalid and m.grid.content.getChildCount() > 0 then
            m.grid.setFocus(true)
            return true
        end if
    end if
    if key = "left" and m.grid.hasFocus() then
        m.cats.setFocus(true)
        return true
    end if
    if key = "back" and m.grid.hasFocus() then
        m.cats.setFocus(true)
        return true
    end if
    return false
end function
