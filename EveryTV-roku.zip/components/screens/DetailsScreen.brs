sub init()
    m.backdrop = m.top.findNode("backdrop")
    m.poster = m.top.findNode("poster")
    m.title = m.top.findNode("title")
    m.meta = m.top.findNode("meta")
    m.plot = m.top.findNode("plot")
    m.cast = m.top.findNode("cast")
    m.actions = m.top.findNode("actions")
    m.status = m.top.findNode("status")
    m.episodes = m.top.findNode("episodes")
    m.actions.observeField("itemSelected", "onAction")
    m.episodes.observeField("itemSelected", "onEpisode")
    m.top.observeField("focusedChild", "onFocusChild")
    m.eps = []
    m.seasons = []
    m.season = -1
    m.rows = []
end sub

sub onFocusChild()
    if m.top.hasFocus() then m.actions.setFocus(true)
end sub

sub onStart()
    m.it = m.top.item
    show(m.it)
    m.status.text = "Loading..."
    if m.it.ty = "SERIES" then
        api("series", { item: m.it }, onSeries)
    else
        drawActions()
        api("details", { item: m.it }, onDetails)
    end if
end sub

sub onRefresh()
    drawActions()
    drawEpisodes()
end sub

sub show(it as object)
    m.title.text = it.name
    m.poster.uri = it.poster
    bd = it.backdrop
    if bd = invalid or bd = "" then bd = it.poster
    m.backdrop.uri = bd
    meta = []
    for each k in ["year", "rating", "duration", "genre"]
        v = it[k]
        if v <> invalid and toStr(v) <> "" then
            if k = "rating" then meta.Push("Rating " + toStr(v)) else meta.Push(toStr(v))
        end if
    end for
    m.meta.text = meta.Join("     ")
    if it.plot <> invalid then m.plot.text = it.plot
    c = ""
    if it.cast <> invalid and it.cast <> "" then c = "Cast: " + it.cast
    if it.director <> invalid and it.director <> "" then c = c + "     Director: " + it.director
    m.cast.text = c
end sub

sub onDetails(r as object)
    m.status.text = ""
    if r.ok and isAA(r.data) then
        m.it = r.data
        show(m.it)
    end if
end sub

sub onSeries(r as object)
    if not r.ok then
        m.status.text = r.error
        drawActions()
        return
    end if
    m.status.text = ""
    if isAA(r.item) then
        m.it.Append(r.item)
        show(m.it)
    end if
    ' group into seasons, sorted
    bySeason = {}
    m.seasons = []
    for each e in r.eps
        k = toStr(e.season)
        if bySeason[k] = invalid then
            bySeason[k] = []
            m.seasons.Push(e.season)
        end if
        bySeason[k].Push(e)
    end for
    m.seasons.Sort()
    m.eps = []
    for each s in m.seasons
        list = bySeason[toStr(s)]
        list.SortBy("episode")
        m.eps.Append(list)
    end for
    m.plot.height = 100
    m.plot.maxLines = 3
    t = target()
    if t.index >= 0 then m.season = m.eps[t.index].season else m.season = m.seasons[0]
    drawActions()
    drawEpisodes()
end sub

' The episode the main button plays: resume the last one, or move on to the next.
function target() as object
    if m.eps.Count() = 0 then return { index: -1, resume: invalid }
    pid = currentPid()
    for each e in getProgressList()
        if e.pid = pid and e.ty = "SERIES" and e.it.id = m.it.id and e.ep <> invalid then
            for i = 0 to m.eps.Count() - 1
                if m.eps[i].id = e.ep.id then
                    if not isTrue(e.fin) and e.ps > 10 then return { index: i, resume: e }
                    if i + 1 < m.eps.Count() then return { index: i + 1, resume: invalid }
                    return { index: i, resume: invalid }
                end if
            end for
        end if
    end for
    return { index: 0, resume: invalid }
end function

sub drawActions()
    rows = []
    if m.it.ty = "SERIES" then
        t = target()
        if t.index >= 0 then
            e = m.eps[t.index]
            label = "S" + toStr(e.season) + ":E" + toStr(e.episode)
            if t.resume <> invalid then
                rows.Push(["resume", "Resume " + label])
            else
                rows.Push(["resume", "Play " + label])
            end if
        end if
    else
        p = getProgress(m.it, invalid)
        if p <> invalid and not isTrue(p.fin) and p.ps > 10 then
            rows.Push(["play", "Resume " + fmtTime(p.ps)])
            rows.Push(["startover", "Start over"])
        else
            rows.Push(["play", "Play"])
        end if
    end if
    if isFav(m.it) then rows.Push(["fav", "Remove from My List"]) else rows.Push(["fav", "Add to My List"])
    for each s in m.seasons
        mark = ""
        if s = m.season then mark = "> "
        rows.Push(["season:" + toStr(s), mark + "Season " + toStr(s)])
    end for
    m.rows = rows
    c = CreateObject("roSGNode", "ContentNode")
    for each r in rows
        n = c.createChild("ContentNode")
        n.title = r[1]
    end for
    f = m.actions.itemFocused
    m.actions.content = c
    if f > 0 and f < rows.Count() then m.actions.jumpToItem = f
end sub

sub drawEpisodes()
    if m.eps.Count() = 0 then return
    c = CreateObject("roSGNode", "ContentNode")
    m.visIdx = []
    for i = 0 to m.eps.Count() - 1
        e = m.eps[i]
        if e.season = m.season then
            m.visIdx.Push(i)
            p = getProgress(m.it, e)
            extra = { frac: 0, watched: false }
            if p <> invalid then
                if isTrue(p.fin) then extra.watched = true
                if p.dur > 0 then extra.frac = p.ps / p.dur
            end if
            n = c.createChild("ContentNode")
            n.title = toStr(e.episode) + ".  " + e.title
            img = e.image
            if img = invalid or img = "" then img = m.it.poster
            n.HDPosterUrl = img
            o = {}
            o.Append(e)
            o.Append(extra)
            n.addFields({ item: o })
        end if
    end for
    f = m.episodes.itemFocused
    m.episodes.content = c
    if f > 0 and f < c.getChildCount() then m.episodes.jumpToItem = f
end sub

function playlistFrom(index as integer) as object
    list = []
    for each e in m.eps
        list.Push({ item: m.it, ep: e })
    end for
    return list
end function

sub onAction()
    key = m.rows[m.actions.itemSelected][0]
    if key = "play" then
        m.top.action = { kind: "play", list: [{ item: m.it }], index: 0 }
    else if key = "startover" then
        m.top.action = { kind: "play", list: [{ item: m.it }], index: 0, startOver: true }
    else if key = "resume" then
        t = target()
        m.top.action = { kind: "play", list: playlistFrom(t.index), index: t.index }
    else if key = "fav" then
        toggleFav(m.it)
        drawActions()
    else if startsWith(key, "season:") then
        m.season = Mid(key, 8).ToInt()
        drawActions()
        drawEpisodes()
        m.episodes.jumpToItem = 0
        m.episodes.setFocus(true)
    end if
end sub

sub onEpisode()
    i = m.visIdx[m.episodes.itemSelected]
    m.top.action = { kind: "play", list: playlistFrom(i), index: i }
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "right" and m.actions.hasFocus() and m.eps.Count() > 0 then
        m.episodes.setFocus(true)
        return true
    end if
    if (key = "left" or key = "back") and m.episodes.hasFocus() then
        m.actions.setFocus(true)
        return true
    end if
    return false
end function
