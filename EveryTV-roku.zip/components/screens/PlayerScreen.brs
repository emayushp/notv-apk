' Full-screen player: resume, autoplay next episode, live channel zapping, subtitles/audio options.

sub init()
    m.video = m.top.findNode("video")
    m.status = m.top.findNode("status")
    m.banner = m.top.findNode("banner")
    m.bLogo = m.top.findNode("bLogo")
    m.bName = m.top.findNode("bName")
    m.bNum = m.top.findNode("bNum")
    m.bNow = m.top.findNode("bNow")
    m.chPanel = m.top.findNode("chPanel")
    m.chList = m.top.findNode("chList")
    m.optPanel = m.top.findNode("optPanel")
    m.optList = m.top.findNode("optList")
    m.toastLbl = m.top.findNode("toast")
    m.bannerTimer = m.top.findNode("bannerTimer")
    m.toastTimer = m.top.findNode("toastTimer")
    m.bannerTimer.observeField("fire", "hideBanner")
    m.toastTimer.observeField("fire", "hideToast")
    m.video.observeField("state", "onState")
    m.video.observeField("position", "onPosition")
    m.video.positionNotificationPeriod = 5
    m.chList.observeField("itemSelected", "onChannelPicked")
    m.optList.observeField("itemSelected", "onOption")
    m.top.observeField("focusedChild", "onFocusChild")
    m.index = 0
    m.lastSave = 0
    m.variants = []
    m.vi = 0
    m.closed = false
    m.prevIndex = -1
end sub

sub onFocusChild()
    if m.top.hasFocus() then m.video.setFocus(true)
end sub

sub onStart()
    m.list = m.top.playlist
    m.isLive = m.top.live
    m.so = m.top.startOver
    if m.isLive then
        m.video.enableTrickPlay = false
        ' playlist for live is a plain list of channel items
        content = CreateObject("roSGNode", "ContentNode")
        for each ch in m.list
            content.appendChild(itemToNode(ch))
        end for
        m.chList.content = content
    end if
    loadIndex(m.top.index)
end sub

sub onRefresh()
end sub

sub onClosing()
    if not m.top.closing or m.closed then return
    m.closed = true
    saveNow(false)
    m.video.control = "stop"
    cancelApi()
end sub

function curItem() as object
    e = m.list[m.index]
    if m.isLive then return e
    return e.item
end function

function curEp() as dynamic
    if m.isLive then return invalid
    return m.list[m.index].ep
end function

sub loadIndex(i as integer)
    if i < 0 or i >= m.list.Count() then return
    if i <> m.index then
        saveNow(false)
        m.prevIndex = m.index
    end if
    m.index = i
    m.video.control = "stop"
    it = curItem()
    ep = curEp()
    m.status.text = "Loading " + it.name + "..."
    m.status.visible = true
    if m.isLive then
        showBanner(it)
        saveProgress(it, invalid, 0, 0, false)
    else if ep <> invalid then
        toast("S" + toStr(ep.season) + ":E" + toStr(ep.episode) + "  " + ep.title)
    end if
    m.resolveFor = i
    api("resolve", { item: it, ep: ep }, onResolved)
end sub

sub onResolved(r as object)
    if m.closed or m.resolveFor <> m.index then return
    if not r.ok then
        showError(r.error)
        return
    end if
    m.headers = r.headers
    m.variants = variantsFor(r.url)
    m.vi = 0
    startVariant()
end sub

' Ways to try a stream on Roku, best first.
function variantsFor(url as string) as object
    low = LCase(url)
    path = low
    q = Instr(1, path, "?")
    if q > 0 then path = Left(path, q - 1)
    if endsWith(path, ".m3u8") or Instr(1, low, "extension=m3u8") > 0 then return [{ url: url, fmt: "hls" }]
    if endsWith(path, ".mp4") or endsWith(path, ".m4v") or endsWith(path, ".mov") then return [{ url: url, fmt: "mp4" }]
    if endsWith(path, ".mkv") then return [{ url: url, fmt: "mkv" }, { url: url, fmt: "mp4" }]
    if endsWith(path, ".ts") or Instr(1, low, "extension=ts") > 0 then
        if Instr(1, low, "extension=ts") > 0 then
            alt = CreateObject("roRegex", "extension=ts", "i").Replace(url, "extension=m3u8")
        else
            alt = CreateObject("roRegex", "\.ts(\?|$)", "i").Replace(url, ".m3u8\1")
        end if
        return [{ url: alt, fmt: "hls" }, { url: url, fmt: "ts" }, { url: url, fmt: "hls" }]
    end if
    return [{ url: url, fmt: "hls" }, { url: url, fmt: "ts" }, { url: url, fmt: "mp4" }]
end function

sub startVariant()
    v = m.variants[m.vi]
    it = curItem()
    ep = curEp()
    c = CreateObject("roSGNode", "ContentNode")
    c.url = v.url
    c.streamFormat = v.fmt
    c.title = it.name
    if ep <> invalid then c.title = it.name + "  S" + toStr(ep.season) + ":E" + toStr(ep.episode)
    if isArray(m.headers) and m.headers.Count() > 0 then c.HttpHeaders = m.headers
    if m.isLive then
        c.live = true
    else
        st = getSettings()
        p = getProgress(it, ep)
        if not m.so and isTrue(st.autoResume) and p <> invalid and not isTrue(p.fin) and p.ps > 10 then c.PlayStart = p.ps
        m.so = false
    end if
    m.video.content = c
    m.video.control = "play"
end sub

sub onState()
    s = m.video.state
    if s = "playing" then
        m.status.visible = false
    else if s = "buffering" then
        if m.video.position < 1 then m.status.visible = true
    else if s = "error" then
        if m.vi + 1 < m.variants.Count() then
            m.vi = m.vi + 1
            startVariant()
        else
            msg = m.video.errorMsg
            if msg = invalid or msg = "" then msg = "This stream could not be played."
            showError(msg)
        end if
    else if s = "finished" then
        if not m.isLive then
            saveNow(true)
            if isTrue(getSettings().autoplayNext) and m.index + 1 < m.list.Count() then
                loadIndex(m.index + 1)
            else
                m.top.action = { kind: "close" }
            end if
        end if
    end if
end sub

sub onPosition()
    if m.isLive then return
    if m.video.position - m.lastSave >= 30 or m.video.position < m.lastSave then saveNow(false)
end sub

sub saveNow(finished as boolean)
    if m.isLive or m.list = invalid then return
    ps = Int(m.video.position)
    dur = Int(m.video.duration)
    if dur <= 0 or ps < 3 then return
    m.lastSave = ps
    if ps > dur * 0.95 then finished = true
    saveProgress(curItem(), curEp(), ps, dur, finished)
end sub

sub showError(text as string)
    m.status.text = text + Chr(10) + Chr(10) + "OK: try again     Back: close"
    m.status.visible = true
    m.failed = true
end sub

sub showBanner(it as object)
    m.bName.text = it.name
    if it.number <> invalid and it.number > 0 then m.bNum.text = "Channel " + toStr(it.number) else m.bNum.text = ""
    m.bLogo.uri = it.poster
    m.bNow.text = ""
    m.banner.visible = true
    m.bannerTimer.control = "stop"
    m.bannerTimer.control = "start"
    m.epgFor = it.id
    api("epg", { item: it }, onEpg)
end sub

sub onEpg(r as object)
    if m.closed or not m.isLive or curItem().id <> m.epgFor then return
    if not r.ok or not isArray(r.data) then return
    now = CreateObject("roDateTime").AsSeconds()
    t = ""
    for each e in r.data
        if e.start <= now and e.endt > now then t = "Now: " + e.title + "   (until " + fmtClock(e.endt) + ")"
    end for
    if t = "" and r.data.Count() > 0 then t = "Next: " + r.data[0].title + " at " + fmtClock(r.data[0].start)
    m.bNow.text = t
end sub

sub hideBanner()
    m.banner.visible = false
end sub

sub toast(t as string)
    m.toastLbl.text = t
    m.toastLbl.visible = true
    m.toastTimer.control = "stop"
    m.toastTimer.control = "start"
end sub

sub hideToast()
    m.toastLbl.visible = false
end sub

sub zap(d as integer)
    n = m.list.Count()
    if n = 0 then return
    loadIndex((m.index + d + n) mod n)
end sub

sub openChannels()
    m.chPanel.visible = true
    m.chList.jumpToItem = m.index
    m.chList.setFocus(true)
end sub

sub onChannelPicked()
    m.chPanel.visible = false
    m.video.setFocus(true)
    loadIndex(m.chList.itemSelected)
end sub

sub openOptions()
    rows = []
    mode = m.video.globalCaptionMode
    if mode = "On" then rows.Push(["cc:Off", "Subtitles: On  (select to turn off)"]) else rows.Push(["cc:On", "Subtitles: Off  (select to turn on)"])
    tracks = m.video.availableSubtitleTracks
    if isArray(tracks) then
        for each t in tracks
            name = t.Language
            if t.Description <> invalid and t.Description <> "" then name = t.Description
            if name = invalid or name = "" then name = t.TrackName
            mark = ""
            if m.video.subtitleTrack = t.TrackName then mark = "✓ "
            rows.Push(["sub:" + t.TrackName, mark + "Subtitle: " + name])
        end for
    end if
    audio = m.video.availableAudioTracks
    if isArray(audio) and audio.Count() > 1 then
        for each a in audio
            name = a.Name
            if name = invalid or name = "" then name = a.Language
            mark = ""
            if m.video.currentAudioTrack = a.Track then mark = "✓ "
            rows.Push(["aud:" + a.Track, mark + "Audio: " + name])
        end for
    end if
    if m.isLive then
        if isFav(curItem()) then rows.Push(["fav", "Remove from My channels"]) else rows.Push(["fav", "Add to My channels"])
        rows.Push(["list", "Channel list"])
    else if m.list.Count() > 1 then
        if m.index + 1 < m.list.Count() then rows.Push(["next", "Next episode"])
        if m.index > 0 then rows.Push(["prev", "Previous episode"])
    end if
    if not m.isLive then
        if isFav(curItem()) then rows.Push(["fav", "✓ In My List"]) else rows.Push(["fav", "+ My List"])
    end if
    m.optRows = rows
    c = CreateObject("roSGNode", "ContentNode")
    for each r in rows
        n = c.createChild("ContentNode")
        n.title = r[1]
    end for
    m.optList.content = c
    m.optPanel.visible = true
    m.optList.setFocus(true)
end sub

sub closePanels()
    m.optPanel.visible = false
    m.chPanel.visible = false
    m.video.setFocus(true)
end sub

sub onOption()
    key = m.optRows[m.optList.itemSelected][0]
    closePanels()
    if key = "cc:On" then
        m.video.globalCaptionMode = "On"
        toast("Subtitles on")
    else if key = "cc:Off" then
        m.video.globalCaptionMode = "Off"
        toast("Subtitles off")
    else if startsWith(key, "sub:") then
        m.video.subtitleTrack = Mid(key, 5)
        m.video.globalCaptionMode = "On"
    else if startsWith(key, "aud:") then
        m.video.audioTrack = Mid(key, 5)
    else if key = "fav" then
        if toggleFav(curItem()) then toast("Added to My List") else toast("Removed from My List")
    else if key = "list" then
        openChannels()
    else if key = "next" then
        loadIndex(m.index + 1)
    else if key = "prev" then
        loadIndex(m.index - 1)
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if m.optPanel.visible or m.chPanel.visible then
        if key = "back" or key = "options" or (key = "left" and m.optPanel.visible) then
            closePanels()
            return true
        end if
        return false
    end if
    if key = "options" then
        openOptions()
        return true
    end if
    if isTrue(m.failed) and key = "OK" then
        m.failed = false
        loadIndex(m.index)
        return true
    end if
    if m.isLive then
        if key = "up" or key = "channelup" then
            zap(-1)
            return true
        end if
        if key = "down" or key = "channeldown" then
            zap(1)
            return true
        end if
        if key = "OK" or key = "left" or key = "right" then
            openChannels()
            return true
        end if
        if key = "replay" and m.prevIndex >= 0 then
            loadIndex(m.prevIndex)
            return true
        end if
        if key = "play" then
            showBanner(curItem())
            return true
        end if
    end if
    return false
end function
