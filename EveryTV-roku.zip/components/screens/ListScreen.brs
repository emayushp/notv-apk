sub init()
    m.grid = m.top.findNode("grid")
    m.status = m.top.findNode("status")
    m.grid.observeField("itemSelected", "onSelected")
    m.top.observeField("focusedChild", "onFocusChild")
    m.items = []
end sub

sub onFocusChild()
    if m.top.hasFocus() then m.grid.setFocus(true)
end sub

sub onStart()
    build()
end sub

sub onRefresh()
    build()
end sub

sub build()
    pid = currentPid()
    m.items = []
    c = CreateObject("roSGNode", "ContentNode")
    for each f in getFavs()
        if f.pid = pid then
            m.items.Push(f.it)
            c.appendChild(itemToNode(f.it))
        end if
    end for
    m.grid.content = c
    m.status.visible = m.items.Count() = 0
end sub

sub onSelected()
    i = m.grid.itemSelected
    if i < 0 or i >= m.items.Count() then return
    it = m.items[i]
    if it.ty = "LIVE" then
        live = []
        idx = 0
        for each x in m.items
            if x.ty = "LIVE" then
                if x.id = it.id then idx = live.Count()
                live.Push(x)
            end if
        end for
        m.top.action = { kind: "live", list: live, index: idx }
    else
        m.top.action = { kind: "details", item: it }
    end if
end sub
