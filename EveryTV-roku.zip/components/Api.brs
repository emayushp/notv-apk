' Sends a command to the Backend task and calls cb(response) when it answers.
function api(cmd as string, args as object, cb as dynamic) as integer
    g = m.global
    g.reqSeq = g.reqSeq + 1
    id = g.reqSeq
    if m.apiCbs = invalid then
        m.apiCbs = {}
        g.backend.observeFieldScoped("response", "onApiResponse")
    end if
    m.apiCbs[id.ToStr()] = cb
    req = { id: id, cmd: cmd, args: args }
    if g.backend.ready = true then
        g.backend.request = req
    else
        ' the background task is still starting: send once it is listening
        if m.apiQueue = invalid then
            m.apiQueue = []
            g.backend.observeFieldScoped("ready", "onBackendReady")
        end if
        m.apiQueue.Push(req)
    end if
    return id
end function

sub onBackendReady()
    if m.apiQueue = invalid or m.global.backend.ready <> true then return
    q = m.apiQueue
    m.apiQueue = []
    for each req in q
        m.global.backend.request = req
    end for
end sub

sub onApiResponse(ev as object)
    r = ev.getData()
    if not isAA(r) or m.apiCbs = invalid or r.id = invalid then return
    k = toStr(r.id)
    cb = m.apiCbs[k]
    if cb = invalid then return
    m.apiCbs.Delete(k)
    cb(r)
end sub

sub cancelApi()
    m.apiCbs = {}
end sub
