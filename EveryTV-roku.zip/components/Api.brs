' Sends a command to the Backend task and calls cb(response) when it answers.
function api(cmd as string, args as object, cb as dynamic) as integer
    g = m.global
    g.reqSeq = g.reqSeq + 1
    id = g.reqSeq
    if m.apiCbs = invalid then
        m.apiCbs = {}
        g.backend.observeFieldScoped("response", "onApiResponse")
    end if
    m.apiCbs[id.ToStr()] = cb
    g.backend.request = { id: id, cmd: cmd, args: args }
    return id
end function

sub onApiResponse(ev as object)
    r = ev.getData()
    if not isAA(r) or m.apiCbs = invalid or r.id = invalid then return
    k = toStr(r.id)
    cb = m.apiCbs[k]
    if cb = invalid then return
    m.apiCbs.Delete(k)
    cb(r)
end sub

sub cancelApi()
    m.apiCbs = {}
end sub
