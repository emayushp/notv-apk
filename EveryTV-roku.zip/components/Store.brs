' Saved data in the Roku registry (render thread). The registry is small (~16 KB), so lists are trimmed to fit.

function regGet(key as string, fallback as dynamic) as dynamic
    sec = CreateObject("roRegistrySection", "everytv")
    if not sec.Exists(key) then return fallback
    v = ParseJson(sec.Read(key))
    if v = invalid then return fallback
    return v
end function

sub regSetRaw(key as string, json as string)
    sec = CreateObject("roRegistrySection", "everytv")
    sec.Write(key, json)
    sec.Flush()
end sub

sub regSet(key as string, value as dynamic)
    regSetRaw(key, FormatJson(value))
end sub

function getSettings() as object
    d = { lastProfile: "", autoplayNext: true, autoResume: true, hideAdult: true, cacheDays: 7, lastCat: {} }
    s = regGet("settings", {})
    if isAA(s) then
        for each k in s
            d[k] = s[k]
        end for
    end if
    return d
end function

sub patchSettings(p as object)
    s = getSettings()
    for each k in p
        s[k] = p[k]
    end for
    regSet("settings", s)
end sub

function getProfiles() as object
    p = regGet("profiles", [])
    if not isArray(p) then return []
    return p
end function

sub saveProfile(p as object)
    list = getProfiles()
    out = []
    found = false
    for each x in list
        if x.id = p.id then
            out.Push(p)
            found = true
        else
            out.Push(x)
        end if
    end for
    if not found then out.Push(p)
    regSet("profiles", out)
end sub

sub removeProfile(id as string)
    out = []
    for each x in getProfiles()
        if x.id <> id then out.Push(x)
    end for
    regSet("profiles", out)
end sub

function currentPid() as string
    p = m.global.profile
    if p = invalid or p.id = invalid then return ""
    return p.id
end function

function slimItem(it as object) as object
    return { id: it.id, name: it.name, ty: it.ty, cat: it.cat, poster: it.poster, url: it.url, ext: it.ext, extra: it.extra, year: it.year, number: it.number, epg: it.epg }
end function

function slimEp(ep as dynamic) as dynamic
    if ep = invalid then return invalid
    o = { id: ep.id, season: ep.season, episode: ep.episode, title: Left(ep.title, 60), url: ep.url, dur: ep.dur }
    if ep.ext <> invalid then o.ext = ep.ext
    return o
end function

function progKey(it as object, ep as dynamic) as string
    if ep <> invalid then return currentPid() + "|e|" + it.id + "|" + ep.id
    return currentPid() + "|" + it.ty + "|" + it.id
end function

function getProgressList() as object
    l = regGet("progress", [])
    if not isArray(l) then return []
    return l
end function

function getProgress(it as object, ep as dynamic) as dynamic
    k = progKey(it, ep)
    for each e in getProgressList()
        if e.k = k then return e
    end for
    return invalid
end function

sub saveProgress(it as object, ep as dynamic, ps as integer, dur as integer, finished as boolean)
    k = progKey(it, ep)
    entry = { k: k, pid: currentPid(), ty: it.ty, it: slimItem(it), ps: ps, dur: dur, at: CreateObject("roDateTime").AsSeconds(), fin: finished }
    if ep <> invalid then entry.ep = slimEp(ep)
    list = [entry]
    for each e in getProgressList()
        if e.k <> k then list.Push(e)
    end for
    json = FormatJson(list)
    while Len(json) > 8500 and list.Count() > 1
        list.Pop()
        json = FormatJson(list)
    end while
    regSetRaw("progress", json)
end sub

' Category scores from watch history: recent and finished titles count more.
function categoryScores() as object
    pid = currentPid()
    now = CreateObject("roDateTime").AsSeconds()
    out = {}
    for each e in getProgressList()
        if e.pid = pid and e.it <> invalid and e.it.cat <> invalid and e.it.cat <> "" then
            w = 1.0
            if e.dur <> invalid and e.dur > 0 then
                f = e.ps / e.dur
                if f > 1 then f = 1
                w = w + f * 2
            end if
            if isTrue(e.fin) then w = w + 1
            age = (now - e.at) / 86400
            if age < 7 then
                w = w + 2
            else if age < 30 then
                w = w + 1
            end if
            key = e.ty + "|" + e.it.cat
            if out[key] = invalid then out[key] = 0
            out[key] = out[key] + w
        end if
    end for
    return out
end function

function getFavs() as object
    l = regGet("favs", [])
    if not isArray(l) then return []
    return l
end function

function isFav(it as object) as boolean
    pid = currentPid()
    for each f in getFavs()
        if f.pid = pid and f.it.id = it.id and f.it.ty = it.ty then return true
    end for
    return false
end function

' Returns true when the item is now in My List.
function toggleFav(it as object) as boolean
    pid = currentPid()
    was = false
    out = []
    for each f in getFavs()
        if f.pid = pid and f.it.id = it.id and f.it.ty = it.ty then
            was = true
        else
            out.Push(f)
        end if
    end for
    if not was then out.Unshift({ pid: pid, it: slimItem(it) })
    json = FormatJson(out)
    while Len(json) > 5000 and out.Count() > 1
        out.Pop()
        json = FormatJson(out)
    end while
    regSetRaw("favs", json)
    return not was
end function

function itemToNode(it as object, extra = invalid as dynamic) as object
    n = CreateObject("roSGNode", "ContentNode")
    n.title = it.name
    n.HDPosterUrl = it.poster
    n.FHDPosterUrl = it.poster
    o = it
    if extra <> invalid then
        o = {}
        o.Append(it)
        o.Append(extra)
    end if
    n.addFields({ item: o })
    return n
end function

function fmtTime(sec as integer) as string
    if sec < 0 then sec = 0
    h = Int(sec / 3600)
    mm = Int((sec mod 3600) / 60)
    ss = sec mod 60
    m2 = mm.ToStr()
    if Len(m2) < 2 and h > 0 then m2 = "0" + m2
    s2 = ss.ToStr()
    if Len(s2) < 2 then s2 = "0" + s2
    if h > 0 then return h.ToStr() + ":" + m2 + ":" + s2
    return m2 + ":" + s2
end function

function fmtClock(sec as integer) as string
    d = CreateObject("roDateTime")
    d.FromSeconds(sec)
    d.ToLocalTime()
    h = d.GetHours()
    mi = d.GetMinutes()
    ampm = "AM"
    if h >= 12 then ampm = "PM"
    h = h mod 12
    if h = 0 then h = 12
    m2 = mi.ToStr()
    if Len(m2) < 2 then m2 = "0" + m2
    return h.ToStr() + ":" + m2 + " " + ampm
end function
