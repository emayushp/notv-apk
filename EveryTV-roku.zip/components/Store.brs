' Saved data in the Roku registry (render thread). The registry is small (~16 KB), so lists are trimmed to fit.

function regGet(key as string, fallback as dynamic) as dynamic
    sec = CreateObject("roRegistrySection", "everytv")
    if not sec.Exists(key) then return fallback
    v = ParseJson(sec.Read(key))
    if v = invalid then return fallback
    return v
end function

sub regSetRaw(key as string, json as string)
    sec = CreateObject("roRegistrySection", "everytv")
    sec.Write(key, json)
    sec.Flush()
end sub

sub regSet(key as string, value as dynamic)
    regSetRaw(key, FormatJson(value))
end sub

function getSettings() as object
    d = { lastProfile: "", autoplayNext: true, autoResume: true, hideAdult: true, cacheDays: 7, lastCat: {}, person: "", syncUrl: "https://everytv-sync.ayush1121998.workers.dev", syncCode: "", syncCursor: 0, syncLastOk: 0, syncError: "" }
    s = regGet("settings", {})
    if isAA(s) then
        for each k in s
            d[k] = s[k]
        end for
    end if
    return d
end function

sub patchSettings(p as object)
    s = getSettings()
    for each k in p
        s[k] = p[k]
    end for
    regSet("settings", s)
end sub

function getProfiles() as object
    p = regGet("profiles", [])
    if not isArray(p) then return []
    return p
end function

sub saveProfile(p as object)
    list = getProfiles()
    out = []
    found = false
    for each x in list
        if x.id = p.id then
            out.Push(p)
            found = true
        else
            out.Push(x)
        end if
    end for
    if not found then out.Push(p)
    regSet("profiles", out)
end sub

sub removeProfile(id as string)
    out = []
    for each x in getProfiles()
        if x.id <> id then out.Push(x)
    end for
    regSet("profiles", out)
end sub

' Whose history / list we're showing: "<personId>~<source fingerprint>".
' The fingerprint is the same on the phone and PC apps, so progress can move between them.
function currentPid() as string
    sc = m.global.scope
    if sc = invalid then return ""
    return sc
end function

function sha1Hex(s as string) as string
    ba = CreateObject("roByteArray")
    ba.FromAsciiString(s)
    d = CreateObject("roEVPDigest")
    d.Setup("sha1")
    return d.Process(ba)
end function

function sourceFp(p as object) as string
    kind = p["type"]
    if kind = "XTREAM" then
        basis = "xtream:" + LCase(toStr(p.username).Trim())
    else if kind = "M3U" then
        basis = "m3u:" + LCase(toStr(p.url).Trim())
    else
        basis = "stalker:" + UCase(toStr(p.mac).Trim())
    end if
    return Left(sha1Hex(basis), 10)
end function

function nowMs() as longinteger
    return CreateObject("roDateTime").AsSeconds() * 1000&
end function

function msToSec(v as dynamic) as dynamic
    if v = invalid then return 0
    t = type(v)
    if t = "roInt" or t = "Integer" or t = "roInteger" or t = "LongInteger" or t = "roLongInteger" then return v \ 1000
    return Int(v / 1000)
end function

' ---------- people ----------

function getPeople() as object
    l = regGet("people", [])
    if not isArray(l) then return []
    return l
end function

function currentPerson() as dynamic
    id = toStr(getSettings().person)
    for each p in getPeople()
        if p.id = id then return p
    end for
    return invalid
end function

function newId() as string
    u = LCase(CreateObject("roDeviceInfo").GetRandomUUID())
    return Left(u.Replace("-", ""), 10)
end function

sub savePerson(p as object)
    out = []
    found = false
    for each x in getPeople()
        if x.id = p.id then
            out.Push(p)
            found = true
        else
            out.Push(x)
        end if
    end for
    if not found then out.Push(p)
    regSet("people", out)
    queueSync("p|" + p.id, false)
end sub

' Remove a person with their history and list (on every synced device).
sub deletePerson(id as string)
    out = []
    for each x in getPeople()
        if x.id <> id then out.Push(x)
    end for
    regSet("people", out)
    queueSync("p|" + id, true)
    purgePerson(id)
    if toStr(getSettings().person) = id then patchSettings({ person: "" })
end sub

sub purgePerson(id as string)
    pre = id + "~"
    keep = []
    for each e in getProgressList()
        if not startsWith(toStr(e.pid), pre) then keep.Push(e)
    end for
    regSet("progress", keep)
    keepF = []
    for each f in getFavs()
        if not startsWith(toStr(f.pid), pre) then keepF.Push(f)
    end for
    regSet("favs", keepF)
end sub

' Two devices met the same person: move this one's history to the other id.
sub renamePersonId(fromId as string, toId as string)
    if fromId = toId then return
    pre = fromId + "~"
    l = getProgressList()
    for each e in l
        if startsWith(toStr(e.pid), pre) then
            e.pid = toId + Mid(e.pid, Len(fromId) + 1)
            e.k = toId + Mid(e.k, Len(fromId) + 1)
        end if
    end for
    regSet("progress", l)
    f = getFavs()
    for each x in f
        if startsWith(toStr(x.pid), pre) then x.pid = toId + Mid(x.pid, Len(fromId) + 1)
    end for
    regSet("favs", f)
    out = []
    for each p in getPeople()
        if p.id <> fromId then out.Push(p)
    end for
    regSet("people", out)
    if toStr(getSettings().person) = fromId then patchSettings({ person: toId })
end sub

' Before people existed, history belonged to the IPTV source. Give it to a first person.
sub migrateToPeople()
    if getPeople().Count() > 0 then return
    me = { id: newId(), name: "Me", color: 0, updatedAt: nowMs() }
    regSet("people", [me])
    fps = {}
    for each p in getProfiles()
        fps[p.id] = sourceFp(p)
    end for
    l = getProgressList()
    for each e in l
        old = toStr(e.pid)
        if Instr(1, old, "~") = 0 then
            fp = fps[old]
            if fp = invalid then fp = old
            sc = me.id + "~" + fp
            tail = Mid(toStr(e.k), Len(old) + 2)
            if startsWith(tail, "MOVIE|") then tail = "m|" + Mid(tail, 7)
            if startsWith(tail, "LIVE|") then tail = "l|" + Mid(tail, 6)
            if startsWith(tail, "SERIES|") then tail = "s|" + Mid(tail, 8)
            e.pid = sc
            e.k = sc + "|" + tail
        end if
    end for
    regSet("progress", l)
    f = getFavs()
    for each x in f
        old = toStr(x.pid)
        if Instr(1, old, "~") = 0 then
            fp = fps[old]
            if fp = invalid then fp = old
            x.pid = me.id + "~" + fp
        end if
    end for
    regSet("favs", f)
end sub

' ---------- sync queue (only keys; values are read fresh when sending) ----------

sub queueSync(k as string, del as boolean)
    if toStr(getSettings().syncCode) = "" then return
    q = regGet("syncq", {})
    if not isAA(q) then q = {}
    q[k] = { ct: nowMs(), del: del }
    ' keep the registry small: drop the oldest when the queue grows
    while q.Count() > 60
        oldK = invalid
        oldT = invalid
        for each kk in q
            if oldT = invalid or q[kk].ct < oldT then
                oldT = q[kk].ct
                oldK = kk
            end if
        end for
        q.Delete(oldK)
    end while
    regSet("syncq", q)
end sub

function getSyncQueue() as object
    q = regGet("syncq", {})
    if not isAA(q) then return {}
    return q
end function

function slimItem(it as object) as object
    return { id: it.id, name: it.name, ty: it.ty, cat: it.cat, poster: it.poster, url: it.url, ext: it.ext, extra: it.extra, year: it.year, number: it.number, epg: it.epg }
end function

function slimEp(ep as dynamic) as dynamic
    if ep = invalid then return invalid
    o = { id: ep.id, season: ep.season, episode: ep.episode, title: Left(ep.title, 60), url: ep.url, dur: ep.dur }
    if ep.ext <> invalid then o.ext = ep.ext
    return o
end function

function progKey(it as object, ep as dynamic) as string
    if ep <> invalid then return currentPid() + "|e|" + it.id + "|" + ep.id
    letter = "m"
    if it.ty = "LIVE" then letter = "l"
    if it.ty = "SERIES" then letter = "s"
    return currentPid() + "|" + letter + "|" + it.id
end function

function getProgressList() as object
    l = regGet("progress", [])
    if not isArray(l) then return []
    return l
end function

function getProgress(it as object, ep as dynamic) as dynamic
    k = progKey(it, ep)
    for each e in getProgressList()
        if e.k = k then return e
    end for
    return invalid
end function

sub saveProgress(it as object, ep as dynamic, ps as integer, dur as integer, finished as boolean)
    k = progKey(it, ep)
    entry = { k: k, pid: currentPid(), ty: it.ty, it: slimItem(it), ps: ps, dur: dur, at: CreateObject("roDateTime").AsSeconds(), fin: finished }
    if ep <> invalid then entry.ep = slimEp(ep)
    list = [entry]
    for each e in getProgressList()
        if e.k <> k then list.Push(e)
    end for
    saveProgressList(list)
    queueSync(syncKeyForLocal(k), false)
end sub

sub saveProgressList(list as object)
    json = FormatJson(list)
    while Len(json) > 6500 and list.Count() > 1
        list.Pop()
        json = FormatJson(list)
    end while
    regSetRaw("progress", json)
end sub

' "<person>~<fp>|m|123" -> "w|<person>|<fp>|m|123"
function syncKeyForLocal(k as string) as string
    bar = Instr(1, k, "|")
    if bar = 0 then return ""
    sc = Left(k, bar - 1)
    t = Instr(1, sc, "~")
    if t = 0 then return ""
    return "w|" + Left(sc, t - 1) + "|" + Mid(sc, t + 1) + "|" + Mid(k, bar + 1)
end function

' Category scores from watch history: recent and finished titles count more.
function categoryScores() as object
    pid = currentPid()
    now = CreateObject("roDateTime").AsSeconds()
    out = {}
    for each e in getProgressList()
        if e.pid = pid and e.it <> invalid and e.it.cat <> invalid and e.it.cat <> "" then
            w = 1.0
            if e.dur <> invalid and e.dur > 0 then
                f = e.ps / e.dur
                if f > 1 then f = 1
                w = w + f * 2
            end if
            if isTrue(e.fin) then w = w + 1
            age = (now - e.at) / 86400
            if age < 7 then
                w = w + 2
            else if age < 30 then
                w = w + 1
            end if
            key = e.ty + "|" + e.it.cat
            if out[key] = invalid then out[key] = 0
            out[key] = out[key] + w
        end if
    end for
    return out
end function

function getFavs() as object
    l = regGet("favs", [])
    if not isArray(l) then return []
    return l
end function

function isFav(it as object) as boolean
    pid = currentPid()
    for each f in getFavs()
        if f.pid = pid and f.it.id = it.id and f.it.ty = it.ty then return true
    end for
    return false
end function

' Returns true when the item is now in My List.
function toggleFav(it as object) as boolean
    pid = currentPid()
    was = false
    out = []
    for each f in getFavs()
        if f.pid = pid and f.it.id = it.id and f.it.ty = it.ty then
            was = true
        else
            out.Push(f)
        end if
    end for
    if not was then out.Unshift({ pid: pid, it: slimItem(it), at: nowMs() })
    saveFavList(out)
    t = Instr(1, pid, "~")
    if t > 0 then queueSync("f|" + Left(pid, t - 1) + "|" + Mid(pid, t + 1) + "|" + it.ty + "|" + it.id, was)
    return not was
end function

sub saveFavList(out as object)
    json = FormatJson(out)
    while Len(json) > 3200 and out.Count() > 1
        out.Pop()
        json = FormatJson(out)
    end while
    regSetRaw("favs", json)
end sub

function itemToNode(it as object, extra = invalid as dynamic) as object
    n = CreateObject("roSGNode", "ContentNode")
    n.title = it.name
    n.HDPosterUrl = it.poster
    n.FHDPosterUrl = it.poster
    o = it
    if extra <> invalid then
        o = {}
        o.Append(it)
        o.Append(extra)
    end if
    n.addFields({ item: o })
    return n
end function

function fmtTime(sec as integer) as string
    if sec < 0 then sec = 0
    h = Int(sec / 3600)
    mm = Int((sec mod 3600) / 60)
    ss = sec mod 60
    m2 = mm.ToStr()
    if Len(m2) < 2 and h > 0 then m2 = "0" + m2
    s2 = ss.ToStr()
    if Len(s2) < 2 then s2 = "0" + s2
    if h > 0 then return h.ToStr() + ":" + m2 + ":" + s2
    return m2 + ":" + s2
end function

function fmtClock(sec as integer) as string
    d = CreateObject("roDateTime")
    d.FromSeconds(sec)
    d.ToLocalTime()
    h = d.GetHours()
    mi = d.GetMinutes()
    ampm = "AM"
    if h >= 12 then ampm = "PM"
    h = h mod 12
    if h = 0 then h = 12
    m2 = mi.ToStr()
    if Len(m2) < 2 then m2 = "0" + m2
    return h.ToStr() + ":" + m2 + " " + ampm
end function
