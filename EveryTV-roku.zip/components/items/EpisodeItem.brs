sub init()
    m.thumb = m.top.findNode("thumb")
    m.title = m.top.findNode("title")
    m.plot = m.top.findNode("plot")
    m.rightLbl = m.top.findNode("right")
    m.progBg = m.top.findNode("progBg")
    m.prog = m.top.findNode("prog")
end sub

sub onContent()
    c = m.top.itemContent
    if c = invalid then return
    e = c.item
    m.title.text = c.title
    m.thumb.uri = c.HDPosterUrl
    m.plot.text = ""
    m.rightLbl.text = ""
    m.progBg.visible = false
    m.prog.visible = false
    if e = invalid then return
    if e.plot <> invalid then m.plot.text = e.plot
    if e.dur <> invalid and e.dur > 0 then m.rightLbl.text = Int(e.dur / 60).ToStr() + " min"
    if isTrue(e.watched) then m.rightLbl.text = "Watched"
    if e.frac <> invalid and e.frac > 0 then
        m.progBg.visible = true
        m.prog.visible = true
        f = e.frac
        if f > 1 then f = 1
        m.prog.width = 224 * f
    end if
end sub
