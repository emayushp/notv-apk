sub init()
    m.num = m.top.findNode("num")
    m.logo = m.top.findNode("logo")
    m.name = m.top.findNode("name")
    m.star = m.top.findNode("star")
end sub

sub onContent()
    c = m.top.itemContent
    if c = invalid then return
    it = c.item
    m.name.text = c.title
    m.logo.uri = c.HDPosterUrl
    m.num.text = ""
    m.star.text = ""
    if it <> invalid then
        if it.number <> invalid and it.number > 0 then m.num.text = it.number.ToStr()
        if isTrue(it.fav) then m.star.text = "★"
    end if
end sub

sub onFocusPct()
    if m.top.focusPercent > 0.5 then
        m.name.color = "0xFFFFFFFF"
    else
        m.name.color = "0xDDDDDDFF"
    end if
end sub
