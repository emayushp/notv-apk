sub init()
    m.ring = m.top.findNode("ring")
    m.box = m.top.findNode("box")
    m.letter = m.top.findNode("letter")
    m.name = m.top.findNode("name")
end sub

sub onContent()
    c = m.top.itemContent
    if c = invalid then return
    m.name.text = c.title
    m.letter.text = c.shortDescriptionLine1
    m.box.color = c.shortDescriptionLine2
end sub

sub onFocus()
    f = m.top.focusPercent
    if f > 0.5 then
        m.ring.color = "0xFFFFFFFF"
        m.name.color = "0xFFFFFFFF"
    else
        m.ring.color = "0xFFFFFF00"
        m.name.color = "0xAAAAAAFF"
    end if
end sub
