sub init()
    m.ph = m.top.findNode("ph")
    m.initials = m.top.findNode("initials")
    m.poster = m.top.findNode("poster")
    m.progBg = m.top.findNode("progBg")
    m.prog = m.top.findNode("prog")
    m.title = m.top.findNode("title")
    m.subLbl = m.top.findNode("sub")
    m.poster.observeField("loadStatus", "onLoad")
    m.frac = -1
    m.top.width = 260
    m.top.height = 450
end sub

sub layout()
    w = m.top.width
    h = m.top.height
    if w <= 0 or h <= 0 then return
    ph = h - 64
    m.ph.width = w
    m.ph.height = ph
    m.poster.width = w
    m.poster.height = ph
    m.initials.width = w
    m.initials.height = ph
    m.progBg.translation = [0, ph - 8]
    m.progBg.width = w
    m.progBg.height = 8
    m.prog.translation = [0, ph - 8]
    m.prog.height = 8
    m.title.translation = [4, ph + 6]
    m.title.width = w - 8
    m.subLbl.translation = [4, ph + 36]
    m.subLbl.width = w - 8
    showProg()
end sub

sub onContent()
    c = m.top.itemContent
    if c = invalid then return
    it = c.item
    name = c.title
    live = false
    label = ""
    m.frac = -1
    if it <> invalid then
        live = it.ty = "LIVE"
        if it.label <> invalid then label = it.label
        if it.frac <> invalid then m.frac = it.frac
        if label = "" then
            if it.year <> invalid and it.year <> "" then label = it.year
            if it.rating <> invalid and it.rating <> "" then
                if label <> "" then label = label + "  "
                label = label + "★ " + it.rating
            end if
        end if
    end if
    m.title.text = name
    m.subLbl.text = label
    initials = ""
    for each w in name.Split(" ")
        if Len(initials) < 2 and w <> "" then initials = initials + UCase(Left(w, 1))
    end for
    m.initials.text = initials
    if live then
        m.poster.loadDisplayMode = "scaleToFit"
        m.ph.color = "0x161616FF"
    else
        m.poster.loadDisplayMode = "scaleToZoom"
        m.ph.color = "0x262626FF"
    end if
    m.poster.uri = c.HDPosterUrl
    m.initials.visible = true
    showProg()
end sub

sub onLoad()
    m.initials.visible = m.poster.loadStatus <> "ready"
end sub

sub showProg()
    if m.frac < 0 then
        m.progBg.visible = false
        m.prog.visible = false
        return
    end if
    f = m.frac
    if f > 1 then f = 1
    m.progBg.visible = true
    m.prog.visible = true
    m.prog.width = m.top.width * f
end sub

sub onFocusPct()
    p = m.top.focusPercent
    m.title.color = "0xCCCCCCFF"
    if p > 0.5 then m.title.color = "0xFFFFFFFF"
end sub
