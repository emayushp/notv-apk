' Navigation: left menu, a stack of screens, connecting to the source.

sub init()
    m.global.addFields({ reqSeq: 0 })
    m.global.addField("backend", "node", false)
    m.global.addField("profile", "assocarray", false)
    m.backend = CreateObject("roSGNode", "Backend")
    m.global.backend = m.backend
    m.backend.control = "RUN"

    m.content = m.top.findNode("content")
    m.full = m.top.findNode("full")
    m.nav = m.top.findNode("nav")
    m.menu = m.top.findNode("menu")
    m.splash = m.top.findNode("splash")
    m.splashText = m.top.findNode("splashText")
    m.profileLabel = m.top.findNode("profileLabel")

    m.tabs = [["HomeScreen", "Home"], ["LiveScreen", "Live TV"], ["BrowseMovies", "Movies"], ["BrowseSeries", "Series"], ["SearchScreen", "Search"], ["ListScreen", "My List"], ["SettingsScreen", "Settings"]]
    mc = CreateObject("roSGNode", "ContentNode")
    for each t in m.tabs
        c = mc.createChild("ContentNode")
        c.title = t[1]
    end for
    m.menu.content = mc
    m.menu.observeField("itemSelected", "onMenu")
    m.stack = []
    m.connected = false
    boot()
end sub

sub boot()
    profiles = getProfiles()
    if profiles.Count() = 0 then
        openLogin(invalid, "", true)
        return
    end if
    st = getSettings()
    p = profiles[0]
    for each x in profiles
        if x.id = st.lastProfile then p = x
    end for
    connect(p, false)
end sub

' ---------- connecting ----------

sub connect(p as object, fromLogin as boolean)
    m.pending = p
    m.pendingFromLogin = fromLogin
    if not fromLogin then
        m.splashText.text = "Connecting to " + p.name + "..."
        m.splash.visible = true
        m.splash.setFocus(true)
    end if
    api("connect", { profile: p, cacheDays: getSettings().cacheDays }, onConnected)
end sub

sub onConnected(r as object)
    p = m.pending
    m.splash.visible = false
    if not r.ok then
        if m.pendingFromLogin and m.stack.Count() > 0 then
            top = m.stack.Peek().node
            top.errorText = r.error
            top.busy = false
        else
            openLogin(p, r.error, true)
        end if
        return
    end if
    saveProfile(p)
    patchSettings({ lastProfile: p.id })
    m.global.profile = p
    m.connected = true
    m.profileLabel.text = p.name
    clearStack()
    m.nav.visible = true
    m.menu.jumpToItem = 0
    setRoot(0)
end sub

sub openLogin(p as dynamic, err as string, asRoot as boolean)
    fields = { errorText: err, canCancel: not asRoot and m.connected }
    if p <> invalid then fields.profile = p
    if asRoot then
        clearStack()
        m.nav.visible = false
    end if
    push("LoginScreen", fields, true)
end sub

' ---------- screen stack ----------

function makeScreen(name as string, fields as object) as object
    comp = name
    if name = "BrowseMovies" or name = "BrowseSeries" then comp = "BrowseScreen"
    s = CreateObject("roSGNode", comp)
    if name = "BrowseMovies" then s.ty = "MOVIE"
    if name = "BrowseSeries" then s.ty = "SERIES"
    s.setFields(fields)
    s.observeField("action", "onAction")
    return s
end function

sub clearStack()
    while m.stack.Count() > 0
        e = m.stack.Pop()
        e.node.closing = true
        e.node.getParent().removeChild(e.node)
    end while
end sub

sub setRoot(index as integer)
    clearStack()
    s = makeScreen(m.tabs[index][0], {})
    s.start = true
    m.content.appendChild(s)
    m.stack.Push({ node: s, full: false })
    s.setFocus(true)
end sub

sub push(name as string, fields as object, full as boolean)
    if m.stack.Count() > 0 then m.stack.Peek().node.visible = false
    s = makeScreen(name, fields)
    if full then
        m.full.appendChild(s)
        m.nav.visible = false
    else
        m.content.appendChild(s)
    end if
    m.stack.Push({ node: s, full: full })
    s.start = true
    s.setFocus(true)
end sub

sub pop()
    if m.stack.Count() <= 1 then return
    e = m.stack.Pop()
    e.node.closing = true
    e.node.getParent().removeChild(e.node)
    prev = m.stack.Peek()
    prev.node.visible = true
    m.nav.visible = m.connected and not prev.full
    prev.node.setFocus(true)
    prev.node.refresh = true
end sub

sub onMenu()
    setRoot(m.menu.itemSelected)
end sub

sub onAction(ev as object)
    a = ev.getData()
    if not isAA(a) then return
    k = a.kind
    if k = "close" then
        pop()
    else if k = "details" then
        push("DetailsScreen", { item: a.item }, false)
    else if k = "play" then
        f = { playlist: a.list, index: a.index, live: false }
        if isTrue(a.startOver) then f.startOver = true
        push("PlayerScreen", f, true)
    else if k = "live" then
        push("PlayerScreen", { playlist: a.list, index: a.index, live: true }, true)
    else if k = "connect" then
        connect(a.profile, true)
    else if k = "switch" then
        connect(a.profile, false)
    else if k = "addSource" then
        openLogin(invalid, "", false)
    else if k = "editSource" then
        openLogin(a.profile, "", false)
    else if k = "menu" then
        if m.nav.visible then m.menu.setFocus(true)
    else if k = "noSources" then
        m.connected = false
        openLogin(invalid, "", true)
    else if k = "reload" then
        setRoot(m.menu.itemFocused)
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back" then
        if m.splash.visible then return true
        if m.stack.Count() > 1 then
            pop()
            return true
        end if
        if m.nav.visible and not m.menu.hasFocus() then
            m.menu.setFocus(true)
            return true
        end if
        return false
    end if
    if key = "left" and m.nav.visible and not m.menu.hasFocus() then
        m.menu.setFocus(true)
        return true
    end if
    if key = "right" and m.menu.hasFocus() and m.stack.Count() > 0 then
        m.stack.Peek().node.setFocus(true)
        return true
    end if
    return false
end function
