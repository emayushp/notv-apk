' Navigation: left menu, a stack of screens, connecting to the source.

sub init()
    m.global.addFields({ reqSeq: 0 })
    m.global.addField("backend", "node", false)
    m.global.addField("profile", "assocarray", false)
    m.global.addField("scope", "string", false)
    m.backend = CreateObject("roSGNode", "Backend")
    m.global.backend = m.backend
    m.backend.control = "RUN"

    m.content = m.top.findNode("content")
    m.full = m.top.findNode("full")
    m.nav = m.top.findNode("nav")
    m.menu = m.top.findNode("menu")
    m.splash = m.top.findNode("splash")
    m.splashText = m.top.findNode("splashText")
    m.profileLabel = m.top.findNode("profileLabel")

    m.tabs = [["HomeScreen", "Home"], ["LiveScreen", "Live TV"], ["BrowseMovies", "Movies"], ["BrowseSeries", "Series"], ["SearchScreen", "Search"], ["ListScreen", "My List"], ["SettingsScreen", "Settings"]]
    mc = CreateObject("roSGNode", "ContentNode")
    for each t in m.tabs
        c = mc.createChild("ContentNode")
        c.title = t[1]
    end for
    m.menu.content = mc
    m.menu.observeField("itemSelected", "onMenu")
    m.stack = []
    m.connected = false
    m.connecting = false
    m.personPicked = false
    m.syncTimer = CreateObject("roSGNode", "Timer")
    m.syncTimer.duration = 90
    m.syncTimer.repeat = true
    m.syncTimer.observeField("fire", "syncRun")
    m.syncTimer.control = "start"
    boot()
end sub

sub boot()
    migrateToPeople()
    patchSettings({ person: "" })   ' Netflix-style: ask who's watching every time
    profiles = getProfiles()
    if profiles.Count() = 0 then
        openLogin(invalid, "", true)
        return
    end if
    showPeople()
    ' connect in the background while someone picks a profile
    connect(lastSource(), true, true)
    syncRun()
end sub

function lastSource() as dynamic
    profiles = getProfiles()
    if profiles.Count() = 0 then return invalid
    st = getSettings()
    p = profiles[0]
    for each x in profiles
        if x.id = st.lastProfile then p = x
    end for
    return p
end function

' ---------- people ----------

sub updateScope()
    person = currentPerson()
    p = m.global.profile
    if person <> invalid and isAA(p) and p.id <> invalid then
        m.global.scope = person.id + "~" + sourceFp(p)
        m.profileLabel.text = toStr(person.name) + Chr(10) + toStr(p.name)
    else
        m.global.scope = ""
    end if
end sub

sub showPeople()
    clearStack()
    m.nav.visible = false
    m.personPicked = false
    push("PeopleScreen", {}, true)
    if m.connecting then m.stack.Peek().node.statusText = "Connecting to your TV service..."
end sub

sub choosePerson(person as object)
    patchSettings({ person: person.id })
    m.personPicked = true
    updateScope()
    if m.connected then
        enterHome()
    else if m.connecting then
        m.splashText.text = "Connecting..."
        m.splash.visible = true
        m.splash.setFocus(true)
    else
        p = lastSource()
        if p = invalid then
            openLogin(invalid, "", true)
        else
            connect(p, false)
        end if
    end if
    syncRun()
end sub

sub enterHome()
    m.splash.visible = false
    clearStack()
    m.nav.visible = true
    m.menu.jumpToItem = 0
    setRoot(0)
end sub

' ---------- sync ----------

sub syncRun()
    st = getSettings()
    if toStr(st.syncCode) = "" or m.syncBusy = true then return
    out = buildOutgoing()
    m.syncSent = out.sent
    m.syncBusy = true
    since = st.syncCursor
    if since = invalid then since = 0
    since = since - 5000
    if since < 0 then since = 0
    api("sync", { url: st.syncUrl, code: st.syncCode, since: since, changes: out.changes }, onSynced)
end sub

sub onSynced(r as object)
    m.syncBusy = false
    if not r.ok then
        patchSettings({ syncError: toStr(r.error) })
        tellSettings()
        return
    end if
    clearSent(m.syncSent)
    got = applySync(r.data.changes)
    patch = { syncLastOk: nowMs(), syncError: "" }
    if r.data.now <> invalid then patch.syncCursor = r.data.now
    patchSettings(patch)
    tellSettings()
    if got then refreshQuietly()
    if m.syncRounds = invalid then m.syncRounds = 0
    m.syncRounds = m.syncRounds + 1
    if (isTrue(r.data.more) or getSyncQueue().Count() > 0) and m.syncRounds < 10 then
        syncRun()
    else
        m.syncRounds = 0
    end if
end sub

' Redraw Home / People with what arrived, but never interrupt playback or a dialog.
sub refreshQuietly()
    if m.stack.Count() = 0 then return
    top = m.stack.Peek().node
    t = top.subtype()
    if t = "HomeScreen" or t = "PeopleScreen" or t = "ListScreen" then top.refresh = true
end sub

sub tellSettings()
    if m.stack.Count() = 0 then return
    top = m.stack.Peek().node
    if top.subtype() = "SettingsScreen" then top.refresh = true
end sub

sub syncJoin(code as string)
    st = getSettings()
    m.joinCode = UCase(code.Trim())
    patchSettings({ syncError: "Joining..." })
    tellSettings()
    api("sync", { url: st.syncUrl, code: m.joinCode, since: 0, changes: [] }, onJoinFetched)
end sub

sub onJoinFetched(r as object)
    if not r.ok then
        patchSettings({ syncError: toStr(r.error) })
        tellSettings()
        return
    end if
    remote = r.data.changes
    if not isArray(remote) then remote = []
    ' the same name on both sides is the same person
    for each local in getPeople()
        for each c in remote
            if startsWith(toStr(c.k), "p|") and not isTrue(c.del) and isAA(c.v) then
                if LCase(toStr(c.v.name).Trim()) = LCase(toStr(local.name).Trim()) and toStr(c.v.id) <> local.id then renamePersonId(local.id, toStr(c.v.id))
            end if
        end for
    end for
    patchSettings({ syncCode: m.joinCode, syncCursor: r.data.now, syncError: "" })
    applySync(remote)
    queueAll()
    updateScope()
    tellSettings()
    syncRun()
end sub

sub syncCreate()
    patchSettings({ syncError: "Creating a household..." })
    tellSettings()
    api("household", { url: getSettings().syncUrl }, onHousehold)
end sub

sub onHousehold(r as object)
    if not r.ok then
        patchSettings({ syncError: toStr(r.error) })
        tellSettings()
        return
    end if
    syncJoin(toStr(r.data.code))
end sub

sub syncLeave()
    regSet("syncq", {})
    patchSettings({ syncCode: "", syncCursor: 0, syncError: "", syncLastOk: 0 })
    tellSettings()
end sub

' ---------- connecting ----------

sub connect(p as object, fromLogin as boolean, background = false as boolean)
    m.pending = p
    m.pendingFromLogin = fromLogin
    m.background = background
    m.connecting = true
    if not fromLogin and not background then
        m.splashText.text = "Connecting to " + p.name + "..."
        m.splash.visible = true
        m.splash.setFocus(true)
    end if
    m.connectId = api("connect", { profile: p, cacheDays: getSettings().cacheDays }, onConnected)
    if m.connectTimer = invalid then
        m.connectTimer = CreateObject("roSGNode", "Timer")
        m.connectTimer.duration = 120
        m.connectTimer.observeField("fire", "onConnectTimeout")
    end if
    m.connectTimer.control = "stop"
    m.connectTimer.control = "start"
end sub

sub onConnectTimeout()
    if not m.splash.visible then return
    if m.apiCbs <> invalid then m.apiCbs.Delete(toStr(m.connectId))
    onConnected({ ok: false, error: "Connecting took too long. Check your internet connection and the portal URL, then try again." })
end sub

sub onConnected(r as object)
    p = m.pending
    m.connecting = false
    if m.connectTimer <> invalid then m.connectTimer.control = "stop"
    m.splash.visible = false
    if not r.ok then
        if m.background and not m.personPicked and m.stack.Count() > 0 and m.stack.Peek().node.subtype() = "PeopleScreen" then
            m.stack.Peek().node.statusText = "Couldn't connect to " + toStr(p.name) + ": " + toStr(r.error)
            return
        end if
        if m.pendingFromLogin and not m.background and m.stack.Count() > 0 then
            top = m.stack.Peek().node
            top.errorText = r.error
            top.busy = false
        else
            openLogin(p, r.error, true)
        end if
        return
    end if
    saveProfile(p)
    patchSettings({ lastProfile: p.id })
    m.global.profile = p
    m.connected = true
    m.profileLabel.text = p.name
    updateScope()
    ' still on "Who's watching?": wait for a pick
    if not m.personPicked or currentPerson() = invalid then
        if m.stack.Count() > 0 and m.stack.Peek().node.subtype() = "PeopleScreen" then
            m.stack.Peek().node.statusText = ""
            m.stack.Peek().node.setFocus(true)
        else
            showPeople()
        end if
        return
    end if
    enterHome()
end sub

sub openLogin(p as dynamic, err as string, asRoot as boolean)
    fields = { errorText: err, canCancel: not asRoot and (m.connected or m.stack.Count() > 0) }
    if p <> invalid then fields.profile = p
    if asRoot then
        clearStack()
        m.nav.visible = false
    end if
    push("LoginScreen", fields, true)
end sub

' ---------- screen stack ----------

function makeScreen(name as string, fields as object) as object
    comp = name
    if name = "BrowseMovies" or name = "BrowseSeries" then comp = "BrowseScreen"
    s = CreateObject("roSGNode", comp)
    if name = "BrowseMovies" then s.ty = "MOVIE"
    if name = "BrowseSeries" then s.ty = "SERIES"
    s.setFields(fields)
    s.observeField("action", "onAction")
    return s
end function

sub clearStack()
    while m.stack.Count() > 0
        e = m.stack.Pop()
        e.node.closing = true
        e.node.getParent().removeChild(e.node)
    end while
end sub

sub setRoot(index as integer)
    clearStack()
    s = makeScreen(m.tabs[index][0], {})
    s.start = true
    m.content.appendChild(s)
    m.stack.Push({ node: s, full: false })
    s.setFocus(true)
end sub

sub push(name as string, fields as object, full as boolean)
    if m.stack.Count() > 0 then m.stack.Peek().node.visible = false
    s = makeScreen(name, fields)
    if full then
        m.full.appendChild(s)
        m.nav.visible = false
    else
        m.content.appendChild(s)
    end if
    m.stack.Push({ node: s, full: full })
    s.start = true
    s.setFocus(true)
end sub

sub pop()
    if m.stack.Count() <= 1 then return
    e = m.stack.Pop()
    e.node.closing = true
    e.node.getParent().removeChild(e.node)
    prev = m.stack.Peek()
    prev.node.visible = true
    m.nav.visible = m.connected and not prev.full
    prev.node.setFocus(true)
    prev.node.refresh = true
end sub

sub onMenu()
    setRoot(m.menu.itemSelected)
end sub

sub onAction(ev as object)
    a = ev.getData()
    if not isAA(a) then return
    k = a.kind
    if k = "close" then
        pop()
    else if k = "details" then
        push("DetailsScreen", { item: a.item }, false)
    else if k = "play" then
        f = { playlist: a.list, index: a.index, live: false }
        if isTrue(a.startOver) then f.startOver = true
        push("PlayerScreen", f, true)
    else if k = "live" then
        push("PlayerScreen", { playlist: a.list, index: a.index, live: true }, true)
    else if k = "connect" then
        connect(a.profile, true)
    else if k = "person" then
        choosePerson(a.person)
    else if k = "people" then
        showPeople()
    else if k = "sources" then
        openLogin(lastSource(), "", false)
    else if k = "peopleChanged" then
        syncRun()
    else if k = "syncJoin" then
        syncJoin(toStr(a.code))
    else if k = "syncCreate" then
        syncCreate()
    else if k = "syncLeave" then
        syncLeave()
    else if k = "syncNow" then
        syncRun()
    else if k = "switch" then
        connect(a.profile, false)
    else if k = "addSource" then
        openLogin(invalid, "", false)
    else if k = "editSource" then
        openLogin(a.profile, "", false)
    else if k = "menu" then
        if m.nav.visible then m.menu.setFocus(true)
    else if k = "noSources" then
        m.connected = false
        openLogin(invalid, "", true)
    else if k = "reload" then
        setRoot(m.menu.itemFocused)
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "back" then
        if m.splash.visible then
            m.top.exitApp = true
            return true
        end if
        if m.stack.Count() > 1 then
            pop()
            return true
        end if
        m.top.exitApp = true
        return true
    end if
    if key = "left" and m.nav.visible and not m.menu.hasFocus() then
        m.menu.setFocus(true)
        return true
    end if
    if key = "right" and m.menu.hasFocus() and m.stack.Count() > 0 then
        m.stack.Peek().node.setFocus(true)
        return true
    end if
    return false
end function
