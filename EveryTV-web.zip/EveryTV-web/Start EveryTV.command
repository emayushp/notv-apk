#!/usr/bin/env bash
# Start EveryTV on macOS / Linux
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "EveryTV needs Node.js (free). Install the LTS version from https://nodejs.org and run this again."
  exit 1
fi
exec node server.js
