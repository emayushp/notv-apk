#!/usr/bin/env bash
# Start EveryTV on macOS / Linux. Uses Node.js if installed, otherwise downloads a portable copy into ./node
set -e
cd "$(dirname "$0")"
if [ -x node/bin/node ]; then exec node/bin/node server.js; fi
if command -v node >/dev/null 2>&1; then exec node server.js; fi

case "$(uname -s)" in Darwin) os=darwin; ext=tar.gz ;; Linux) os=linux; ext=tar.xz ;; *) echo "Unsupported system"; exit 1 ;; esac
case "$(uname -m)" in arm64|aarch64) arch=arm64 ;; x86_64|amd64) arch=x64 ;; *) echo "Unsupported CPU $(uname -m)"; exit 1 ;; esac
base=https://nodejs.org/dist/latest-v22.x
echo
echo "  First run: downloading portable Node.js (about 30 MB, one time only)..."
line=$(curl -fsSL "$base/SHASUMS256.txt" | grep -E "node-v[0-9.]+-$os-$arch\.$ext$" | head -1)
[ -n "$line" ] || { echo "Could not find a Node.js download for $os-$arch."; exit 1; }
hash=${line%% *}; name=${line##* }
tmp=$(mktemp -d)
curl -fL --progress-bar "$base/$name" -o "$tmp/$name"
if command -v shasum >/dev/null 2>&1; then got=$(shasum -a 256 "$tmp/$name" | cut -d' ' -f1); else got=$(sha256sum "$tmp/$name" | cut -d' ' -f1); fi
[ "$got" = "$hash" ] || { echo "Download was corrupted (checksum mismatch). Please try again."; rm -rf "$tmp"; exit 1; }
tar -xf "$tmp/$name" -C "$tmp"
rm -rf node && mv "$tmp/${name%.$ext}" node
rm -rf "$tmp"
echo "  Done: $name"
echo
exec node/bin/node server.js
