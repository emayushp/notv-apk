#!/usr/bin/env node
'use strict';
/**
 * EveryTV web — tiny local server.
 *  - serves the web app from ./public
 *  - /proxy     : forwards a request to your IPTV portal / stream with the headers a MAG box or player would send
 *                 (Cookie: mac=…, User-Agent, Authorization…) — browsers are not allowed to set those, and portals
 *                 don't send CORS headers. HLS manifests are rewritten so segments flow through here too.
 *  - /probe     : follows redirects and reports the final URL (used to discover the real Stalker portal address)
 *  - /transcode : optional, needs ffmpeg installed; fixes streams the browser can't decode (AC3/EAC3 audio etc.)
 *
 * Your laptop talks to the portal directly — this server just runs on your own machine.
 * By default it listens on 127.0.0.1 only and every request needs a per-run token, so other websites can't use it.
 */
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');

const PORT = Number(process.env.PORT) || 8787;
const HOST = process.env.HOST || '127.0.0.1';
const TOKEN = process.env.EVERYTV_TOKEN || crypto.randomBytes(16).toString('hex');
const PUB = path.join(__dirname, 'public');
const HAS_FFMPEG = (() => { try { return spawnSync('ffmpeg', ['-version']).status === 0; } catch { return false; } })();

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json', '.map': 'application/json',
};

// Only these request headers may be set through the proxy.
const ALLOWED_HEADERS = new Set(['user-agent', 'x-user-agent', 'cookie', 'authorization', 'referer', 'origin', 'accept']);
const DEFAULT_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

function parseHeaders(b64) {
  const out = {};
  if (!b64) return out;
  try {
    const obj = JSON.parse(Buffer.from(b64, 'base64url').toString('utf8'));
    for (const [k, v] of Object.entries(obj)) {
      if (ALLOWED_HEADERS.has(k.toLowerCase()) && typeof v === 'string' && !/[\r\n]/.test(v)) out[k] = v;
    }
  } catch { /* ignore */ }
  return out;
}

function open(urlStr, headers, redirects = 0) {
  return new Promise((resolve, reject) => {
    let u;
    try { u = new URL(urlStr); } catch { return reject(new Error('Bad URL')); }
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return reject(new Error('Only http(s) URLs are supported'));
    const lib = u.protocol === 'https:' ? https : http;
    const req = lib.request(u, { method: 'GET', headers, timeout: 25000 }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
        res.resume();
        if (redirects >= 8) return reject(new Error('Too many redirects'));
        let next;
        try { next = new URL(res.headers.location, u).toString(); } catch { return reject(new Error('Bad redirect')); }
        return resolve(open(next, headers, redirects + 1));
      }
      resolve({ res, req, finalUrl: u.toString() });
    });
    req.on('timeout', () => req.destroy(new Error('Timed out talking to the server')));
    req.on('error', reject);
    req.end();
  });
}

function decode(buf, enc) {
  enc = (enc || '').toLowerCase();
  if (enc === 'gzip') return zlib.gunzipSync(buf);
  if (enc === 'deflate') return zlib.inflateSync(buf);
  if (enc === 'br') return zlib.brotliDecompressSync(buf);
  return buf;
}

function rewriteM3U8(text, base, hdrB64) {
  const px = (u) => `/proxy?t=${TOKEN}${hdrB64 ? `&h=${hdrB64}` : ''}&u=${encodeURIComponent(new URL(u, base).toString())}`;
  return text.split(/\r?\n/).map((line) => {
    if (!line.trim()) return line;
    if (line.startsWith('#')) return line.replace(/URI="([^"]+)"/g, (_m, u) => `URI="${px(u)}"`);
    try { return px(line.trim()); } catch { return line; }
  }).join('\n');
}

function fail(res, code, msg) {
  if (res.headersSent) { res.destroy(); return; }
  const body = JSON.stringify({ error: msg });
  res.writeHead(code, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body), 'X-Proxy-Error': '1' });
  res.end(body);
}

async function handleProxy(req, res, q) {
  const target = q.get('u');
  if (!target) return fail(res, 400, 'Missing u');
  const hdrB64 = q.get('h') || '';
  const headers = { 'User-Agent': DEFAULT_UA, Accept: '*/*', 'Accept-Encoding': q.get('gz') === '1' ? 'gzip' : 'identity', ...parseHeaders(hdrB64) };
  if (req.headers.range) headers.Range = req.headers.range;

  let up;
  try { up = await open(target, headers); } catch (e) { return fail(res, 502, e.message || 'Could not reach the server'); }
  const { res: ures, req: ureq, finalUrl } = up;
  req.on('close', () => ureq.destroy());

  const ctype = String(ures.headers['content-type'] || '');
  // Only playback requests get HLS rewriting; API/playlist downloads (gz=1) must stay untouched (an IPTV .m3u list is also audio/x-mpegurl).
  const canRewrite = q.get('gz') !== '1';
  const hintM3U8 = canRewrite && (/mpegurl/i.test(ctype) || /\.m3u8?(\?|$)/i.test(new URL(finalUrl).pathname + new URL(finalUrl).search));
  const enc = ures.headers['content-encoding'];
  let first = true;
  let manifest = null;

  const sendHead = () => {
    const h = { 'Cache-Control': 'no-store', 'X-Final-Url': encodeURIComponent(finalUrl) };
    for (const k of ['content-type', 'content-length', 'content-range', 'accept-ranges', 'content-encoding', 'last-modified']) {
      if (ures.headers[k]) h[k] = ures.headers[k];
    }
    res.writeHead(ures.statusCode || 200, h);
  };

  ures.on('data', (chunk) => {
    if (first) {
      first = false;
      const looksM3U8 = canRewrite && !enc && chunk.subarray(0, 7).toString() === '#EXTM3U';
      if (hintM3U8 || looksM3U8) { manifest = [chunk]; return; }
      sendHead();
    }
    if (manifest) { manifest.push(chunk); return; }
    if (!res.write(chunk)) { ures.pause(); res.once('drain', () => ures.resume()); }
  });
  ures.on('end', () => {
    if (manifest) {
      try {
        const text = decode(Buffer.concat(manifest), enc).toString('utf8');
        if (text.trimStart().startsWith('#EXTM3U')) {
          const body = Buffer.from(rewriteM3U8(text, finalUrl, hdrB64));
          res.writeHead(ures.statusCode || 200, { 'Content-Type': 'application/vnd.apple.mpegurl', 'Content-Length': body.length, 'Cache-Control': 'no-store', 'X-Final-Url': encodeURIComponent(finalUrl) });
          return res.end(body);
        }
        const raw = Buffer.concat(manifest);
        sendHead();
        return res.end(raw);
      } catch (e) { return fail(res, 502, 'Bad playlist: ' + e.message); }
    }
    if (first) sendHead(); // empty body
    res.end();
  });
  ures.on('error', () => res.destroy());
  ures.on('aborted', () => res.destroy());
}

async function handleProbe(_req, res, q) {
  const target = q.get('u');
  if (!target) return fail(res, 400, 'Missing u');
  const headers = { 'User-Agent': DEFAULT_UA, Accept: '*/*', 'Accept-Encoding': 'identity', ...parseHeaders(q.get('h') || '') };
  try {
    const { res: ures, req: ureq, finalUrl } = await open(target, headers);
    const status = ures.statusCode;
    const type = String(ures.headers['content-type'] || '');
    ureq.destroy();
    const body = JSON.stringify({ status, finalUrl, contentType: type });
    res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) });
    res.end(body);
  } catch (e) {
    fail(res, 502, e.message || 'Could not reach the server');
  }
}

/** Opens a stream just long enough to see what it is (HLS playlist, MPEG-TS, MP4…), so the browser can pick a player. */
async function handleSniff(_req, res, q) {
  const target = q.get('u');
  if (!target) return fail(res, 400, 'Missing u');
  const headers = { 'User-Agent': DEFAULT_UA, Accept: '*/*', 'Accept-Encoding': 'identity', ...parseHeaders(q.get('h') || '') };
  try {
    const { res: ures, req: ureq, finalUrl } = await open(target, headers);
    const type = String(ures.headers['content-type'] || '');
    const chunk = await new Promise((resolve) => {
      const t = setTimeout(() => resolve(Buffer.alloc(0)), 15000);
      ures.once('data', (c) => { clearTimeout(t); resolve(c); });
      ures.once('end', () => { clearTimeout(t); resolve(Buffer.alloc(0)); });
      ures.once('error', () => { clearTimeout(t); resolve(Buffer.alloc(0)); });
    });
    ureq.destroy();
    let kind = 'other';
    const head = chunk.subarray(0, 16);
    if (head.subarray(0, 7).toString() === '#EXTM3U' || /mpegurl/i.test(type)) kind = 'hls';
    else if (head[0] === 0x47 && (chunk.length < 189 || chunk[188] === 0x47)) kind = 'ts';
    else if (head.subarray(4, 8).toString() === 'ftyp') kind = 'mp4';
    else if (head[0] === 0x1a && head[1] === 0x45 && head[2] === 0xdf && head[3] === 0xa3) kind = 'mkv';
    else if (/mp2t/i.test(type)) kind = 'ts';
    else if (/^(video|audio)\//i.test(type)) kind = 'other';
    else if (ures.statusCode >= 400) kind = 'error';
    const body = JSON.stringify({ kind, status: ures.statusCode, contentType: type, finalUrl });
    res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) });
    res.end(body);
  } catch (e) {
    fail(res, 502, e.message || 'Could not reach the server');
  }
}

/** Optional ffmpeg path: copies video, converts audio to AAC (fixes "video but no sound"), streams MPEG-TS back. */
function handleTranscode(req, res, q) {
  if (!HAS_FFMPEG) return fail(res, 501, 'ffmpeg is not installed on this computer');
  const target = q.get('u');
  if (!target || !/^https?:\/\//i.test(target)) return fail(res, 400, 'Missing or bad u');
  const h = { 'User-Agent': DEFAULT_UA, ...parseHeaders(q.get('h') || '') };
  const ua = h['User-Agent']; delete h['User-Agent'];
  const extra = Object.entries(h).map(([k, v]) => `${k}: ${v}\r\n`).join('');
  const full = q.get('video') === 'h264';
  const ss = Math.max(0, Number(q.get('ss')) || 0);
  const args = ['-hide_banner', '-loglevel', 'error', '-user_agent', ua];
  if (extra) args.push('-headers', extra);
  args.push('-reconnect', '1', '-reconnect_streamed', '1', '-reconnect_delay_max', '4');
  if (ss > 0) args.push('-ss', String(ss));
  args.push('-i', target, '-map', '0:v:0?', '-map', '0:a:0?');
  if (full) args.push('-c:v', 'libx264', '-preset', 'veryfast', '-tune', 'zerolatency', '-pix_fmt', 'yuv420p');
  else args.push('-c:v', 'copy');
  args.push('-c:a', 'aac', '-b:a', '160k', '-ac', '2', '-f', 'mpegts', 'pipe:1');
  const ff = spawn('ffmpeg', args, { stdio: ['ignore', 'pipe', 'pipe'] });
  let err = '';
  ff.stderr.on('data', (d) => { err += d; if (err.length > 2000) err = err.slice(-2000); });
  res.writeHead(200, { 'Content-Type': 'video/mp2t', 'Cache-Control': 'no-store' });
  ff.stdout.pipe(res);
  ff.on('close', (code) => { if (code && !res.writableEnded) { console.error('ffmpeg:', err.trim()); } res.end(); });
  req.on('close', () => ff.kill('SIGKILL'));
}

function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/' || rel === '') rel = '/index.html';
  const file = path.normalize(path.join(PUB, rel));
  if (!file.startsWith(PUB + path.sep) && file !== PUB) return fail(res, 403, 'Forbidden');
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return fail(res, 404, 'Not found');
    const ext = path.extname(file).toLowerCase();
    if (ext === '.html') {
      const html = fs.readFileSync(file, 'utf8').replace(/__EVERYTV_TOKEN__/g, TOKEN).replace(/__FFMPEG__/g, HAS_FFMPEG ? '1' : '0');
      res.writeHead(200, { 'Content-Type': MIME[ext], 'Cache-Control': 'no-store' });
      return res.end(html);
    }
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': st.size, 'Cache-Control': ext === '.js' || ext === '.css' ? 'no-cache' : 'public, max-age=3600' });
    fs.createReadStream(file).pipe(res);
  });
}

function hostOk(req) {
  // Blocks DNS-rebinding style attacks when listening on loopback.
  if (HOST !== '127.0.0.1' && HOST !== 'localhost') return true;
  const h = String(req.headers.host || '').replace(/:\d+$/, '').toLowerCase();
  return h === '127.0.0.1' || h === 'localhost' || h === '[::1]';
}

const server = http.createServer((req, res) => {
  if (!hostOk(req)) return fail(res, 403, 'Bad host');
  const url = new URL(req.url, 'http://local');
  const p = url.pathname;
  if (p === '/proxy' || p === '/probe' || p === '/sniff' || p === '/transcode') {
    if (url.searchParams.get('t') !== TOKEN) return fail(res, 403, 'Bad token');
    if (p === '/proxy') return void handleProxy(req, res, url.searchParams).catch((e) => fail(res, 500, e.message));
    if (p === '/probe') return void handleProbe(req, res, url.searchParams).catch((e) => fail(res, 500, e.message));
    if (p === '/sniff') return void handleSniff(req, res, url.searchParams).catch((e) => fail(res, 500, e.message));
    return handleTranscode(req, res, url.searchParams);
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') return fail(res, 405, 'Method not allowed');
  serveStatic(req, res, p);
});

function openBrowser(url) {
  if (process.env.NO_OPEN) return;
  const [cmd, args] = process.platform === 'win32' ? ['cmd', ['/c', 'start', '', url]] : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]];
  try { spawn(cmd, args, { stdio: 'ignore', detached: true }).on('error', () => {}).unref(); } catch { /* user can open it by hand */ }
}

server.on('clientError', (_e, sock) => sock.destroy());
server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.log(`\n  Port ${PORT} is already in use – EveryTV is probably already running.\n  Opening http://localhost:${PORT} …\n`);
    openBrowser(`http://localhost:${PORT}`);
    setTimeout(() => process.exit(0), 500);
  } else { console.error(e); process.exit(1); }
});
server.listen(PORT, HOST, () => {
  const shown = HOST === '0.0.0.0' ? 'localhost' : HOST;
  console.log(`\n  EveryTV web is running →  http://${shown}:${PORT}\n`);
  openBrowser(`http://${shown}:${PORT}`);
  console.log(`  ffmpeg: ${HAS_FFMPEG ? 'found (compatibility mode available)' : 'not found (optional)'}`);
  if (HOST !== '127.0.0.1') console.log('  Listening on your network — only do this on a network you trust.');
  console.log('  Press Ctrl+C to stop.\n');
});
