# EveryTV for the web

Watch your IPTV on a laptop: MAG/Stalker portal (URL + MAC + serial), Xtream Codes, or an M3U playlist.
Netflix-style Home, Movies, Series, Live TV with programme guide, resume where you left off, subtitles,
channel zapping, multi-screen (top/bottom, side by side, 2×2) and a 7-day category cache.

## Run it

1. Install **Node.js** (free, one time): https://nodejs.org – choose the *LTS* download.
2. Unzip this folder, then
   - **Windows:** double-click `Start EveryTV.bat`
   - **Mac:** double-click `Start EveryTV.command` (first time: right-click → Open)
   - **Linux:** `./start.sh`
3. Your browser opens at http://localhost:8787 – add your source and watch.

Leave the black window open while you watch; close it to stop EveryTV.

## How it works

Browsers can't talk to IPTV portals directly (no CORS, and they can't send the MAC cookie a set-top box sends).
So `server.js` runs on your own computer and forwards requests to your provider. Nothing goes through anyone
else's server, it only listens on `localhost`, and every request needs a token that only the page knows.

Because it talks to your provider straight from your laptop, it works anywhere your laptop can already reach
the provider. It does not get around networks that block it.

## Good to know

- **Sound or picture missing?** Some channels use audio/video the browser can't decode (AC3, HEVC). Install
  [ffmpeg](https://ffmpeg.org/download.html) and put it on your PATH – EveryTV then switches to *compatibility
  mode* automatically (also in the ⚙ menu while playing).
- **Subtitles:** portal streams rarely carry subtitle tracks into a browser. Use ⚙ → Subtitles → *Load subtitle file*
  (.srt / .vtt). Offline auto-captions from the Android app are not in the web version.
- **Keyboard:** Space play/pause · ← → seek (Shift = 60 s) · ↑ ↓ volume or channel (Live) · PgUp/PgDn channel/episode ·
  0–9 channel number · Backspace previous channel · L channel list · C subtitles · M mute · F fullscreen · / search.
- Your sources, history and My List live in this browser. Use Settings → Backup to move them.
- To reach it from another device on your home network: `HOST=0.0.0.0 node server.js` (only on a network you trust).
- Different port: `PORT=9000 node server.js` (note: browser data is stored per address, so keep one port).

## Development

No build step. `public/` is plain ES modules; `public/vendor/` holds hls.js and mpegts.js.
End-to-end test (needs the mock portal in `../tests`): `python3 tests/web_test.py`.
