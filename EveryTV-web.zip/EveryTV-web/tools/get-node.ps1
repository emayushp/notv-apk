# Downloads a portable copy of Node.js into .\node (no installer, no admin rights needed).
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$root = Split-Path -Parent $PSScriptRoot
$dest = Join-Path $root 'node'
$arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'x64' }
$base = 'https://nodejs.org/dist/latest-v22.x'

Write-Host ''
Write-Host '  First run: downloading portable Node.js (about 30 MB, one time only)...'
$sums = (Invoke-WebRequest "$base/SHASUMS256.txt" -UseBasicParsing).Content
$line = ($sums -split "`n") | Where-Object { $_ -match "node-v[\d.]+-win-$arch\.zip\s*$" } | Select-Object -First 1
if (-not $line) { throw "Could not find a Node.js download for win-$arch." }
$parts = $line.Trim() -split '\s+'
$hash = $parts[0]; $name = $parts[1]

$tmp = Join-Path $env:TEMP $name
Invoke-WebRequest "$base/$name" -OutFile $tmp -UseBasicParsing
$got = (Get-FileHash $tmp -Algorithm SHA256).Hash.ToLower()
if ($got -ne $hash.ToLower()) { Remove-Item $tmp; throw 'Download was corrupted (checksum mismatch). Please try again.' }

$unpack = Join-Path $env:TEMP ('everytv-node-' + [guid]::NewGuid())
Expand-Archive $tmp -DestinationPath $unpack -Force
if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
Move-Item (Join-Path $unpack ($name -replace '\.zip$', '')) $dest
Remove-Item $tmp, $unpack -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "  Done: $name"
Write-Host ''
