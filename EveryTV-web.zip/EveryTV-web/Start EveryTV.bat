@echo off
title EveryTV
cd /d "%~dp0"
if exist "node\node.exe" goto run
where node >nul 2>nul
if not errorlevel 1 (
  node server.js
  pause
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\get-node.ps1"
if not exist "node\node.exe" (
  echo.
  echo  Could not download Node.js automatically.
  echo  Download the Windows "Standalone Binary (.zip)" from https://nodejs.org/en/download
  echo  and unzip it into a folder called "node" inside this EveryTV folder.
  pause
  exit /b
)
:run
"node\node.exe" server.js
pause
