@echo off
title EveryTV
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  EveryTV needs Node.js (free, one-time install).
  echo  Opening the download page - install the "LTS" version, then double-click this file again.
  start https://nodejs.org/en/download
  pause
  exit /b
)
node server.js
pause
