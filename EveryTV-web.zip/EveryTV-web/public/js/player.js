// Video player: HLS (hls.js), MPEG-TS (mpegts.js), plain files, plus optional ffmpeg "compatibility mode".
import { h, clear, fmtTime } from './util.js';
import { proxied, transcoded, sniff, HAS_FFMPEG } from './net.js';

const ICONS = {
  play: 'M8 5v14l11-7z',
  pause: 'M6 19h4V5H6v14zm8-14v14h4V5h-4z',
  back10: 'M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z',
  fwd10: 'M12 5V1l5 5-5 5V7c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6h2c0 4.42-3.58 8-8 8s-8-3.58-8-8 3.58-8 8-8z',
  vol: 'M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02z',
  mute: 'M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z',
  cc: 'M19 4H5c-1.11 0-2 .9-2 2v12c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-8 7H9.5v-.5h-2v3h2V13H11v1c0 .55-.45 1-1 1H7c-.55 0-1-.45-1-1v-4c0-.55.45-1 1-1h3c.55 0 1 .45 1 1v1zm7 0h-1.5v-.5h-2v3h2V13H18v1c0 .55-.45 1-1 1h-3c-.55 0-1-.45-1-1v-4c0-.55.45-1 1-1h3c.55 0 1 .45 1 1v1z',
  gear: 'M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z',
  pip: 'M19 7h-8v6h8V7zm2-4H3c-1.1 0-2 .9-2 2v14c0 1.1.9 1.98 2 1.98h18c1.1 0 2-.88 2-1.98V5c0-1.1-.9-2-2-2zm0 16.01H3V4.98h18v14.03z',
  full: 'M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z',
  list: 'M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z',
  next: 'M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z',
  prev: 'M6 6h2v12H6zm3.5 6l8.5 6V6z',
  back: 'M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z',
};
export function icon(name, size = 24) {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 24 24'); svg.setAttribute('width', size); svg.setAttribute('height', size); svg.setAttribute('fill', 'currentColor');
  const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  p.setAttribute('d', ICONS[name] || ''); svg.append(p);
  return svg;
}
const btn = (name, title, onclick, cls = '') => h('button.pbtn' + (cls ? '.' + cls : ''), { title, onclick, type: 'button', 'aria-label': title }, icon(name));

function srtToVtt(text) {
  const t = text.replace(/\r/g, '').replace(/^﻿/, '');
  if (t.startsWith('WEBVTT')) return t;
  return 'WEBVTT\n\n' + t.replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, '$1.$2');
}

export class Player {
  /**
   * opts: { mini, getSettings, patchSettings, onProgress(sec,dur), onEnded, onNext, onPrev, onClose, onZap(dir), onNumber(n), onList, onStatus }
   */
  constructor(root, opts = {}) {
    this.root = root; this.opts = opts;
    this.hls = null; this.mpegts = null;
    this.src = null; this.compat = false; this.compatVideo = false; this.offset = 0; this.durHint = 0;
    this.timers = new Set(); this.destroyed = false; this.retries = 0; this.token = 0;
    this.build();
    this.bindKeys();
  }

  settings() { return this.opts.getSettings?.() || {}; }

  build() {
    const mini = this.opts.mini;
    this.video = h('video', { playsInline: true, preload: 'auto', crossOrigin: 'anonymous' });
    this.video.addEventListener('click', () => { if (mini) this.opts.onFocus?.(); else this.togglePlayDelayed(); });
    this.video.addEventListener('dblclick', () => { clearTimeout(this.clickT); if (!mini) this.toggleFullscreen(); });
    this.title = h('div.ptitle');
    this.subtitleLine = h('div.psub');
    this.info = h('div.pinfo');
    this.spinner = h('div.pspinner');
    this.msg = h('div.pmsg');
    this.toast = h('div.ptoast');

    this.seek = h('div.pseek', { onpointerdown: (e) => this.seekDown(e) },
      h('div.pseek-buf'), h('div.pseek-bar'), h('div.pseek-thumb'), h('div.pseek-tip'));
    this.timeLbl = h('span.ptime', '0:00 / 0:00');
    this.playBtn = btn('play', 'Play / Pause (Space)', () => this.togglePlay());
    this.muteBtn = btn('vol', 'Mute (M)', () => this.toggleMute());
    this.vol = h('input.pvol', { type: 'range', min: 0, max: 1, step: 0.02, value: this.settings().volume ?? 1, oninput: (e) => { this.video.volume = +e.target.value; this.video.muted = false; this.opts.patchSettings?.({ volume: this.video.volume }); } });
    this.menuBtn = btn('gear', 'Subtitles, audio & more', () => this.toggleMenu());
    this.ccBtn = btn('cc', 'Subtitles (C)', () => this.toggleMenu('subs'));
    this.menu = h('div.pmenu', { hidden: true });

    const live = () => this.src?.live;
    this.controls = h('div.pbottom',
      this.seek,
      h('div.prow',
        this.opts.onPrev ? btn('prev', 'Previous (P)', () => this.opts.onPrev()) : null,
        this.playBtn,
        this.backBtn = btn('back10', 'Back 10s (←)', () => this.skip(-10), 'skip'),
        this.fwdBtn = btn('fwd10', 'Forward 10s (→)', () => this.skip(10), 'skip'),
        this.opts.onNext ? btn('next', 'Next (N)', () => this.opts.onNext()) : null,
        this.muteBtn, this.vol, this.timeLbl,
        h('span.pspacer'),
        this.opts.onList ? btn('list', 'Channels / episodes (L)', () => this.opts.onList()) : null,
        this.ccBtn, this.menuBtn,
        document.pictureInPictureEnabled ? btn('pip', 'Picture in picture', () => this.togglePip()) : null,
        btn('full', 'Fullscreen (F)', () => this.toggleFullscreen())));

    this.top = h('div.ptop',
      this.opts.onClose ? btn('back', 'Back (Esc)', () => this.opts.onClose()) : null,
      h('div.ptitles', this.title, this.subtitleLine, this.info));

    const parts = [this.video, this.top, this.spinner, this.msg, this.toast];
    if (!mini) parts.push(this.controls, this.menu);
    else parts.push(h('div.pmini', this.muteBtn));
    this.root.classList.add('player');
    if (mini) this.root.classList.add('mini');
    this.root.append(...parts);
    this.applyLiveUi(false);

    const v = this.video;
    v.volume = this.settings().volume ?? 1;
    v.addEventListener('play', () => this.onPlayState());
    v.addEventListener('pause', () => { this.onPlayState(); this.saveProgress(); });
    v.addEventListener('waiting', () => this.root.classList.add('buffering'));
    v.addEventListener('playing', () => { this.root.classList.remove('buffering'); this.msg.textContent = ''; this.root.classList.remove('errored'); this.retries = 0; this.scheduleHealthCheck(); });
    v.addEventListener('canplay', () => { this.root.classList.remove('buffering'); this.applyStartPosition(); });
    v.addEventListener('loadedmetadata', () => { if (isFinite(v.duration) && v.duration > 0 && !this.compat) this.durHint = v.duration; });
    v.addEventListener('timeupdate', () => this.onTime());
    v.addEventListener('progress', () => this.updateBuffered());
    v.addEventListener('volumechange', () => { this.muteBtn.replaceChildren(icon(v.muted || v.volume === 0 ? 'mute' : 'vol')); });
    v.addEventListener('ended', () => { this.saveProgress(true); this.opts.onEnded?.(); });
    v.addEventListener('error', () => this.onVideoError());

    const wake = () => this.wake();
    this.root.addEventListener('pointermove', wake);
    this.root.addEventListener('pointerdown', wake);
    this.root.addEventListener('mouseleave', () => { if (!v.paused) this.root.classList.remove('active'); });
    this.interval(() => this.saveProgress(), 5000);
    this.wake();
  }

  interval(fn, ms) { const t = setInterval(fn, ms); this.timers.add(t); return t; }
  timeout(fn, ms) { const t = setTimeout(fn, ms); this.timers.add(t); return t; }

  wake() {
    this.root.classList.add('active');
    clearTimeout(this.hideT);
    this.hideT = setTimeout(() => { if (!this.video.paused && this.menu.hidden) this.root.classList.remove('active'); }, 3200);
  }

  applyLiveUi(live) {
    this.root.classList.toggle('live', !!live);
  }

  // ---------- loading ----------

  /** src: { url, headers, live, title, subtitle, startAt (sec), durationHint (sec), key } */
  async load(src) {
    this.stopEngines();
    this.src = src; this.offset = 0; this.durHint = src.durationHint || 0; this.retries = 0;
    this.startAt = src.startAt || 0; this.startApplied = false;
    this.compat = !!src.compat && HAS_FFMPEG; this.compatVideo = !!src.compatVideo;
    this.title.textContent = src.title || ''; this.subtitleLine.textContent = src.subtitle || ''; this.info.textContent = '';
    this.applyLiveUi(src.live);
    this.clearSubs();
    this.msg.textContent = ''; this.root.classList.remove('errored'); this.root.classList.add('buffering');
    await this.start();
  }

  async start(ss = 0) {
    const token = ++this.token;
    const { url, headers = {}, live } = this.src;
    try {
      this.stopEngines();
      if (this.compat) {
        this.offset = ss;
        this.attachTs(transcoded(url, headers, { ss, video: this.compatVideo }), !!live);
        return;
      }
      const kind = await this.detectKind(url, headers);
      if (token !== this.token || this.destroyed) return;
      this.kind = kind;
      if (kind === 'hls') this.attachHls(proxied(url, headers));
      else if (kind === 'ts') this.attachTs(proxied(url, headers), !!live);
      else { this.video.src = proxied(url, headers); this.safePlay(); }
    } catch (e) {
      if (token === this.token) this.fail(e.message || String(e));
    }
  }

  async detectKind(url, headers) {
    const low = url.toLowerCase();
    const path = low.split('?')[0];
    if (/\.m3u8$/.test(path) || /[?&]extension=m3u8/.test(low)) return 'hls';
    if (/\.(ts|mpegts)$/.test(path) || /[?&]extension=ts\b/.test(low)) return 'ts';
    if (/\.(mp4|m4v|webm|mov|mkv|avi|wmv|flv)$/.test(path)) return 'native';
    if (/^(rtmp|rtsp|udp|rtp):/.test(low)) throw new Error('This channel uses a streaming type browsers can\'t play (' + low.split(':')[0] + '). The phone/TV app can play it.');
    const s = await sniff(url, headers);
    if (s.kind === 'hls') return 'hls';
    if (s.kind === 'ts') return 'ts';
    if (s.kind === 'error') throw new Error(`The stream server answered HTTP ${s.status}.`);
    return 'native';
  }

  attachHls(url) {
    const v = this.video;
    if (window.Hls && window.Hls.isSupported()) {
      const live = !!this.src.live;
      const hls = new window.Hls({ enableWorker: true, maxBufferLength: live ? 20 : 40, backBufferLength: 30, startPosition: live ? -1 : (this.startAt > 5 ? this.startAt : -1), manifestLoadingMaxRetry: 2, levelLoadingMaxRetry: 3, fragLoadingMaxRetry: 4 });
      this.hls = hls;
      hls.on(window.Hls.Events.ERROR, (_e, data) => {
        if (!data.fatal) return;
        if (data.type === window.Hls.ErrorTypes.NETWORK_ERROR && this.retries++ < 3) { this.timeout(() => hls.startLoad(), 1200 * this.retries); return; }
        if (data.type === window.Hls.ErrorTypes.MEDIA_ERROR && this.retries++ < 3) { hls.recoverMediaError(); return; }
        this.fail('Stream error: ' + (data.details || data.type));
      });
      hls.on(window.Hls.Events.MANIFEST_PARSED, () => this.safePlay());
      hls.loadSource(url);
      hls.attachMedia(v);
    } else if (v.canPlayType('application/vnd.apple.mpegurl')) {
      v.src = url; this.safePlay();
    } else this.fail('This browser can\'t play HLS streams.');
  }

  attachTs(url, live) {
    if (!window.mpegts || !window.mpegts.isSupported()) { this.fail('This browser can\'t play MPEG-TS streams.'); return; }
    const p = window.mpegts.createPlayer({ type: 'mpegts', isLive: live, url: new URL(url, location.href).href }, { enableWorker: true, enableStashBuffer: !live, liveBufferLatencyChasing: live, liveBufferLatencyMaxLatency: 8, liveBufferLatencyMinRemain: 1.5, lazyLoad: false, autoCleanupSourceBuffer: true });
    this.mpegts = p;
    p.on(window.mpegts.Events.ERROR, (type, detail) => {
      if (this.retries++ < 2 && this.src?.live) { this.timeout(() => this.start(this.offset), 1500); return; }
      this.fail(`Stream error: ${type}${detail ? ' – ' + detail : ''}`);
    });
    p.attachMediaElement(this.video);
    p.load();
    this.safePlay();
  }

  safePlay() {
    const pr = this.video.play();
    if (pr && pr.catch) pr.catch((e) => {
      if (e.name === 'NotAllowedError') { this.video.muted = true; this.video.play().catch(() => {}); this.say('Click the speaker to unmute'); }
    });
  }

  stopEngines() {
    try { this.hls?.destroy(); } catch { /* */ }
    try { this.mpegts?.pause(); this.mpegts?.unload(); this.mpegts?.detachMediaElement(); this.mpegts?.destroy(); } catch { /* */ }
    this.hls = null; this.mpegts = null;
    clearTimeout(this.healthT);
    this.video.removeAttribute('src');
    try { this.video.load(); } catch { /* */ }
  }

  applyStartPosition() {
    if (this.startApplied) return;
    this.startApplied = true;
    const live = this.src?.live;
    if (live || this.compat || !(this.startAt > 5)) return;
    if (this.hls && this.hls.config.startPosition > 0) return;
    const d = this.video.duration;
    if (isFinite(d) && this.startAt > d - 20) return; // nearly finished: start over
    try { this.video.currentTime = this.startAt; } catch { /* */ }
  }

  // ---------- failures & compatibility fallback ----------

  onVideoError() {
    if (this.compat || !this.src) { if (this.src) this.fail('The video could not be played.'); return; }
    const code = this.video.error?.code;
    if (HAS_FFMPEG && (code === 3 || code === 4)) { this.say('Switching to compatibility mode…'); this.setCompat(true, false, this.cur()); return; }
    this.fail(code === 4 ? 'This video format isn\'t supported by the browser.' : 'The video could not be played.');
  }

  fail(text) {
    if (this.destroyed) return;
    if (!this.compat && HAS_FFMPEG && this.src && !this.triedCompatFor) {
      this.triedCompatFor = this.src.url;
      this.say('Trying compatibility mode…');
      this.setCompat(true, false, this.cur());
      return;
    }
    this.showError(text);
  }

  showError(text) {
    if (this.destroyed) return;
    this.root.classList.remove('buffering');
    this.root.classList.add('errored');
    clearElement(this.msg);
    this.msg.append(h('div.pmsg-text', text),
      h('div.pmsg-actions',
        this.src ? h('button.btn', { onclick: () => this.retry() }, 'Try again') : null,
        HAS_FFMPEG && this.src && !this.compat ? h('button.btn.ghost', { onclick: () => this.setCompat(true, false, this.cur()) }, 'Compatibility mode') : null,
        HAS_FFMPEG && this.compat && !this.compatVideo ? h('button.btn.ghost', { onclick: () => this.setCompat(true, true, this.cur()) }, 'Convert video too') : null,
        this.opts.onClose ? h('button.btn.ghost', { onclick: () => this.opts.onClose() }, 'Close') : null));
  }

  retry() { this.msg.textContent = ''; this.root.classList.remove('errored'); this.root.classList.add('buffering'); this.retries = 0; this.start(this.compat ? this.cur() : 0); }

  setCompat(on, video = false, at = 0) {
    if (!HAS_FFMPEG && on) { this.say('Install ffmpeg to use compatibility mode'); return; }
    this.compat = on; this.compatVideo = video;
    this.msg.textContent = ''; this.root.classList.remove('errored'); this.root.classList.add('buffering');
    this.startApplied = true;
    this.start(on ? Math.max(0, at) : 0);
    this.say(on ? (video ? 'Compatibility mode (video converted)' : 'Compatibility mode (audio converted)') : 'Direct play');
  }

  /** After a few seconds of playback: silent audio or a black picture usually means an unsupported codec. */
  scheduleHealthCheck() {
    clearTimeout(this.healthT);
    if (this.compat || !HAS_FFMPEG || this.opts.mini) return;
    this.healthT = setTimeout(() => {
      const v = this.video;
      if (this.destroyed || v.paused || this.compat) return;
      const noAudio = typeof v.webkitAudioDecodedByteCount === 'number' && v.webkitAudioDecodedByteCount === 0 && v.currentTime > 2;
      const noVideo = v.readyState >= 2 && v.currentTime > 2 && v.videoWidth === 0;
      if (noVideo) { this.say('Video codec not supported – converting…'); this.setCompat(true, true, this.cur()); }
      else if (noAudio) { this.say('Audio codec not supported – converting…'); this.setCompat(true, false, this.cur()); }
    }, 4500);
  }

  // ---------- state & controls ----------

  cur() { return (this.video.currentTime || 0) + (this.compat ? this.offset : 0); }
  dur() {
    if (this.src?.live) return 0;
    const d = this.video.duration;
    if (!this.compat && isFinite(d) && d > 0) return d;
    return this.durHint || 0;
  }

  onPlayState() {
    this.playBtn.replaceChildren(icon(this.video.paused ? 'play' : 'pause'));
    this.root.classList.toggle('paused', this.video.paused);
  }

  onTime() {
    const live = this.src?.live;
    const cur = this.cur(), dur = this.dur();
    this.timeLbl.textContent = live ? 'LIVE' : dur ? `${fmtTime(cur)} / ${fmtTime(dur)}` : fmtTime(cur);
    const pct = dur ? Math.min(100, (cur / dur) * 100) : 0;
    this.seek.style.setProperty('--pos', pct + '%');
    this.root.classList.toggle('noseek', !dur);
  }

  updateBuffered() {
    const v = this.video; if (!v.buffered.length || !this.dur()) return;
    const end = v.buffered.end(v.buffered.length - 1) + (this.compat ? this.offset : 0);
    this.seek.style.setProperty('--buf', Math.min(100, (end / this.dur()) * 100) + '%');
  }

  togglePlay() { if (this.video.paused) this.video.play().catch(() => {}); else this.video.pause(); }
  togglePlayDelayed() { clearTimeout(this.clickT); this.clickT = setTimeout(() => this.togglePlay(), 220); }
  toggleMute() { this.video.muted = !this.video.muted; }
  skip(sec) {
    if (this.src?.live) return;
    this.seekTo(Math.max(0, Math.min(this.dur() || 1e9, this.cur() + sec)));
    this.say((sec > 0 ? '+' : '−') + Math.abs(sec) + 's');
  }
  seekTo(t) {
    if (this.compat) { this.msg.textContent = ''; this.root.classList.add('buffering'); this.start(t); } else this.video.currentTime = t;
  }
  setMuted(m) { this.video.muted = m; }
  toggleFullscreen() {
    if (document.fullscreenElement) document.exitFullscreen(); else (this.opts.fullscreenTarget || this.root).requestFullscreen?.().catch(() => {});
  }
  togglePip() {
    if (document.pictureInPictureElement) document.exitPictureInPicture(); else this.video.requestPictureInPicture?.().catch(() => {});
  }

  say(text) {
    this.toast.textContent = text; this.toast.classList.add('show');
    clearTimeout(this.toastT); this.toastT = setTimeout(() => this.toast.classList.remove('show'), 1800);
  }
  setInfo(text) { this.info.textContent = text || ''; }

  seekDown(e) {
    if (!this.dur()) return;
    const bar = this.seek;
    const calc = (ev) => { const r = bar.getBoundingClientRect(); return Math.max(0, Math.min(1, (ev.clientX - r.left) / r.width)); };
    const move = (ev) => { bar.style.setProperty('--pos', calc(ev) * 100 + '%'); };
    const up = (ev) => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); this.seekTo(calc(ev) * this.dur()); };
    window.addEventListener('pointermove', move); window.addEventListener('pointerup', up);
    move(e);
    const tip = bar.querySelector('.pseek-tip');
    bar.onpointermove = (ev) => { const f = calc(ev); tip.textContent = fmtTime(f * this.dur()); tip.style.left = f * 100 + '%'; };
  }

  // ---------- progress ----------

  saveProgress(finished = false) {
    if (!this.src || this.src.live || !this.opts.onProgress) return;
    const dur = this.dur(), cur = this.cur();
    if (!dur || cur < 3) return;
    this.opts.onProgress(cur, dur, finished || cur > dur * 0.95);
  }

  // ---------- subtitles / settings menu ----------

  clearSubs() {
    this.video.querySelectorAll('track').forEach((t) => t.remove());
    this.subUrls?.forEach((u) => URL.revokeObjectURL(u));
    this.subUrls = [];
  }

  addSubtitleFile(file) {
    const reader = new FileReader();
    reader.onload = () => {
      const url = URL.createObjectURL(new Blob([srtToVtt(String(reader.result))], { type: 'text/vtt' }));
      this.subUrls.push(url);
      const t = h('track', { kind: 'subtitles', label: file.name.replace(/\.[^.]+$/, ''), srclang: 'xx', src: url });
      this.video.append(t);
      this.timeout(() => { for (const tt of this.video.textTracks) tt.mode = tt.label === t.label ? 'showing' : 'disabled'; this.renderMenu('subs'); }, 150);
      this.say('Subtitles loaded');
    };
    reader.readAsText(file);
  }

  toggleMenu(section) {
    if (!this.menu.hidden && (!section || this.menuSection === section)) { this.menu.hidden = true; return; }
    this.menu.hidden = false; this.renderMenu(section || 'main');
  }

  textTracks() { return [...this.video.textTracks].filter((t) => t.kind === 'subtitles' || t.kind === 'captions'); }

  renderMenu(section) {
    this.menuSection = section;
    const m = clear(this.menu);
    const row = (label, active, fn, hint) => h('button.pmenu-row' + (active ? '.on' : ''), { onclick: fn, type: 'button' }, h('span', label), hint ? h('small', hint) : null);
    const head = (t) => h('div.pmenu-head', t);
    const rerender = () => this.renderMenu(section);
    if (section === 'main') {
      m.append(
        row('Subtitles ›', false, () => this.renderMenu('subs')),
        this.audioTracks().length > 1 ? row('Audio track ›', false, () => this.renderMenu('audio')) : null,
        this.hls && this.hls.levels?.length > 1 ? row('Quality ›', false, () => this.renderMenu('quality')) : null,
        !this.src?.live ? row('Speed ›', false, () => this.renderMenu('speed'), this.video.playbackRate + '×') : null,
        row('Picture ›', false, () => this.renderMenu('aspect')),
        HAS_FFMPEG ? row('Compatibility mode', this.compat, () => { this.menu.hidden = true; this.setCompat(!this.compat, false, this.cur()); }, this.compat ? 'on' : 'off') : null);
    } else if (section === 'subs') {
      const tracks = this.textTracks();
      const cur = tracks.find((t) => t.mode === 'showing');
      m.append(head('Subtitles'), row('Off', !cur, () => { tracks.forEach((t) => (t.mode = 'disabled')); rerender(); }));
      tracks.forEach((t, i) => m.append(row(t.label || t.language || `Track ${i + 1}`, t === cur, () => { tracks.forEach((x) => (x.mode = x === t ? 'showing' : 'disabled')); rerender(); })));
      const fileIn = h('input', { type: 'file', accept: '.srt,.vtt', hidden: true, onchange: (e) => e.target.files[0] && this.addSubtitleFile(e.target.files[0]) });
      const s = this.settings();
      m.append(row('Load subtitle file (.srt / .vtt)…', false, () => fileIn.click()), fileIn,
        h('div.pmenu-inline', h('span', 'Size'),
          h('button.mini-btn', { onclick: () => { this.opts.patchSettings?.({ subtitleScale: Math.max(0.6, +((this.settings().subtitleScale || 1) - 0.15).toFixed(2)) }); this.opts.applyCue?.(); } }, 'A−'),
          h('button.mini-btn', { onclick: () => { this.opts.patchSettings?.({ subtitleScale: Math.min(2.5, +((this.settings().subtitleScale || 1) + 0.15).toFixed(2)) }); this.opts.applyCue?.(); } }, 'A+'),
          h('label.chk', h('input', { type: 'checkbox', checked: !!s.subtitleBackground, onchange: (e) => { this.opts.patchSettings?.({ subtitleBackground: e.target.checked }); this.opts.applyCue?.(); } }), ' Background')),
        tracks.length === 0 ? h('div.pmenu-note', 'Streams from IPTV portals rarely carry subtitle tracks in a browser — load an .srt/.vtt file for movies and shows.') : null);
    } else if (section === 'audio') {
      m.append(head('Audio'));
      this.audioTracks().forEach((t) => m.append(row(t.label, t.on, () => { t.set(); rerender(); })));
    } else if (section === 'quality') {
      m.append(head('Quality'), row('Auto', this.hls.currentLevel === -1, () => { this.hls.currentLevel = -1; rerender(); }));
      this.hls.levels.forEach((l, i) => m.append(row(l.height ? l.height + 'p' : Math.round(l.bitrate / 1000) + ' kbps', this.hls.currentLevel === i, () => { this.hls.currentLevel = i; rerender(); })));
    } else if (section === 'speed') {
      m.append(head('Speed'));
      [0.5, 0.75, 1, 1.25, 1.5, 2].forEach((s) => m.append(row(s + '×', this.video.playbackRate === s, () => { this.video.playbackRate = s; rerender(); })));
    } else if (section === 'aspect') {
      m.append(head('Picture'));
      [['Fit', 'contain'], ['Fill (crop)', 'cover'], ['Stretch', 'fill']].forEach(([l, v]) => m.append(row(l, this.video.style.objectFit === v || (!this.video.style.objectFit && v === 'contain'), () => { this.video.style.objectFit = v; rerender(); })));
    }
    if (section !== 'main') m.prepend(h('button.pmenu-back', { onclick: () => this.renderMenu('main'), type: 'button' }, '‹ Back'));
  }

  audioTracks() {
    if (this.hls && this.hls.audioTracks?.length > 1) {
      return this.hls.audioTracks.map((t, i) => ({ label: t.name || t.lang || `Audio ${i + 1}`, on: this.hls.audioTrack === i, set: () => { this.hls.audioTrack = i; } }));
    }
    const at = this.video.audioTracks;
    if (at && at.length > 1) return [...at].map((t, i) => ({ label: t.label || t.language || `Audio ${i + 1}`, on: t.enabled, set: () => { [...at].forEach((x, j) => (x.enabled = i === j)); } }));
    return [];
  }

  // ---------- keyboard ----------

  bindKeys() {
    let digits = '', digitT = null;
    this.keyHandler = (e) => {
      if (this.destroyed || e.ctrlKey || e.metaKey || e.altKey) return;
      if (this.opts.mini || (this.opts.isActive && !this.opts.isActive())) return;
      const tag = e.target?.tagName;
      if (tag === 'INPUT' && e.target.type !== 'range' && e.target.type !== 'checkbox') return;
      if (tag === 'TEXTAREA' || tag === 'SELECT') return;
      const live = this.src?.live;
      let used = true;
      switch (e.key) {
        case ' ': case 'k': case 'K': this.togglePlay(); break;
        case 'ArrowRight': if (live) used = false; else this.skip(e.shiftKey ? 60 : 10); break;
        case 'ArrowLeft': if (live) used = false; else this.skip(e.shiftKey ? -60 : -10); break;
        case 'j': case 'J': this.skip(-10); break;
        case 'l': case 'L': if (this.opts.onList) this.opts.onList(); else this.skip(10); break;
        case 'ArrowUp': if (live && this.opts.onZap) this.opts.onZap(-1); else { this.video.volume = Math.min(1, this.video.volume + 0.05); this.vol.value = this.video.volume; this.say('Volume ' + Math.round(this.video.volume * 100) + '%'); } break;
        case 'ArrowDown': if (live && this.opts.onZap) this.opts.onZap(1); else { this.video.volume = Math.max(0, this.video.volume - 0.05); this.vol.value = this.video.volume; this.say('Volume ' + Math.round(this.video.volume * 100) + '%'); } break;
        case 'PageUp': this.opts.onZap ? this.opts.onZap(-1) : this.opts.onPrev?.(); break;
        case 'PageDown': this.opts.onZap ? this.opts.onZap(1) : this.opts.onNext?.(); break;
        case 'n': case 'N': this.opts.onNext?.(); break;
        case 'p': case 'P': this.opts.onPrev?.(); break;
        case 'm': case 'M': this.toggleMute(); break;
        case 'f': case 'F': this.toggleFullscreen(); break;
        case 'c': case 'C': this.toggleMenu('subs'); break;
        case 'i': case 'I': this.wake(); break;
        case 'Escape': if (!this.menu.hidden) this.menu.hidden = true; else if (document.fullscreenElement) document.exitFullscreen(); else if (this.opts.onClose) this.opts.onClose(); else used = false; break;
        default:
          if (/^[0-9]$/.test(e.key) && this.opts.onNumber && live) {
            digits += e.key; clearTimeout(digitT); this.say('Channel ' + digits);
            digitT = setTimeout(() => { this.opts.onNumber(parseInt(digits, 10)); digits = ''; }, 1200);
          } else used = false;
      }
      if (used) { e.preventDefault(); e.stopPropagation(); this.wake(); }
    };
    document.addEventListener('keydown', this.keyHandler, true);
  }

  destroy() {
    if (this.destroyed) return;
    this.saveProgress();
    this.destroyed = true;
    this.token++;
    document.removeEventListener('keydown', this.keyHandler, true);
    this.timers.forEach((t) => { clearTimeout(t); clearInterval(t); });
    clearTimeout(this.hideT); clearTimeout(this.toastT); clearTimeout(this.clickT); clearTimeout(this.healthT);
    this.stopEngines();
    this.clearSubs();
    this.root.classList.remove('player', 'mini', 'active', 'live', 'buffering', 'errored', 'paused', 'noseek');
    clear(this.root);
  }
}

function clearElement(el) { while (el.firstChild) el.removeChild(el.firstChild); }
