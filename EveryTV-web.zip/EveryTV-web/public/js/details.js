// Title details (movies, series + episodes) and the full-screen player flow with resume / autoplay.
import { h, clear, fmtTime } from './util.js';
import { Player } from './player.js';
import { store } from './store.js';
import { S, pushOverlay, closeTopOverlay, getProgress, saveProgress, profileProgress, isFav, toggleFav, posterEl, spinner, errorBox, applyCue, toast, LIVE, MOVIE, SERIES } from './ctx.js';

const detailCache = new Map();
let current = null; // the details box currently open (refreshed after the player closes)

export function openDetails(item) {
  if (item.type === LIVE) return play({ item });
  const root = h('div.modal-bg');
  const box = h('div.details');
  root.append(box);
  document.getElementById('overlays').append(root);
  pushOverlay(() => { root.remove(); if (current?.box === box) current = null; });
  root.addEventListener('mousedown', (e) => { if (e.target === root) closeTopOverlay(); });
  current = { box, item };
  render(box, item);
}

async function render(box, item) {
  clear(box);
  const hero = h('div.d-hero', { style: item.backdrop || item.poster ? { backgroundImage: `url("${item.backdrop || item.poster}")` } : {} });
  const body = h('div.d-body');
  box.append(hero, h('button.d-close', { onclick: closeTopOverlay, 'aria-label': 'Close' }, '✕'), body);
  hero.append(h('div.d-hero-fade'), h('h1.d-title', item.name));
  body.append(spinner());

  const key = `${S.profile.id}|${item.type}|${item.id}`;
  try {
    if (item.type === MOVIE) {
      let full = detailCache.get(key);
      if (!full) { full = await S.provider.movieDetails(item).catch(() => item); detailCache.set(key, full); }
      renderMovie(box, hero, body, full);
    } else {
      let info = detailCache.get(key);
      if (!info) { info = await S.provider.seriesInfo(item); detailCache.set(key, info); }
      renderSeries(box, hero, body, info);
    }
  } catch (e) {
    clear(body);
    body.append(meta(item), errorBox(e.message || String(e), () => render(box, item)));
  }
}

function meta(it) {
  const bits = [it.year, it.rating ? '★ ' + it.rating : null, it.duration, it.genre].filter(Boolean);
  return h('div.d-meta', bits.map((b) => h('span', b)));
}

function facts(it) {
  return h('div.d-facts',
    it.plot ? h('p.d-plot', it.plot) : null,
    it.cast ? h('p', h('b', 'Cast: '), it.cast) : null,
    it.director ? h('p', h('b', 'Director: '), it.director) : null);
}

function favButton(it) {
  const b = h('button.btn.ghost', { onclick: () => { toggleFav(it); b.textContent = isFav(it) ? '✓ In My List' : '+ My List'; } }, isFav(it) ? '✓ In My List' : '+ My List');
  return b;
}

function renderMovie(box, hero, body, it) {
  clear(body);
  if (it.backdrop) hero.style.backgroundImage = `url("${it.backdrop}")`;
  const p = getProgress(it, null);
  const resumable = p && !p.finished && p.positionMs > 10000;
  body.append(
    h('div.d-actions',
      h('button.btn', { onclick: () => play({ item: it }) }, resumable ? `▶ Resume ${fmtTime(p.positionMs / 1000)}` : '▶ Play'),
      resumable ? h('button.btn.ghost', { onclick: () => play({ item: it, startOver: true }) }, 'Start over') : null,
      favButton(it)),
    resumable ? h('div.d-resume', h('div', { style: { width: Math.round(p.positionMs / p.durationMs * 100) + '%' } })) : null,
    meta(it), facts(it));
}

function renderSeries(box, hero, body, info) {
  clear(body);
  const it = info.item;
  if (it.backdrop) hero.style.backgroundImage = `url("${it.backdrop}")`;
  const seasons = Object.keys(info.seasons).map(Number).sort((a, b) => a - b);
  const flat = seasons.flatMap((s) => info.seasons[s]);
  const prog = profileProgress().filter((p) => p.type === SERIES && p.item.id === it.id && p.episode);

  // What should the main button do? Resume the last episode, or move on to the next one.
  let target = flat[0], resume = null;
  const last = prog[0];
  if (last) {
    const idx = flat.findIndex((e) => e.id === last.episode.id);
    if (idx >= 0) {
      if (!last.finished && last.positionMs > 10000) { target = flat[idx]; resume = last; }
      else target = flat[idx + 1] || flat[idx];
    }
  }
  const label = (e) => `S${e.season}:E${e.episode}`;
  const playFrom = (ep, startOver = false) => play({ item: it, episode: ep, queue: flat.map((e) => ({ item: it, episode: e })), index: flat.indexOf(ep), startOver });

  body.append(
    h('div.d-actions',
      h('button.btn', { onclick: () => playFrom(target) }, resume ? `▶ Resume ${label(target)} · ${fmtTime(resume.positionMs / 1000)}` : `▶ Play ${label(target)}`),
      favButton(it)),
    meta(it), facts(it));

  const epList = h('div.ep-list');
  let current = target ? target.season : seasons[0];
  const tabs = h('div.season-tabs');
  const draw = () => {
    clear(tabs); clear(epList);
    if (seasons.length > 1) seasons.forEach((s) => tabs.append(h('button.tab' + (s === current ? '.on' : ''), { onclick: () => { current = s; draw(); } }, `Season ${s}`)));
    for (const ep of info.seasons[current] || []) {
      const p = getProgress(it, ep);
      epList.append(h('div.ep', { tabIndex: 0, onclick: () => playFrom(ep, false), onkeydown: (e) => { if (e.key === 'Enter') playFrom(ep); } },
        h('div.ep-num', ep.episode),
        posterEl({ name: ep.title, poster: ep.image || it.poster }, 'ep-thumb'),
        h('div.ep-info',
          h('div.ep-title', ep.title, p?.finished ? h('span.watched', ' ✓') : null),
          ep.plot ? h('div.ep-plot', ep.plot) : null,
          p && !p.finished && p.positionMs > 10000 ? h('div.ep-prog', h('div', { style: { width: Math.round(p.positionMs / p.durationMs * 100) + '%' } })) : null),
        ep.durationSecs ? h('div.ep-dur', Math.round(ep.durationSecs / 60) + ' min') : null));
    }
  };
  body.append(tabs, epList);
  draw();
}

// ---------- player ----------

export async function play({ item, episode = null, queue = null, index = 0, startOver = false }) {
  const list = queue || [{ item, episode }];
  let i = index;
  const root = h('div.player-overlay');
  const host = h('div.player-host');
  root.append(host);
  document.getElementById('overlays').append(root);
  let player = null;
  pushOverlay(() => {
    player?.destroy(); root.remove();
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    if (current?.box.isConnected) render(current.box, current.item); // show Resume / next episode right away
  });

  const entryOf = () => list[i];
  player = new Player(host, {
    getSettings: () => store.settings(),
    patchSettings: (p) => { store.patchSettings(p); applyCue(); },
    applyCue,
    fullscreenTarget: root,
    isActive: () => root.isConnected,
    onClose: closeTopOverlay,
    onProgress: (sec, dur, finished) => { const e = entryOf(); saveProgress(e.item, e.episode, sec, dur, finished); },
    onEnded: () => { if (store.settings().autoplayNext && i + 1 < list.length) { toast('Playing next episode'); loadAt(i + 1); } else closeTopOverlay(); },
    onNext: list.length > 1 ? () => { if (i + 1 < list.length) loadAt(i + 1); } : null,
    onPrev: list.length > 1 ? () => { if (i > 0) loadAt(i - 1); } : null,
  });

  async function loadAt(n, so = false) {
    player.saveProgress();
    i = n;
    const { item: it, episode: ep } = entryOf();
    const live = it.type === LIVE;
    const subtitle = ep ? `S${ep.season}:E${ep.episode} · ${ep.title}` : (it.year || '');
    player.title.textContent = it.name; player.subtitleLine.textContent = subtitle;
    player.root.classList.add('buffering'); player.msg.textContent = '';
    let url;
    try { url = await S.provider.resolve(it, ep); }
    catch (e) { player.showError(e.message || 'Could not get a stream link.'); return; }
    if (!player || player.destroyed) return;
    const p = getProgress(it, ep);
    const startAt = !so && !live && store.settings().autoResume && p && !p.finished && p.positionMs > 10000 ? p.positionMs / 1000 : 0;
    if (live) saveProgress(it, null, 0, 0, false); // feeds the "what I watch" scoring
    await player.load({ url, headers: S.provider.playbackHeaders(), live, title: it.name, subtitle, startAt, durationHint: ep?.durationSecs || (p ? p.durationMs / 1000 : 0), compat: store.settings().compatMode });
  }
  loadAt(i, startOver);
}

S.openDetails = openDetails;
S.play = play;
