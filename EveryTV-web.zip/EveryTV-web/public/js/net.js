// Talks to the local EveryTV server, which forwards requests to your portal.

const TOKEN = document.querySelector('meta[name="etv-token"]')?.content || '';
export const HAS_FFMPEG = document.querySelector('meta[name="etv-ffmpeg"]')?.content === '1';

export class HttpError extends Error {
  constructor(code, body) { super(`HTTP ${code}`); this.code = code; this.body = body; }
}
export class NetError extends Error {}

function b64url(obj) {
  const bytes = new TextEncoder().encode(JSON.stringify(obj));
  let s = '';
  bytes.forEach((b) => { s += String.fromCharCode(b); });
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function qs(url, headers, extra = {}) {
  const p = new URLSearchParams({ t: TOKEN, u: url, ...extra });
  if (headers && Object.keys(headers).length) p.set('h', b64url(headers));
  return p.toString();
}

/** URL the <video>/<img> can load; the local server adds the right headers. */
export function proxied(url, headers = {}) { return `/proxy?${qs(url, headers)}`; }
export function transcoded(url, headers = {}, { ss = 0, video = false } = {}) {
  const extra = {};
  if (ss > 0) extra.ss = String(Math.floor(ss));
  if (video) extra.video = 'h264';
  return `/transcode?${qs(url, headers, extra)}`;
}

async function localFetch(path, opts) {
  try {
    return await fetch(path, opts);
  } catch {
    throw new NetError('EveryTV can\'t reach its helper on this computer. Make sure the start script is still running.');
  }
}

async function check(r, body) {
  if (r.headers.get('X-Proxy-Error')) {
    let m = body;
    try { m = JSON.parse(body).error; } catch { /* keep text */ }
    throw new NetError(m || 'Network error');
  }
  if (!r.ok) throw new HttpError(r.status, body.slice(0, 300));
}

export async function fetchText(url, headers = {}, { gz = true, signal } = {}) {
  const r = await localFetch(`/proxy?${qs(url, headers, gz ? { gz: '1' } : {})}`, { signal });
  const body = await r.text();
  await check(r, body);
  return body;
}

export async function probe(url, headers = {}) {
  const r = await localFetch(`/probe?${qs(url, headers)}`);
  const body = await r.text();
  await check(r, body);
  return JSON.parse(body);
}

export async function sniff(url, headers = {}) {
  const r = await localFetch(`/sniff?${qs(url, headers)}`);
  const body = await r.text();
  await check(r, body);
  return JSON.parse(body);
}
