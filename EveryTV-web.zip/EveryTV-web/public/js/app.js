// EveryTV web — boot, navigation and routing.
import { h, clear } from './util.js';
import { store } from './store.js';
import { createProvider } from './providers.js';
import { S, applyCue, closeTopOverlay, overlayDepth, spinner } from './ctx.js';
import './details.js';
import { renderHome, renderBrowse, renderSearch, renderList } from './views.js';
import { renderLive } from './live.js';
import { openSourceForm, renderSettings, loadM3uText } from './settings.js';

const app = document.getElementById('app');
let view = null, tabsEl = null, searchEl = null;

const TABS = [['home', 'Home'], ['live', 'Live TV'], ['movies', 'Movies'], ['series', 'Series'], ['list', 'My List']];

function parseRoute() {
  const parts = location.hash.replace(/^#\/?/, '').split('/');
  return { name: parts[0] || 'home', arg: decodeURIComponent(parts.slice(1).join('/')) };
}
S.go = (name, arg) => { const next = '#/' + name + (arg ? '/' + encodeURIComponent(arg) : ''); if (location.hash === next) render(); else location.hash = next; };

function wordmark(size = '') { return h('span.wordmark' + size, 'EveryTV'); }

// ---------- shells ----------

function buildShell() {
  clear(app);
  searchEl = h('input.nav-search', { type: 'search', placeholder: 'Search titles & channels  ( / )', onkeydown: (e) => { if (e.key === 'Enter' && searchEl.value.trim()) S.go('search', searchEl.value.trim()); } });
  tabsEl = h('nav.tabs', TABS.map(([k, n]) => h('a.navtab', { href: '#/' + k, 'data-k': k }, n)));
  const menu = h('div.profile-menu', { hidden: true });
  const avatar = h('button.avatar', { title: 'Sources & settings', onclick: (e) => { e.stopPropagation(); menu.hidden = !menu.hidden; if (!menu.hidden) drawMenu(menu); } }, (S.profile.name[0] || '?').toUpperCase());
  document.addEventListener('click', () => { menu.hidden = true; });
  view = h('main#view');
  app.append(h('header.nav', h('a.brand', { href: '#/home' }, wordmark()), tabsEl, h('div.nav-right', searchEl, h('div.avatar-wrap', avatar, menu))), view);
}

function drawMenu(menu) {
  clear(menu);
  store.profiles().forEach((p) => menu.append(h('button' + (p.id === S.profile.id ? '.cur' : ''), { onclick: () => { if (p.id !== S.profile.id) activate(p); menu.hidden = true; } }, (p.id === S.profile.id ? '✓ ' : '') + p.name)));
  menu.append(h('hr'), h('button', { onclick: () => S.go('settings') }, '⚙ Settings'),
    h('button', { onclick: () => openSourceForm({ onDone: (np, prov) => activate(np, prov) }) }, '+ Add source'));
}

function splash(text) { clear(app); app.append(h('div.splash', wordmark('.big'), spinner(text))); }

function connectError(profile, err) {
  clear(app);
  app.append(h('div.splash', wordmark('.big'),
    h('div.errbox', h('h3', `Couldn't connect to “${profile.name}”`), h('pre', err.message || String(err))),
    h('div.sf-actions',
      h('button.btn', { onclick: () => activate(profile) }, 'Try again'),
      h('button.btn.ghost', { onclick: () => openSourceForm({ profile, first: true, onDone: (np, prov) => activate(np, prov) }) }, 'Edit source'),
      store.profiles().length > 1 ? h('button.btn.ghost', { onclick: () => { const other = store.profiles().find((p) => p.id !== profile.id); activate(other); } }, 'Use another source') : null)));
}

// ---------- routing ----------

async function render() {
  S.cleanup?.(); S.cleanup = null;
  if (!view) return;
  clear(view);
  window.scrollTo(0, 0);
  const r = parseRoute();
  tabsEl.querySelectorAll('.navtab').forEach((a) => a.classList.toggle('on', a.dataset.k === r.name));
  view.className = r.name === 'live' ? 'full' : '';
  try {
    switch (r.name) {
      case 'live': await renderLive(view); break;
      case 'movies': await renderBrowse(view, 'MOVIE'); break;
      case 'series': await renderBrowse(view, 'SERIES'); break;
      case 'list': renderList(view); break;
      case 'search': searchEl.value = r.arg; await renderSearch(view, r.arg); break;
      case 'settings': await renderSettings(view, { activate, rerender: render }); break;
      default: await renderHome(view);
    }
  } catch (e) {
    console.error(e);
    view.append(h('div.errbox', h('pre', e.message || String(e))));
  }
}
S.rerender = render;
window.addEventListener('hashchange', () => { if (S.profile && !overlayDepth()) render(); });

// ---------- activation ----------

async function activate(profile, provided) {
  S.cleanup?.(); S.cleanup = null;
  while (overlayDepth()) { history.back(); await new Promise((r) => setTimeout(r, 30)); }
  splash(`Connecting to ${profile.name}…`);
  let provider = provided;
  try {
    if (!provider) {
      provider = createProvider(profile, store.settings, await loadM3uText(profile));
      await provider.connect();
    }
  } catch (e) { connectError(profile, e); return; }
  S.provider?.close();
  S.provider = provider; S.profile = profile;
  store.patchSettings({ lastProfileId: profile.id });
  buildShell();
  render();
}

// ---------- global keys ----------

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && overlayDepth()) { closeTopOverlay(); return; }
  if (e.key === '/' && searchEl && !/INPUT|TEXTAREA|SELECT/.test(e.target.tagName) && !overlayDepth()) { e.preventDefault(); searchEl.focus(); searchEl.select(); }
});

// ---------- boot ----------

(async function boot() {
  applyCue();
  const profiles = store.profiles();
  if (!profiles.length) {
    clear(app);
    app.append(h('div.splash', wordmark('.big'), h('p.tagline', 'All your TV, movies and series in one place.')));
    openSourceForm({ first: true, onDone: (p, prov) => activate(p, prov) });
    return;
  }
  const last = profiles.find((p) => p.id === store.settings().lastProfileId) || profiles[0];
  activate(last);
})();
