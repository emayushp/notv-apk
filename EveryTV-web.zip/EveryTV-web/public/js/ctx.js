// Shared state and small UI building blocks used by all screens.
import { h, clear } from './util.js';
import { proxied } from './net.js';
import { store, catalog, categoryScores } from './store.js';
import { isAdultName, LIVE, MOVIE, SERIES, Keys } from './providers.js';

export const S = {
  profile: null,
  provider: null,
  cleanup: null,        // called when leaving the current view
  openDetails: null,    // set by details.js
  play: null,           // set by details.js
  go: null,             // set by app.js
  rerender: null,
};

// ---------- toasts ----------

export function toast(msg, ms = 2600) {
  const t = h('div.toast', msg);
  document.getElementById('toasts').append(t);
  requestAnimationFrame(() => t.classList.add('show'));
  setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 300); }, ms);
}

// ---------- overlays tied to the browser Back button ----------

const stack = [];
export function pushOverlay(closeFn) {
  stack.push(closeFn);
  history.pushState({ ov: stack.length }, '');
}
/** Close the top overlay (goes through history so the Back button and the UI agree). */
export function closeTopOverlay() { if (stack.length) history.back(); }
window.addEventListener('popstate', () => { const f = stack.pop(); if (f) f(); });
export const overlayDepth = () => stack.length;

// ---------- progress & favourites ----------

const slim = (it) => ({ id: it.id, name: it.name, type: it.type, categoryId: it.categoryId, poster: it.poster, backdrop: it.backdrop, year: it.year, rating: it.rating, genre: it.genre, url: it.url, ext: it.ext, extra: it.extra, number: it.number, epgId: it.epgId, plot: it.plot ? it.plot.slice(0, 400) : null });

export function progressKey(item, ep) {
  const pid = S.profile.id;
  if (item.type === LIVE) return Keys.live(pid, item.id);
  if (ep) return Keys.episode(pid, item.id, ep.id);
  return Keys.movie(pid, item.id);
}
export function getProgress(item, ep) { return store.progress()[progressKey(item, ep)] || null; }
export function saveProgress(item, ep, posSec, durSec, finished = false) {
  const map = store.progress();
  const key = progressKey(item, ep);
  map[key] = { key, profileId: S.profile.id, type: item.type, item: slim(item), episode: ep ? { ...ep, plot: null } : null, positionMs: Math.floor(posSec * 1000), durationMs: Math.floor(durSec * 1000), updatedAt: Date.now(), finished };
  store.saveProgress(map);
}
export function profileProgress() {
  return Object.values(store.progress()).filter((p) => p.profileId === S.profile.id).sort((a, b) => b.updatedAt - a.updatedAt);
}

export const isFav = (item) => store.favorites().some((f) => f.profileId === S.profile.id && f.item.id === item.id && f.item.type === item.type);
export function toggleFav(item) {
  let list = store.favorites();
  if (isFav(item)) { list = list.filter((f) => !(f.profileId === S.profile.id && f.item.id === item.id && f.item.type === item.type)); toast('Removed from My List'); }
  else { list.unshift({ profileId: S.profile.id, item: slim(item), addedAt: Date.now() }); toast('Added to My List'); }
  store.saveFavorites(list);
}
export const favorites = () => store.favorites().filter((f) => f.profileId === S.profile.id).map((f) => f.item);

// ---------- cached data access ----------

export async function getCategories(type, { force = false } = {}) {
  const pid = S.profile.id;
  const cats = await catalog.get(catalog.key(pid, 'cats', type), () => S.provider.categories(type), { force });
  return store.settings().hideAdult ? cats.filter((c) => !isAdultName(c.name)) : cats;
}
export function getItems(type, catId, page = 1, { force = false } = {}) {
  return catalog.get(catalog.key(S.profile.id, 'items', type, catId, page), () => S.provider.items(type, catId, page), { force });
}
export function peekItems(type, catId, page = 1) { return catalog.peek(catalog.key(S.profile.id, 'items', type, catId, page)); }

/** Categories ordered by what this profile actually watches; returns {ordered, scored:Set} */
export function rankCategories(type, cats) {
  const scores = categoryScores(S.profile.id);
  const sc = (c) => scores[`${type}|${c.id}`] || 0;
  const scored = cats.filter((c) => sc(c) > 0).sort((a, b) => sc(b) - sc(a));
  const rest = cats.filter((c) => sc(c) === 0);
  return { ordered: [...scored, ...rest], scoredIds: new Set(scored.map((c) => c.id)) };
}

// ---------- UI pieces ----------

export function initials(name) {
  return (name || '?').replace(/[^\p{L}\p{N} ]/gu, '').split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase() || '?';
}
const hue = (s) => { let x = 0; for (const c of s || '') x = (x * 31 + c.charCodeAt(0)) % 360; return x; };

export function posterEl(item, cls = '', progress = null) {
  const box = h('div.poster' + (cls ? '.' + cls : ''), { style: { '--hue': hue(item.name) } });
  const bar = progress != null ? h('div.card-prog', h('div', { style: { width: Math.round(progress * 100) + '%' } })) : null;
  const placeholder = () => { box.classList.add('ph'); box.replaceChildren(h('span', initials(item.name)), bar); };
  if (!item.poster) { placeholder(); return box; }
  let retried = false;
  const img = h('img', { src: item.poster, loading: 'lazy', alt: '', referrerPolicy: 'no-referrer', decoding: 'async' });
  img.addEventListener('error', () => {
    if (!retried && S.provider) { retried = true; img.src = proxied(item.poster, S.provider.playbackHeaders()); } else placeholder();
  });
  box.append(img);
  if (bar) box.append(bar);
  return box;
}

export function card(item, { progress = null, label = null, onclick, wide = false } = {}) {
  const el = h('div.card' + (wide ? '.wide' : '') + (item.type === LIVE ? '.live-card' : ''), { tabIndex: 0, role: 'button', onclick: onclick || (() => S.openDetails(item)),
    onkeydown: (e) => { if (e.key === 'Enter') (onclick || (() => S.openDetails(item)))(); } },
    posterEl(item, '', progress),
    h('div.card-title', item.name),
    label ? h('div.card-sub', label) : (item.year || item.rating ? h('div.card-sub', [item.year, item.rating ? '★ ' + item.rating : null].filter(Boolean).join(' · ')) : null),
    h('button.card-star' + (isFav(item) ? '.on' : ''), { title: 'My List', onclick: (e) => { e.stopPropagation(); toggleFav(item); e.currentTarget.classList.toggle('on', isFav(item)); } }, '★'));
  return el;
}

export function row(title, nodesOrPromise, { sub = null } = {}) {
  const scroller = h('div.row-scroll');
  const wrap = h('section.row', h('div.row-head', h('h2', title), sub ? h('span.row-sub', sub) : null),
    h('div.row-body',
      h('button.row-arrow.left', { onclick: () => scroller.scrollBy({ left: -scroller.clientWidth * 0.85, behavior: 'smooth' }) }, '‹'),
      scroller,
      h('button.row-arrow.right', { onclick: () => scroller.scrollBy({ left: scroller.clientWidth * 0.85, behavior: 'smooth' }) }, '›')));
  const fill = (nodes) => { clear(scroller); scroller.append(...nodes); wrap.hidden = nodes.length === 0; };
  if (nodesOrPromise && typeof nodesOrPromise.then === 'function') {
    scroller.append(...Array.from({ length: 8 }, () => h('div.card.skeleton')));
    nodesOrPromise.then(fill).catch(() => { wrap.hidden = true; });
  } else fill(nodesOrPromise || []);
  return wrap;
}

/** Renders `items` in batches as the user scrolls. */
export function lazyList(container, items, renderOne, batch = 120) {
  let shown = 0;
  const sentinel = h('div.sentinel');
  const more = () => {
    const next = items.slice(shown, shown + batch);
    shown += next.length;
    sentinel.remove();
    container.append(...next.map(renderOne));
    if (shown < items.length) { container.append(sentinel); io.observe(sentinel); }
  };
  const io = new IntersectionObserver((es) => { if (es.some((e) => e.isIntersecting)) { io.unobserve(sentinel); more(); } }, { root: null, rootMargin: '600px' });
  more();
  return () => io.disconnect();
}

export function spinner(text = 'Loading…') { return h('div.loading', h('div.spin'), h('span', text)); }
export function errorBox(msg, retry) {
  return h('div.errbox', h('pre', msg), retry ? h('button.btn', { onclick: retry }, 'Try again') : null);
}

export function applyCue() {
  const s = store.settings();
  const r = document.documentElement.style;
  r.setProperty('--cue-scale', String(s.subtitleScale || 1));
  r.setProperty('--cue-bg', s.subtitleBackground ? '0.7' : '0');
}

export const TYPE_LABEL = { LIVE: 'Live TV', MOVIE: 'Movies', SERIES: 'Series' };
export { LIVE, MOVIE, SERIES };
