// Add/edit sources and the Settings screen.
import { h, clear } from './util.js';
import { store, catalog, idbGet, idbSet, idbDel, exportBackup, importBackup } from './store.js';
import { createProvider, randomMac, normalizeMac } from './providers.js';
import { HAS_FFMPEG } from './net.js';
import { S, toast, applyCue, pushOverlay, closeTopOverlay } from './ctx.js';

export const loadM3uText = async (p) => (p.type === 'M3U' && p.url.startsWith('file:') ? idbGet('m3u:' + p.id) : undefined);

const TYPE_NAMES = { STALKER: 'MAG / Stalker portal', XTREAM: 'Xtream Codes', M3U: 'M3U playlist' };
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);

/** onDone(profile, connectedProvider) is called after a successful connection. */
export function openSourceForm({ profile = null, first = false, onDone }) {
  const f = { type: 'STALKER', name: '', url: '', username: '', password: '', mac: '', serial: '', deviceId: '', deviceId2: '', signature: '', epgUrl: '', userAgent: '', ...(profile || {}) };
  let uploaded = null, uploadName = '';
  const root = h('div.modal-bg');
  const card = h('form.sourceform', { onsubmit: (e) => { e.preventDefault(); submit(); } });
  root.append(card);
  document.getElementById('overlays').append(root);
  if (!first) { pushOverlay(() => root.remove()); root.addEventListener('mousedown', (e) => { if (e.target === root) closeTopOverlay(); }); }
  else root.classList.add('solid');

  const field = (label, key, opts = {}) => h('label.field', h('span', label),
    h('input.input', { type: opts.type || 'text', value: f[key] || '', placeholder: opts.ph || '', autocomplete: 'off', spellcheck: false, oninput: (e) => { f[key] = e.target.value; } }),
    opts.hint ? h('small', opts.hint) : null);

  const status = h('div.form-status');
  function draw() {
    clear(card);
    card.append(
      h('div.sf-head', h('span.wordmark', 'EveryTV'), h('h2', profile ? 'Edit source' : first ? 'Add your IPTV source' : 'Add a source'),
        first ? h('p', 'Sign in the same way you do in the phone or TV app.') : null),
      h('div.season-tabs', Object.entries(TYPE_NAMES).map(([k, n]) => h('button.tab' + (f.type === k ? '.on' : ''), { type: 'button', onclick: () => { f.type = k; draw(); } }, n))),
      field('Name', 'name', { ph: 'e.g. Home TV' }));
    if (f.type === 'STALKER') {
      card.append(
        field('Portal URL', 'url', { ph: 'http://portal.example.com/c/', hint: 'The address your provider gave you (…/c/ or …/stalker_portal/c/).' }),
        h('label.field', h('span', 'MAC address'),
          h('div.inline', h('input.input', { value: f.mac || '', placeholder: '00:1A:79:12:34:56', autocomplete: 'off', spellcheck: false, oninput: (e) => { f.mac = e.target.value; } }),
            h('button.btn.ghost.small', { type: 'button', onclick: () => { f.mac = randomMac(); draw(); } }, 'Generate')),
          h('small', 'Must be a MAC your provider activated.')),
        field('Serial number (optional)', 'serial', { hint: 'Leave empty to derive it from the MAC.' }));
      card.append(h('details.adv', h('summary', 'Advanced'), field('Device ID', 'deviceId'), field('Device ID 2', 'deviceId2'), field('Signature', 'signature'), field('User-Agent', 'userAgent', { ph: 'MAG200 default' })));
    } else if (f.type === 'XTREAM') {
      card.append(field('Server URL', 'url', { ph: 'http://server.example.com:8080', hint: 'You can also paste the full get.php link.' }), field('Username', 'username'), field('Password', 'password', { type: 'password' }));
      card.append(h('details.adv', h('summary', 'Advanced'), field('EPG (XMLTV) URL', 'epgUrl'), field('User-Agent', 'userAgent')));
    } else {
      card.append(field('Playlist URL', 'url', { ph: 'http://example.com/playlist.m3u' }),
        h('label.field', h('span', 'or upload a file'), h('input', { type: 'file', accept: '.m3u,.m3u8,.txt', onchange: async (e) => { const file = e.target.files[0]; if (!file) return; uploaded = await file.text(); uploadName = file.name; f.url = 'file:' + file.name; draw(); } }),
          uploadName ? h('small', 'Loaded ' + uploadName) : null));
      card.append(h('details.adv', h('summary', 'Advanced'), field('EPG (XMLTV) URL', 'epgUrl'), field('User-Agent', 'userAgent')));
    }
    card.append(status, h('div.sf-actions', h('button.btn', { type: 'submit' }, profile ? 'Save & connect' : 'Connect'), !first ? h('button.btn.ghost', { type: 'button', onclick: closeTopOverlay }, 'Cancel') : null));
  }

  async function submit() {
    clear(status);
    if (!f.name.trim()) f.name = f.type === 'STALKER' ? 'MAG portal' : f.type === 'XTREAM' ? 'Xtream' : 'Playlist';
    if (!f.url.trim()) { status.append(h('div.err', 'Please enter the URL.')); return; }
    if (f.type === 'STALKER') { f.mac = normalizeMac(f.mac); if (f.mac.length !== 17) { status.append(h('div.err', 'The MAC address must look like 00:1A:79:12:34:56')); return; } }
    if (f.type === 'XTREAM' && !f.url.includes('username=') && (!f.username || !f.password)) { status.append(h('div.err', 'Username and password are required.')); return; }
    const p = { id: profile?.id || uid(), name: f.name.trim(), type: f.type, url: f.url.trim(), username: f.username.trim(), password: f.password, mac: f.mac, serial: f.serial.trim(), deviceId: f.deviceId.trim(), deviceId2: f.deviceId2.trim(), signature: f.signature.trim(), epgUrl: f.epgUrl.trim(), userAgent: f.userAgent.trim(), createdAt: profile?.createdAt || Date.now() };
    const text = uploaded ?? (p.type === 'M3U' && p.url.startsWith('file:') ? await idbGet('m3u:' + p.id) : undefined);
    const btn = card.querySelector('button[type=submit]');
    btn.disabled = true; status.append(h('div.info', h('div.spin.small'), ' Connecting…'));
    const provider = createProvider(p, store.settings, text);
    try {
      await provider.connect();
    } catch (e) {
      btn.disabled = false; clear(status);
      status.append(h('div.err', h('pre', e.message || String(e))));
      provider.close();
      return;
    }
    if (uploaded != null) await idbSet('m3u:' + p.id, uploaded);
    const list = store.profiles();
    const idx = list.findIndex((x) => x.id === p.id);
    if (idx >= 0) list[idx] = p; else list.push(p);
    store.saveProfiles(list);
    if (idx >= 0) await catalog.clear(p.id);
    if (first) root.remove(); else closeTopOverlay();
    onDone(p, provider);
  }

  draw();
}

// ---------- Settings screen ----------

export async function renderSettings(view, { activate, rerender }) {
  const s = store.settings();
  const profiles = store.profiles();
  const toggle = (label, key, hint) => h('label.set-row', h('div', h('b', label), hint ? h('small', hint) : null),
    h('input', { type: 'checkbox', checked: !!s[key], onchange: (e) => { store.patchSettings({ [key]: e.target.checked }); applyCue(); } }));

  const acct = h('div.acct');
  S.provider?.accountInfo().then((a) => { if (a) acct.append(h('div', `Status: ${a.status || '—'}`), h('div', `Expires: ${a.expires || '—'}`), h('div', a.extra || '')); }).catch(() => {});

  const sources = h('div.sources', profiles.map((p) => h('div.source' + (S.profile?.id === p.id ? '.cur' : ''),
    h('div', h('b', p.name), h('small', ` ${TYPE_NAMES[p.type]}`), S.profile?.id === p.id ? h('span.badge', 'IN USE') : null),
    h('div.source-actions',
      S.profile?.id !== p.id ? h('button.btn.small', { onclick: () => activate(p) }, 'Use') : null,
      h('button.btn.ghost.small', { onclick: () => openSourceForm({ profile: p, onDone: (np, prov) => activate(np, prov) }) }, 'Edit'),
      h('button.btn.ghost.small.danger', { onclick: async () => {
        if (!confirm(`Remove “${p.name}”? Its watch history stays on this computer.`)) return;
        store.saveProfiles(store.profiles().filter((x) => x.id !== p.id));
        await catalog.clear(p.id); await idbDel('m3u:' + p.id);
        if (S.profile?.id === p.id) { const left = store.profiles(); if (left.length) activate(left[0]); else location.reload(); } else rerender();
      } }, 'Remove')))));

  const days = h('select.input', { onchange: (e) => store.patchSettings({ catalogCacheDays: +e.target.value }) },
    [1, 3, 7, 14, 30].map((d) => h('option', { value: d, selected: s.catalogCacheDays === d }, d === 1 ? '1 day' : d + ' days')));
  const fmt = h('select.input', { onchange: (e) => store.patchSettings({ liveFormat: e.target.value }) },
    h('option', { value: 'm3u8', selected: s.liveFormat !== 'ts' }, 'HLS (m3u8) – most compatible'), h('option', { value: 'ts', selected: s.liveFormat === 'ts' }, 'MPEG-TS'));

  view.append(h('div.settings',
    h('h2.page-title', 'Settings'),
    h('section.set-sect', h('h3', 'Sources'), sources, acct, h('button.btn', { onclick: () => openSourceForm({ onDone: (np, prov) => activate(np, prov) }) }, '+ Add source')),
    h('section.set-sect', h('h3', 'Playback'),
      toggle('Resume where I left off', 'autoResume', 'Movies and episodes continue from your last position.'),
      toggle('Play next episode automatically', 'autoplayNext'),
      toggle('Hide adult categories', 'hideAdult', 'Applies to category lists and the Home page.'),
      h('label.set-row', h('div', h('b', 'Live stream format'), h('small', 'Xtream sources only.')), fmt),
      HAS_FFMPEG ? toggle('Always use compatibility mode', 'compatMode', 'Converts audio (and video if needed) with ffmpeg. Use only if a lot of channels have no sound.') : null),
    h('section.set-sect', h('h3', 'Categories & data'),
      h('label.set-row', h('div', h('b', 'Keep lists for'), h('small', 'Categories and titles are saved on this computer so they don’t reload all day.')), days),
      h('div.set-row', h('div', h('b', 'Refresh now'), h('small', 'Download categories and lists again from your provider.')),
        h('button.btn.ghost.small', { onclick: async () => { await catalog.clear(S.profile.id); toast('Lists cleared – reloading'); rerender(); } }, 'Refresh')),
      h('div.set-row', h('div', h('b', 'Backup'), h('small', 'Sources, watch history and My List as a file.')),
        h('div.source-actions',
          h('button.btn.ghost.small', { onclick: () => { const a = h('a', { href: URL.createObjectURL(new Blob([exportBackup()], { type: 'application/json' })), download: 'everytv-backup.json' }); a.click(); } }, 'Export'),
          h('label.btn.ghost.small', 'Import', h('input', { type: 'file', accept: '.json', hidden: true, onchange: async (e) => { try { importBackup(await e.target.files[0].text()); toast('Backup restored'); setTimeout(() => location.reload(), 600); } catch (err) { toast(err.message); } } }))))),
    h('section.set-sect', h('h3', 'Keyboard shortcuts'),
      h('div.keys', [['Space / K', 'Play / pause'], ['← →', 'Back / forward 10s (Shift = 60s)'], ['↑ ↓', 'Volume – or change channel on Live TV'], ['PgUp / PgDn', 'Previous / next channel or episode'], ['0–9', 'Type a channel number'], ['Backspace', 'Previous channel (Live TV)'],
        ['L', 'Channel list (Live) / forward 10s'], ['N / P', 'Next / previous episode'], ['C', 'Subtitles'], ['M', 'Mute'], ['F', 'Fullscreen'], ['Esc', 'Close / exit fullscreen']].map(([k, v]) => h('div', h('kbd', k), h('span', v))))),
    h('section.set-sect', h('h3', 'About'),
      h('p', `EveryTV for the web. ${HAS_FFMPEG ? 'ffmpeg found – compatibility mode is available.' : 'ffmpeg not found – install it to enable compatibility mode (fixes streams with unsupported audio/video).'}`),
      h('p.muted', 'Everything runs on this computer: this page talks to a small helper on localhost, which talks to your provider.'))));
}
