// Home, Movies, Series, Search and My List screens.
import { h, clear, debounce } from './util.js';
import { store, catalog, categoryScores } from './store.js';
import { S, card, row, lazyList, spinner, errorBox, getCategories, getItems, rankCategories, profileProgress, favorites, TYPE_LABEL, LIVE, MOVIE, SERIES, toast } from './ctx.js';

// ---------- Home ----------

export async function renderHome(view) {
  const pid = S.profile.id;
  const prog = profileProgress();
  const resumable = [];
  const seenSeries = new Set();
  for (const p of prog) {
    if (p.type === LIVE || p.finished || !(p.positionMs > 10000)) continue;
    if (p.type === SERIES) { if (seenSeries.has(p.item.id)) continue; seenSeries.add(p.item.id); }
    resumable.push(p);
  }

  const hero = h('div.hero', { hidden: true });
  view.append(hero);
  const rows = h('div.rows');
  view.append(rows);

  const heroFrom = (it, resumeP) => {
    hero.hidden = false;
    clear(hero);
    hero.style.backgroundImage = it.backdrop || it.poster ? `url("${it.backdrop || it.poster}")` : '';
    hero.classList.toggle('poster-bg', !it.backdrop);
    hero.append(h('div.hero-fade'), h('div.hero-text',
      h('h1', it.name),
      h('p', (it.plot || '').slice(0, 220)),
      h('div.d-actions',
        h('button.btn', { onclick: () => (resumeP ? S.play({ item: resumeP.item, episode: resumeP.episode }) : S.openDetails(it)) }, resumeP ? '▶ Resume' : '▶ Play'),
        h('button.btn.ghost', { onclick: () => S.openDetails(it) }, 'ⓘ More info'))));
  };

  if (resumable.length) {
    heroFrom(resumable[0].item, resumable[0]);
    rows.append(row('Continue watching', resumable.slice(0, 20).map((p) => card(p.item, {
      progress: p.durationMs ? p.positionMs / p.durationMs : 0,
      label: p.episode ? `S${p.episode.season}:E${p.episode.episode}` : null,
      onclick: () => S.play({ item: p.item, episode: p.episode }),
    }))));
  }

  const favs = favorites();
  if (favs.length) rows.append(row('My List', favs.slice(0, 30).map((it) => card(it))));

  const recent = prog.filter((p) => p.type === LIVE).slice(0, 20);
  if (recent.length) rows.append(row('Recent channels', recent.map((p) => card(p.item, { onclick: () => S.play({ item: p.item }) }))));

  // Personalised rows: categories you actually watch first, otherwise the first few categories.
  const scores = categoryScores(pid);
  const hasHistory = Object.keys(scores).length > 0;
  for (const type of [MOVIE, SERIES, LIVE]) {
    (async () => {
      let cats;
      try { cats = await getCategories(type); } catch { return; }
      if (!cats.length) return;
      const { ordered, scoredIds } = rankCategories(type, cats);
      const pick = ordered.slice(0, hasHistory && scoredIds.size ? Math.min(3, Math.max(1, scoredIds.size)) : 2);
      for (const c of pick) {
        const title = scoredIds.has(c.id) ? `Because you watch ${c.name}` : `${TYPE_LABEL[type]}: ${c.name}`;
        const r = row(title, getItems(type, c.id, 1).then((res) => {
          const list = res.items.slice(0, 24);
          if (!hero.hidden === false && list.length && type !== LIVE) heroFrom(list.find((x) => x.backdrop || x.poster) || list[0], null);
          return list.map((it) => card(it, it.type === LIVE ? { onclick: () => S.play({ item: it }) } : {}));
        }));
        rows.append(r);
      }
    })();
  }

  if (!resumable.length && !favs.length) {
    rows.prepend(h('div.welcome', h('h2', `Welcome to ${S.profile.name}`), h('p', 'Pick something from the rows below or browse Movies, Series and Live TV. What you watch shapes this page.')));
  }
}

// ---------- Movies / Series browse ----------

export async function renderBrowse(view, type) {
  const pid = S.profile.id;
  const settingsKey = `${pid}|${type}`;
  const side = h('aside.cats');
  const grid = h('div.grid');
  const head = h('div.browse-head');
  const filter = h('input.input', { placeholder: 'Filter categories', oninput: () => drawCats() });
  view.append(h('div.browse', h('div.browse-side', filter, side), h('section.browse-main', head, grid)));

  let cats = [], ranked = null, current = null, stopLazy = null, token = 0;
  try { cats = await getCategories(type); } catch (e) { view.replaceChildren(errorBox(e.message, () => S.rerender())); return; }
  if (!cats.length) { view.replaceChildren(h('div.empty', `No ${TYPE_LABEL[type].toLowerCase()} categories were found on this source.`)); return; }
  ranked = rankCategories(type, cats);
  const remembered = store.settings().lastCategory[settingsKey];
  current = cats.find((c) => c.id === remembered) || ranked.ordered[0];

  function drawCats() {
    clear(side);
    const q = filter.value.trim().toLowerCase();
    let shownHeader = false, shownRest = false;
    for (const c of ranked.ordered) {
      if (q && !c.name.toLowerCase().includes(q)) continue;
      const isScored = ranked.scoredIds.has(c.id);
      if (!q && isScored && !shownHeader) { side.append(h('div.cat-head', 'For you')); shownHeader = true; }
      if (!q && !isScored && !shownRest && shownHeader) { side.append(h('div.cat-head', 'All categories')); shownRest = true; }
      side.append(h('button.cat' + (c.id === current?.id ? '.on' : ''), { onclick: () => select(c) }, c.name));
    }
  }

  async function select(c, force = false) {
    current = c;
    store.patchSettings({ lastCategory: { ...store.settings().lastCategory, [settingsKey]: c.id } });
    drawCats();
    const my = ++token;
    stopLazy?.();
    clear(grid);
    clear(head);
    head.append(h('h2', c.name), h('button.btn.ghost.small', { onclick: () => select(c, true), title: 'Reload this category from your provider' }, '⟳ Refresh'));
    grid.append(spinner());
    try {
      const first = await getItems(type, c.id, 1, { force });
      if (my !== token) return;
      clear(grid);
      if (!first.items.length) { grid.append(h('div.empty', 'Nothing in this category.')); return; }
      const queue = [], seen = new Set();
      let hasMore = first.hasMore, page = 1, busy = false;
      const push = (list) => { for (const it of list) if (!seen.has(it.id)) { seen.add(it.id); queue.push(it); } };
      const sentinel = h('div.sentinel');
      const step = async () => {
        if (busy || my !== token) return;
        busy = true;
        try {
          if (!queue.length && hasMore) {
            page++;
            const r = await getItems(type, c.id, page, { force });
            if (my !== token) return;
            const before = seen.size;
            push(r.items);
            hasMore = r.hasMore && seen.size > before;
          }
          queue.splice(0, 100).forEach((it) => grid.insertBefore(card(it), sentinel));
        } catch { hasMore = false; }
        busy = false;
        if (queue.length || hasMore) { io.unobserve(sentinel); io.observe(sentinel); } else sentinel.remove();
      };
      const io = new IntersectionObserver((es) => { if (es.some((e) => e.isIntersecting)) step(); }, { rootMargin: '900px' });
      stopLazy = () => io.disconnect();
      grid.append(sentinel);
      push(first.items);
      step();
    } catch (e) {
      if (my !== token) return;
      clear(grid); grid.append(errorBox(e.message || String(e), () => select(c, true)));
    }
  }

  drawCats();
  select(current);
  S.cleanup = () => { token++; stopLazy?.(); };
}

// ---------- Search ----------

export async function renderSearch(view, q) {
  view.append(h('h2.page-title', `Results for “${q}”`), spinner('Searching…'));
  let results = [];
  try { results = await S.provider.search(q); } catch (e) { view.replaceChildren(h('h2.page-title', `Results for “${q}”`), errorBox(e.message || String(e))); return; }
  clear(view);
  view.append(h('h2.page-title', `Results for “${q}”`));
  if (!results.length) { view.append(h('div.empty', 'Nothing found. Try fewer words.')); return; }
  for (const type of [MOVIE, SERIES, LIVE]) {
    const list = results.filter((r) => r.type === type);
    if (!list.length) continue;
    const g = h('div.grid');
    view.append(h('h3.sect', `${TYPE_LABEL[type]} (${list.length})`), g);
    lazyList(g, list, (it) => card(it, it.type === LIVE ? { onclick: () => S.play({ item: it }) } : {}), 80);
  }
}

// ---------- My List ----------

export function renderList(view) {
  const favs = favorites();
  view.append(h('h2.page-title', 'My List'));
  if (!favs.length) { view.append(h('div.empty', 'Tap the ★ on any title to save it here.')); return; }
  const g = h('div.grid');
  view.append(g);
  lazyList(g, favs, (it) => card(it, it.type === LIVE ? { onclick: () => S.play({ item: it }) } : {}), 80);
}
