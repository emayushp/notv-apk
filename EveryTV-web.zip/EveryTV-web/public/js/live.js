// Live TV: categories | channel list | player with EPG. Plus multi-screen.
import { h, clear, fmtClock, debounce } from './util.js';
import { Player } from './player.js';
import { store } from './store.js';
import { S, posterEl, spinner, errorBox, getCategories, getItems, rankCategories, profileProgress, favorites, isFav, toggleFav, saveProgress, pushOverlay, closeTopOverlay, overlayDepth, applyCue, lazyList, LIVE, toast } from './ctx.js';

const FAV = '__fav', RECENT = '__recent';

export async function renderLive(view) {
  const pid = S.profile.id;
  const st = { cats: [], cat: null, channels: [], filter: '', playing: null, prev: null, player: null, epgTimer: null, panel: null };

  const catList = h('div.cats');
  const chList = h('div.ch-list');
  const chFilter = h('input.input', { placeholder: 'Search channels', oninput: debounce(() => { st.filter = chFilter.value.trim().toLowerCase(); drawChannels(); }, 120) });
  const stage = h('div.live-stage', h('div.stage-hint', h('div.big', '📺'), h('div', 'Pick a channel to start watching')));
  const epgBox = h('div.epg');
  const title = h('h2');

  view.append(h('div.live',
    h('aside.live-cats', catList),
    h('section.live-channels', h('div.live-ch-head', title, h('button.btn.ghost.small', { onclick: () => openMulti(st.playing, st.channels), title: 'Watch several channels at once' }, '⊞ Multi-screen')), chFilter, chList),
    h('section.live-right', stage, epgBox)));

  let cats;
  try { cats = await getCategories(LIVE); } catch (e) { view.replaceChildren(errorBox(e.message || String(e), () => S.rerender())); return; }
  const { ordered, scoredIds } = rankCategories(LIVE, cats);
  const favCat = { id: FAV, name: '★ My channels' }, recentCat = { id: RECENT, name: '🕘 Recent' };
  st.cats = [favCat, recentCat, ...ordered];
  const remembered = store.settings().lastCategory[`${pid}|LIVE`];
  const startCat = st.cats.find((c) => c.id === remembered) || ordered[0] || recentCat;

  function drawCats() {
    clear(catList);
    st.cats.forEach((c, i) => {
      if (i === 2 && scoredIds.size) catList.append(h('div.cat-head', 'For you'));
      if (i === 2 + scoredIds.size && scoredIds.size && ordered.length > scoredIds.size) catList.append(h('div.cat-head', 'All categories'));
      catList.append(h('button.cat' + (c.id === st.cat?.id ? '.on' : ''), { onclick: () => selectCat(c) }, c.name));
    });
  }

  async function selectCat(c) {
    st.cat = c; drawCats(); title.textContent = c.name;
    if (c.id !== FAV && c.id !== RECENT) store.patchSettings({ lastCategory: { ...store.settings().lastCategory, [`${pid}|LIVE`]: c.id } });
    clear(chList); chList.append(spinner());
    try {
      if (c.id === FAV) st.channels = favorites().filter((i) => i.type === LIVE);
      else if (c.id === RECENT) { const seen = new Set(); st.channels = profileProgress().filter((p) => p.type === LIVE && !seen.has(p.item.id) && seen.add(p.item.id)).map((p) => p.item); }
      else st.channels = (await getItems(LIVE, c.id, 1)).items;
    } catch (e) { clear(chList); chList.append(errorBox(e.message || String(e), () => selectCat(c))); return; }
    drawChannels();
  }

  let stopLazy = null;
  function matches(ch) { return !st.filter || ch.name.toLowerCase().includes(st.filter) || String(ch.number) === st.filter; }
  function chRow(ch) {
    return h('div.ch' + (st.playing?.id === ch.id ? '.on' : ''), { tabIndex: 0, 'data-id': ch.id, onclick: () => playChannel(ch), ondblclick: () => st.player?.toggleFullscreen(), onkeydown: (e) => { if (e.key === 'Enter') playChannel(ch); } },
      h('span.ch-num', ch.number || ''), posterEl(ch, 'ch-logo'), h('span.ch-name', ch.name),
      h('button.card-star' + (isFav(ch) ? '.on' : ''), { title: 'My channels', onclick: (e) => { e.stopPropagation(); toggleFav(ch); e.currentTarget.classList.toggle('on', isFav(ch)); } }, '★'));
  }
  function drawChannels() {
    stopLazy?.(); clear(chList);
    const list = st.channels.filter(matches);
    if (!list.length) { chList.append(h('div.empty', st.cat?.id === FAV ? 'Tap ★ next to a channel to add it here.' : st.cat?.id === RECENT ? 'Channels you watch will show up here.' : 'No channels.')); return; }
    stopLazy = lazyList(chList, list, chRow, 150);
  }
  function markPlaying() { chList.querySelectorAll('.ch').forEach((el) => el.classList.toggle('on', el.dataset.id === st.playing?.id)); st.panel?.querySelectorAll('.ch').forEach((el) => el.classList.toggle('on', el.dataset.id === st.playing?.id)); }

  // ---------- player ----------
  function ensurePlayer() {
    if (st.player) return;
    clear(stage);
    const host = h('div.live-player');
    stage.append(host);
    st.player = new Player(host, {
      getSettings: () => store.settings(), patchSettings: (p) => { store.patchSettings(p); applyCue(); }, applyCue,
      fullscreenTarget: host, isActive: () => view.isConnected && !overlayDepth(),
      onZap: (d) => zap(d), onNumber: (n) => jumpTo(n), onList: () => togglePanel(),
      onPrev: () => zap(-1), onNext: () => zap(1),
    });
    st.panel = h('div.chpanel', { hidden: true });
    host.append(st.panel);
  }

  function togglePanel() {
    if (!st.panel) return;
    st.panel.hidden = !st.panel.hidden;
    if (st.panel.hidden) return;
    clear(st.panel);
    const list = h('div.ch-list');
    const f = h('input.input', { placeholder: 'Search channels', oninput: debounce(() => { clear(list); lazyList(list, st.channels.filter((c) => c.name.toLowerCase().includes(f.value.trim().toLowerCase())), chRow, 100); markPlaying(); }, 120) });
    st.panel.append(h('div.chpanel-head', h('b', st.cat?.name || 'Channels'), h('button.pbtn', { onclick: () => (st.panel.hidden = true) }, '✕')), f, list);
    lazyList(list, st.channels, chRow, 100);
    markPlaying();
    list.querySelector('.ch.on')?.scrollIntoView({ block: 'center' });
  }

  function zap(dir) {
    const list = st.channels.filter(matches);
    if (!list.length) return;
    const i = list.findIndex((c) => c.id === st.playing?.id);
    const next = list[(i + dir + list.length) % list.length];
    playChannel(next);
    chList.querySelector(`.ch[data-id="${CSS.escape(next.id)}"]`)?.scrollIntoView({ block: 'nearest' });
  }

  async function jumpTo(n) {
    let ch = st.channels.find((c) => c.number === n);
    if (!ch) { try { ch = (await S.provider.allLive()).find((c) => c.number === n); } catch { /* */ } }
    if (ch) playChannel(ch); else st.player?.say(`No channel ${n}`);
  }

  async function playChannel(ch) {
    ensurePlayer();
    const p = st.player;
    if (st.playing && st.playing.id !== ch.id) st.prev = st.playing;
    st.playing = ch; markPlaying();
    clearTimeout(st.epgTimer);
    p.title.textContent = ch.name; p.subtitleLine.textContent = ch.number ? `Channel ${ch.number}` : ''; p.setInfo('');
    p.msg.textContent = ''; p.root.classList.remove('errored'); p.root.classList.add('buffering');
    clear(epgBox);
    let url;
    try { url = await S.provider.resolve(ch, null); }
    catch (e) { if (st.playing === ch) p.showError(e.message || 'Could not get a stream link.'); return; }
    if (st.playing !== ch || p.destroyed) return;
    saveProgress(ch, null, 0, 0, false);
    await p.load({ url, headers: S.provider.playbackHeaders(), live: true, title: ch.name, subtitle: ch.number ? `Channel ${ch.number}` : '', compat: store.settings().compatMode });
    loadEpg(ch);
  }

  async function loadEpg(ch) {
    let list = [];
    try { list = await S.provider.epg(ch); } catch { /* optional */ }
    if (st.playing !== ch) return;
    clear(epgBox);
    const now = Date.now();
    const cur = list.find((e) => e.startMs <= now && e.endMs > now);
    st.player?.setInfo(cur ? `Now: ${cur.title}  ·  until ${fmtClock(cur.endMs)}` : '');
    if (!list.length) { epgBox.append(h('div.epg-empty', 'No programme guide for this channel.')); return; }
    epgBox.append(h('h3', ch.name));
    list.slice(0, 6).forEach((e) => {
      const on = e.startMs <= now && e.endMs > now;
      epgBox.append(h('div.epg-item' + (on ? '.now' : ''),
        h('div.epg-time', `${fmtClock(e.startMs)} – ${fmtClock(e.endMs)}`),
        h('div.epg-title', e.title, on ? h('span.badge', 'NOW') : null),
        on ? h('div.epg-prog', h('div', { style: { width: Math.round(((now - e.startMs) / (e.endMs - e.startMs)) * 100) + '%' } })) : null,
        e.description ? h('div.epg-desc', e.description.slice(0, 220)) : null));
    });
    const nextChange = list.map((e) => (e.startMs > now ? e.startMs : e.endMs)).filter((t) => t > now).sort((a, b) => a - b)[0];
    if (nextChange) st.epgTimer = setTimeout(() => loadEpg(ch), Math.min(nextChange - now + 1000, 10 * 60e3));
  }

  // Backspace = previous channel (like a TV remote's "last" button)
  const keys = (e) => {
    if (!view.isConnected || overlayDepth() || e.target.tagName === 'INPUT') return;
    if (e.key === 'Backspace' && st.prev) { e.preventDefault(); playChannel(st.prev); }
  };
  document.addEventListener('keydown', keys);

  S.cleanup = () => {
    document.removeEventListener('keydown', keys);
    clearTimeout(st.epgTimer); stopLazy?.();
    st.player?.destroy(); st.player = null;
  };

  drawCats();
  selectCat(startCat);
}

// ---------- Multi-screen ----------

export async function openMulti(startCh, seedList = []) {
  let all = [];
  try { all = await S.provider.allLive(); } catch { /* picker will be empty */ }
  const root = h('div.multi');
  const area = h('div.multi-area');
  let layout = store.settings().multiLayout || 'stack';
  let focus = 0;
  const cells = [];

  const setLayout = (l) => {
    layout = l; store.patchSettings({ multiLayout: l });
    area.className = 'multi-area ' + l;
    while (cells.length < (l === 'grid' ? 4 : 2)) addCell();
    while (cells.length > (l === 'grid' ? 4 : 2)) { const c = cells.pop(); c.player.destroy(); c.el.remove(); }
    bar.querySelectorAll('[data-l]').forEach((b) => b.classList.toggle('on', b.dataset.l === l));
    setFocus(Math.min(focus, cells.length - 1));
  };
  const bar = h('div.multi-bar',
    h('b', 'Multi-screen'),
    h('button.tab', { 'data-l': 'stack', onclick: () => setLayout('stack') }, 'Top / bottom'),
    h('button.tab', { 'data-l': 'side', onclick: () => setLayout('side') }, 'Side by side'),
    h('button.tab', { 'data-l': 'grid', onclick: () => setLayout('grid') }, '2 × 2'),
    h('span.multi-note', 'Click a screen to hear it. Your plan may limit how many streams can run at once.'),
    h('button.btn.ghost.small', { onclick: closeTopOverlay }, 'Close'));
  root.append(bar, area);
  document.getElementById('overlays').append(root);
  pushOverlay(() => { cells.forEach((c) => c.player.destroy()); root.remove(); });

  function setFocus(i) {
    focus = i;
    cells.forEach((c, j) => { c.player.setMuted(j !== i); c.el.classList.toggle('focus', j === i); });
  }

  async function loadCell(i, ch) {
    const c = cells[i]; if (!c) return;
    c.ch = ch;
    c.player.title.textContent = ch.name;
    c.player.root.classList.add('buffering'); c.player.msg.textContent = '';
    let url;
    try { url = await S.provider.resolve(ch, null); } catch (e) { c.player.showError(e.message || 'No stream link'); return; }
    if (c.ch !== ch || c.player.destroyed) return;
    await c.player.load({ url, headers: S.provider.playbackHeaders(), live: true, title: ch.name });
    c.player.setMuted(cells.indexOf(c) !== focus);
  }

  function addCell() {
    const el = h('div.mcell');
    const idx = cells.length;
    const player = new Player(el, { mini: true, getSettings: () => store.settings(), patchSettings: store.patchSettings, onFocus: () => setFocus(cells.findIndex((c) => c.el === el)) });
    el.append(h('button.mcell-change', { onclick: (e) => { e.stopPropagation(); pick(cells.findIndex((c) => c.el === el)); } }, 'Change channel'));
    const cell = { el, player, ch: null };
    cells.push(cell);
    area.append(el);
    const used = new Set(cells.map((c) => c.ch?.id));
    const pool = [...seedList, ...all].filter((c) => c && !used.has(c.id));
    const ch = idx === 0 ? (startCh || pool[0]) : pool[0];
    if (ch) loadCell(idx, ch);
  }

  function pick(i) {
    const m = h('div.modal-bg.inner');
    const list = h('div.ch-list');
    const draw = () => {
      clear(list);
      const q = f.value.trim().toLowerCase();
      const items = (q ? all.filter((c) => c.name.toLowerCase().includes(q)) : [...seedList, ...all]).slice(0, 80);
      items.forEach((c) => list.append(h('div.ch', { tabIndex: 0, onclick: () => { m.remove(); loadCell(i, c); setFocus(i); } }, h('span.ch-num', c.number || ''), posterEl(c, 'ch-logo'), h('span.ch-name', c.name))));
      if (!items.length) list.append(h('div.empty', 'No channels match.'));
    };
    const f = h('input.input', { placeholder: 'Search all channels', oninput: debounce(draw, 150) });
    m.append(h('div.picker', h('div.picker-head', h('b', 'Choose a channel'), h('button.pbtn', { onclick: () => m.remove() }, '✕')), f, list));
    m.addEventListener('mousedown', (e) => { if (e.target === m) m.remove(); });
    root.append(m); draw(); f.focus();
  }

  setLayout(layout);
}
