// Local storage: sources, watch history, My List, settings, and the 7-day catalog cache (IndexedDB).

const LS = {
  get(key, fallback) { try { const v = localStorage.getItem(key); return v == null ? fallback : JSON.parse(v); } catch { return fallback; } },
  set(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* quota */ } },
};

export const DEFAULT_SETTINGS = {
  lastProfileId: null,
  autoplayNext: true,
  autoResume: true,
  liveFormat: 'm3u8',
  hideAdult: true,
  catalogCacheDays: 7,
  subtitleScale: 1,
  subtitleBackground: true,
  volume: 1,
  lastCategory: {},
  compatMode: false,
};

export const store = {
  profiles: () => LS.get('etv.profiles', []),
  saveProfiles(list) { LS.set('etv.profiles', list); },
  settings: () => ({ ...DEFAULT_SETTINGS, ...LS.get('etv.settings', {}) }),
  saveSettings(s) { LS.set('etv.settings', s); },
  patchSettings(p) { const s = { ...store.settings(), ...p }; store.saveSettings(s); return s; },

  progress: () => LS.get('etv.progress', {}),
  saveProgress(map) {
    const entries = Object.entries(map).sort((a, b) => (b[1].updatedAt || 0) - (a[1].updatedAt || 0)).slice(0, 400);
    LS.set('etv.progress', Object.fromEntries(entries));
  },
  favorites: () => LS.get('etv.favorites', []),
  saveFavorites(list) { LS.set('etv.favorites', list); },
};

// ---------- IndexedDB key/value ----------

let dbp = null;
function db() {
  dbp ||= new Promise((resolve, reject) => {
    const r = indexedDB.open('everytv', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('kv');
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
  return dbp;
}
async function tx(mode, fn) {
  const d = await db();
  return new Promise((resolve, reject) => {
    const t = d.transaction('kv', mode);
    const req = fn(t.objectStore('kv'));
    t.oncomplete = () => resolve(req?.result);
    t.onerror = () => reject(t.error);
  });
}
export const idbGet = (k) => tx('readonly', (s) => s.get(k)).catch(() => undefined);
export const idbSet = (k, v) => tx('readwrite', (s) => s.put(v, k)).catch(() => {});
export const idbDel = (k) => tx('readwrite', (s) => s.delete(k)).catch(() => {});
export const idbKeys = () => tx('readonly', (s) => s.getAllKeys()).catch(() => []);

// ---------- catalog cache ----------

const mem = new Map();
const VERSION = 'v3';

export const catalog = {
  key: (pid, ...parts) => [pid, VERSION, ...parts].join('|'),
  /** Returns cached data when fresh, otherwise loads and stores it. */
  async get(key, loader, { force = false } = {}) {
    const ttl = store.settings().catalogCacheDays * 86400e3;
    if (!force) {
      const m = mem.get(key);
      if (m && Date.now() - m.at < ttl) return m.data;
      const d = await idbGet(key);
      if (d && Date.now() - d.at < ttl) { mem.set(key, d); return d.data; }
    }
    const data = await loader();
    const rec = { at: Date.now(), data };
    mem.set(key, rec);
    idbSet(key, rec);
    return data;
  },
  peek(key) { return mem.get(key)?.data; },
  async clear(pid) {
    for (const k of [...mem.keys()]) if (!pid || k.startsWith(pid + '|')) mem.delete(k);
    for (const k of await idbKeys()) if (typeof k === 'string' && !k.startsWith('m3u:') && (!pid || k.startsWith(pid + '|'))) await idbDel(k);
  },
};

// ---------- personalisation ----------

/** Scores categories by what was actually watched (recent and finished titles count more). */
export function categoryScores(pid) {
  const now = Date.now();
  const scores = {};
  for (const p of Object.values(store.progress())) {
    if (p.profileId !== pid || !p.item?.categoryId) continue;
    const ageDays = (now - (p.updatedAt || 0)) / 86400e3;
    let w = 1 + Math.min((p.positionMs && p.durationMs ? p.positionMs / p.durationMs : 0) * 2, 2) + (p.finished ? 1 : 0);
    w += ageDays < 7 ? 2 : ageDays < 30 ? 1 : 0;
    const k = `${p.item.type}|${p.item.categoryId}`;
    scores[k] = (scores[k] || 0) + w;
  }
  return scores;
}

// ---------- backup ----------

export function exportBackup() {
  return JSON.stringify({ app: 'EveryTV', version: 1, profiles: store.profiles(), settings: store.settings(), progress: store.progress(), favorites: store.favorites() }, null, 2);
}
export function importBackup(text) {
  const o = JSON.parse(text);
  if (o.app !== 'EveryTV') throw new Error('This file is not an EveryTV backup.');
  if (o.profiles) store.saveProfiles(o.profiles);
  if (o.settings) store.saveSettings({ ...DEFAULT_SETTINGS, ...o.settings });
  if (o.progress) store.saveProgress(o.progress);
  if (o.favorites) store.saveFavorites(o.favorites);
}
