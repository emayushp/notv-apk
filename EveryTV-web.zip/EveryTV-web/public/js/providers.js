// Portal clients: M3U, Xtream Codes, MAG/Stalker (Ministra). Ported from the Android app.
import { enc, md5, sha256 } from './util.js';
import { fetchText, HttpError, NetError, probe } from './net.js';

export class ProviderError extends Error {}

export const LIVE = 'LIVE', MOVIE = 'MOVIE', SERIES = 'SERIES';
export const TYPES = [LIVE, MOVIE, SERIES];

const DESKTOP_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

// ---------- shared helpers ----------

export function str(o, key) {
  if (!o || o[key] == null) return null;
  const v = String(o[key]).trim();
  return v && v !== 'null' ? v : null;
}
export function first(o, ...keys) {
  for (const k of keys) { const v = str(o, k); if (v) return v; }
  return null;
}
const num = (v) => { const n = parseInt(v, 10); return Number.isFinite(n) ? n : null; };
const numberIn = (s) => (s ? num((/(\d+)/.exec(s) || [])[1]) : null);

function parseJsonAny(body) {
  const t = body.trim();
  if (t.startsWith('{') || t.startsWith('[')) return JSON.parse(t);
  return null;
}

const adultRegex = /(adult|xxx|18\+|\+18|porn|for adults|erotic|\bsex\b)/i;
export const isAdultName = (n) => adultRegex.test(n || '');

const seriesCatRegex = /(\bseries\b|\bserials?\b|web ?series|tv ?shows?|\bshows?\b|\bdramas?\b|\bseasons?\b|\bepisodes?\b|\bnovelas?\b|\bsitcoms?\b|\bdizi\b|\bserie\b|séries|\bkdrama|\banime\b|\bcartoons?\b)/i;
const notSeriesRegex = /(stage ?shows?|award ?shows?|movies?|films?|cinema)/i;
export function isSeriesCategoryName(name) {
  if (!seriesCatRegex.test(name)) return false;
  if (notSeriesRegex.test(name) && !/(series|drama|serial|season)/i.test(name)) return false;
  return true;
}

const seasonEpisodeRegex = /^(.*?)[\s._\-|:]*\(?S(\d{1,2})\s*[ ._-]?\s*E(\d{1,4})\)?(.*)$/i;

function searchMatch(name, q) {
  if (!q.trim()) return false;
  const n = name.toLowerCase();
  return q.toLowerCase().split(' ').filter(Boolean).every((p) => n.includes(p));
}

function item(o) {
  return { categoryId: '', poster: null, backdrop: null, plot: null, year: null, rating: null, genre: null, cast: null, director: null, duration: null, url: null, ext: null, number: 0, epgId: null, extra: null, ...o };
}

class Semaphore {
  constructor(n) { this.n = n; this.q = []; }
  async run(fn) {
    if (this.n <= 0) await new Promise((r) => this.q.push(r));
    this.n--;
    try { return await fn(); } finally { this.n++; this.q.shift()?.(); }
  }
}

function memo(fn) {
  let p = null;
  return () => (p ||= fn().catch((e) => { p = null; throw e; }));
}

// ---------- XMLTV (EPG) ----------

class XmltvEpg {
  constructor(url, headers) { this.url = url; this.headers = headers; this.by = null; this.loading = null; }
  async forChannel(id) {
    if (!id || !this.url) return [];
    this.loading ||= this.load();
    await this.loading;
    const now = Date.now();
    const list = this.by.get(id) || this.by.get(id.toLowerCase()) || [];
    return list.filter((e) => e.endMs > now).sort((a, b) => a.startMs - b.startMs).slice(0, 6);
  }
  async load() {
    this.by = new Map();
    try {
      const xml = await fetchText(this.url, this.headers);
      const now = Date.now(), from = now - 2 * 3600e3, to = now + 24 * 3600e3;
      const re = /<programme\s+([^>]*)>([\s\S]*?)<\/programme>/g;
      let m;
      while ((m = re.exec(xml))) {
        const attrs = {};
        m[1].replace(/([\w-]+)="([^"]*)"/g, (_x, k, v) => { attrs[k] = v; return ''; });
        const start = xmltvTime(attrs.start), stop = xmltvTime(attrs.stop);
        if (!attrs.channel || stop < from || start > to) continue;
        const title = unescapeXml((/<title[^>]*>([\s\S]*?)<\/title>/.exec(m[2]) || [])[1] || '');
        const desc = unescapeXml((/<desc[^>]*>([\s\S]*?)<\/desc>/.exec(m[2]) || [])[1] || '');
        const e = { title, startMs: start, endMs: stop, description: desc || null };
        for (const key of new Set([attrs.channel, attrs.channel.toLowerCase()])) {
          if (!this.by.has(key)) this.by.set(key, []);
          this.by.get(key).push(e);
        }
      }
    } catch { /* EPG is optional */ }
  }
}
function xmltvTime(s) {
  const m = /^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})\s*([+-]\d{4})?/.exec((s || '').trim());
  if (!m) return 0;
  const utc = Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]);
  if (!m[7]) return utc;
  const sign = m[7][0] === '-' ? -1 : 1;
  return utc - sign * (parseInt(m[7].slice(1, 3), 10) * 60 + parseInt(m[7].slice(3, 5), 10)) * 60000;
}
function unescapeXml(s) {
  return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&').trim();
}

// ---------- base ----------

class Provider {
  constructor(profile) { this.profile = profile; }
  async connect() {}
  async categories(_type) { return []; }
  async items(_type, _cat, _page) { return { items: [], hasMore: false }; }
  async allLive() { return []; }
  async search(_q) { return []; }
  async movieDetails(it) { return it; }
  async seriesInfo(_it) { throw new ProviderError('Not supported'); }
  async resolve(_it, _ep) { throw new ProviderError('Not supported'); }
  async epg(_ch) { return []; }
  async accountInfo() { return null; }
  playbackHeaders() { return {}; }
  close() {}
}

// ---------- M3U ----------

export class M3uProvider extends Provider {
  constructor(profile, text) {
    super(profile);
    this.text = text; // pre-loaded text when a file was uploaded
    this.ua = profile.userAgent || DESKTOP_UA;
    this.cats = {}; this.byCat = new Map(); this.all = []; this.episodes = new Map(); this.xmltv = null;
  }
  async connect() {
    let text = this.text;
    if (text == null) {
      const url = (this.profile.url || '').trim();
      if (!/^https?:\/\//i.test(url)) throw new ProviderError('Playlist URL must start with http:// or https://');
      try { text = await fetchText(url, { 'User-Agent': this.ua }); } catch (e) { throw wrapNet(e, 'playlist'); }
    }
    this.parse(text);
    if (!this.all.length) throw new ProviderError('The playlist loaded but contains no channels.');
  }
  parse(text) {
    const items = [], catMap = new Map(), epMap = new Map(), seriesItems = new Map();
    let name = null, attrs = {}, group = null, headerEpg = null, counter = 0;
    const attrRe = /([a-zA-Z0-9_-]+)="([^"]*)"/g;
    const parseAttrs = (s) => { const a = {}; let m; attrRe.lastIndex = 0; while ((m = attrRe.exec(s))) a[m[1].toLowerCase()] = m[2]; return a; };
    for (const raw of text.split(/\r?\n/)) {
      const line = raw.trim();
      if (!line) continue;
      if (line.startsWith('#EXTM3U')) { const a = parseAttrs(line); headerEpg = a['url-tvg'] || a['x-tvg-url'] || null; }
      else if (line.startsWith('#EXTINF')) {
        let inQ = false, idx = -1;
        for (let i = 0; i < line.length; i++) { const c = line[i]; if (c === '"') inQ = !inQ; else if (c === ',' && !inQ) { idx = i; break; } }
        name = idx >= 0 ? line.slice(idx + 1).trim() : '';
        attrs = parseAttrs(idx >= 0 ? line.slice(0, idx) : line);
      } else if (line.startsWith('#EXTGRP:')) group = line.slice(8).trim();
      else if (line.startsWith('#')) continue;
      else {
        const url = line;
        const nm = (name || attrs['tvg-name'] || `Channel ${counter + 1}`).trim();
        const grp = (attrs['group-title'] || group || 'Uncategorized') || 'Uncategorized';
        const logo = attrs['tvg-logo'] || null;
        const type = this.classify(url, grp, nm);
        counter++;
        const catId = `${type}:${grp}`;
        if (!catMap.has(catId)) catMap.set(catId, { id: catId, name: grp, type });
        if (type === SERIES) {
          const m = seasonEpisodeRegex.exec(nm);
          const trim = (s) => s.replace(/^[\s\-|:.]+|[\s\-|:.]+$/g, '');
          const seriesName = (m && trim(m[1])) || nm;
          const season = m ? parseInt(m[2], 10) : 1;
          const sid = 's:' + seriesName.toLowerCase();
          const epNum = m ? parseInt(m[3], 10) : (epMap.get(sid)?.length || 0) + 1;
          if (!seriesItems.has(sid)) {
            const s = item({ id: sid, name: seriesName, type: SERIES, categoryId: catId, poster: logo });
            seriesItems.set(sid, s); items.push(s);
          }
          const rest = m ? trim(m[4] || '') : '';
          if (!epMap.has(sid)) epMap.set(sid, []);
          epMap.get(sid).push({ id: 'e' + counter, seriesId: sid, season, episode: epNum, title: rest || `Episode ${epNum}`, image: logo, url, plot: null, ext: null, durationSecs: 0 });
        } else {
          items.push(item({ id: 'i' + counter, name: nm, type, categoryId: catId, poster: logo, url, number: num(attrs['tvg-chno']) || counter, epgId: attrs['tvg-id'] || attrs['tvg-name'] || null }));
        }
        name = null; attrs = {}; group = null;
      }
    }
    this.all = items;
    this.byCat = new Map();
    for (const it of items) { if (!this.byCat.has(it.categoryId)) this.byCat.set(it.categoryId, []); this.byCat.get(it.categoryId).push(it); }
    this.cats = {};
    for (const c of catMap.values()) (this.cats[c.type] ||= []).push(c);
    this.episodes = epMap;
    const epgUrl = this.profile.epgUrl || headerEpg || '';
    if (epgUrl) this.xmltv = new XmltvEpg(epgUrl, { 'User-Agent': this.ua });
  }
  classify(url, group, name) {
    const u = url.toLowerCase();
    if (u.includes('/series/')) return SERIES;
    if (u.includes('/movie/') || u.includes('/movies/')) return MOVIE;
    const g = group.toLowerCase();
    const path = u.split('?')[0];
    const vodExt = /\.(mp4|mkv|avi)$/.test(path);
    if (/\b(series|shows|tv shows|serie|séries)\b/.test(g)) return SERIES;
    if (/\b(vod|movie|movies|film|films|cinema)\b/.test(g)) return seasonEpisodeRegex.test(name) ? SERIES : MOVIE;
    if (vodExt) return seasonEpisodeRegex.test(name) ? SERIES : MOVIE;
    return LIVE;
  }
  async categories(type) { return this.cats[type] || []; }
  async items(_type, cat, page) { return { items: page === 1 ? this.byCat.get(cat) || [] : [], hasMore: false }; }
  async allLive() { return this.all.filter((i) => i.type === LIVE); }
  async search(q) { return this.all.filter((i) => searchMatch(i.name, q)).slice(0, 300); }
  async seriesInfo(it) {
    const eps = (this.episodes.get(it.id) || []).slice().sort((a, b) => a.season - b.season || a.episode - b.episode);
    return groupSeasons(it, eps);
  }
  async resolve(it, ep) {
    const u = ep?.url || it.url;
    if (!u) throw new ProviderError(`No stream URL for ${it.name}`);
    return u;
  }
  async epg(ch) { return this.xmltv ? this.xmltv.forChannel(ch.epgId) : []; }
  playbackHeaders() { return this.profile.userAgent ? { 'User-Agent': this.profile.userAgent } : {}; }
}

function groupSeasons(it, eps) {
  const seasons = {};
  for (const e of eps) (seasons[e.season] ||= []).push(e);
  return { item: it, seasons };
}

function wrapNet(e, what) {
  if (e instanceof ProviderError) return e;
  if (e instanceof NetError) return new ProviderError(`Couldn't reach the ${what} server: ${e.message}`);
  if (e instanceof HttpError) return new ProviderError(`The ${what} server answered HTTP ${e.code}.`);
  return new ProviderError(e.message || String(e));
}

// ---------- Xtream Codes ----------

export class XtreamProvider extends Provider {
  constructor(profile, settings) {
    super(profile);
    this.settings = settings;
    let u = (profile.url || '').trim().replace(/\/+$/, '');
    let user = (profile.username || '').trim(), pass = (profile.password || '').trim();
    if (u.includes('username=') && u.includes('password=')) {
      const q = new URLSearchParams(u.split('?')[1] || '');
      user ||= q.get('username') || ''; pass ||= q.get('password') || '';
      u = u.split('?')[0];
    }
    u = u.replace(/\/(get\.php|player_api\.php|xmltv\.php)$/, '').replace(/\/+$/, '');
    if (!/^https?:\/\//i.test(u)) u = 'http://' + u;
    this.base = u; this.user = user; this.pass = pass;
    this.ua = profile.userAgent || DESKTOP_UA;
    this.api = `${u}/player_api.php?username=${enc(user)}&password=${enc(pass)}`;
    this.allCache = {}; this.userInfo = null; this.xmltv = null;
  }
  headers() { return { 'User-Agent': this.ua }; }
  async call(params) {
    let body;
    try { body = await fetchText(`${this.api}&${params}`, this.headers()); }
    catch (e) {
      if (e instanceof HttpError && (e.code === 401 || e.code === 403)) throw new ProviderError(`Login rejected by the server (HTTP ${e.code}). Check username and password.`);
      throw wrapNet(e, 'Xtream');
    }
    try { return parseJsonAny(body); } catch { return null; }
  }
  async connect() {
    if (!this.user || !this.pass) throw new ProviderError('Username and password are required for Xtream Codes.');
    const r = await this.call('');
    if (!r || Array.isArray(r)) throw new ProviderError('The server did not return valid Xtream data. Check the server URL.');
    const ui = r.user_info;
    if (!ui) throw new ProviderError('Server did not return account info. Check the URL.');
    if (Number(ui.auth) === 0) throw new ProviderError('Wrong username or password.');
    if (ui.status && String(ui.status).toLowerCase() !== 'active') throw new ProviderError(`Account status: ${ui.status}`);
    this.userInfo = ui;
    const epgUrl = this.profile.epgUrl || `${this.base}/xmltv.php?username=${enc(this.user)}&password=${enc(this.pass)}`;
    this.xmltv = new XmltvEpg(epgUrl, this.headers());
  }
  async accountInfo() {
    const ui = this.userInfo; if (!ui) return null;
    const exp = ui.exp_date ? new Date(Number(ui.exp_date) * 1000).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : 'Unlimited';
    return { status: ui.status, expires: exp, extra: `${ui.active_cons ?? 0} / ${ui.max_connections ?? '?'} connections` };
  }
  async categories(type) {
    const action = { LIVE: 'get_live_categories', MOVIE: 'get_vod_categories', SERIES: 'get_series_categories' }[type];
    const arr = await this.call(`action=${action}`);
    if (!Array.isArray(arr)) return [];
    return arr.map((o) => ({ id: str(o, 'category_id'), name: str(o, 'category_name') || 'Category', type })).filter((c) => c.id);
  }
  async items(type, cat, page) {
    if (page > 1) return { items: [], hasMore: false };
    return { items: await this.fetchItems(type, cat), hasMore: false };
  }
  async fetchItems(type, cat) {
    const action = { LIVE: 'get_live_streams', MOVIE: 'get_vod_streams', SERIES: 'get_series' }[type];
    const arr = await this.call(`action=${action}${cat != null ? `&category_id=${enc(cat)}` : ''}`);
    if (!Array.isArray(arr)) return [];
    const out = [];
    for (const o of arr) {
      if (type === LIVE) {
        const id = str(o, 'stream_id'); if (!id) continue;
        out.push(item({ id, name: str(o, 'name') || id, type, categoryId: str(o, 'category_id') || '', poster: str(o, 'stream_icon'), number: num(o.num) || 0, epgId: str(o, 'epg_channel_id') }));
      } else if (type === MOVIE) {
        const id = str(o, 'stream_id'); if (!id) continue;
        const rating = str(o, 'rating');
        out.push(item({ id, name: str(o, 'name') || id, type, categoryId: str(o, 'category_id') || '', poster: str(o, 'stream_icon'), rating: rating && rating !== '0' ? rating : null, ext: str(o, 'container_extension') || 'mp4', year: str(o, 'year'), plot: str(o, 'plot') }));
      } else {
        const id = str(o, 'series_id'); if (!id) continue;
        const rating = str(o, 'rating');
        out.push(item({ id, name: str(o, 'name') || id, type, categoryId: str(o, 'category_id') || '', poster: str(o, 'cover'), backdrop: firstBackdrop(o), plot: str(o, 'plot'), rating: rating && rating !== '0' ? rating : null, genre: str(o, 'genre'), cast: str(o, 'cast'), director: str(o, 'director'), year: (first(o, 'year', 'releaseDate', 'release_date') || '').slice(0, 4) || null }));
      }
    }
    return out;
  }
  async allLive() { return (this.allCache.LIVE ||= await this.fetchItems(LIVE, null)); }
  async allOf(type) { return (this.allCache[type] ||= await this.fetchItems(type, null)); }
  async search(q) {
    const parts = await Promise.all(TYPES.map((t) => this.allOf(t).catch(() => [])));
    return parts.flat().filter((i) => searchMatch(i.name, q)).slice(0, 300);
  }
  async movieDetails(it) {
    const r = await this.call(`action=get_vod_info&vod_id=${it.id}`);
    const info = r && r.info; if (!info) return it;
    const md = r.movie_data;
    const rating = str(info, 'rating');
    return { ...it,
      plot: first(info, 'plot', 'description') || it.plot, backdrop: firstBackdrop(info) || it.backdrop, poster: it.poster || str(info, 'movie_image'),
      cast: first(info, 'cast', 'actors') || it.cast, director: str(info, 'director') || it.director, genre: str(info, 'genre') || it.genre,
      year: (first(info, 'releasedate', 'release_date', 'year') || '').slice(0, 4) || it.year, duration: str(info, 'duration') || it.duration,
      rating: rating && rating !== '0' ? rating : it.rating, ext: (md && str(md, 'container_extension')) || it.ext };
  }
  async seriesInfo(it) {
    const r = await this.call(`action=get_series_info&series_id=${it.id}`);
    if (!r || Array.isArray(r)) throw new ProviderError("Couldn't load episodes.");
    const info = r.info;
    const enriched = info ? { ...it, plot: str(info, 'plot') || it.plot, backdrop: firstBackdrop(info) || it.backdrop, poster: it.poster || str(info, 'cover'), cast: str(info, 'cast') || it.cast, genre: str(info, 'genre') || it.genre, year: (first(info, 'releaseDate', 'release_date') || '').slice(0, 4) || it.year } : it;
    const covers = {};
    for (const s of r.seasons || []) { const n = num(s.season_number); const c = first(s, 'cover_big', 'cover'); if (n != null && c) covers[n] = c; }
    const eps = [];
    const add = (o, seasonKey) => {
      const id = str(o, 'id'); if (!id) return;
      const season = num(o.season) ?? seasonKey ?? 1;
      const inf = o.info || {};
      eps.push({ id, seriesId: it.id, season, episode: num(o.episode_num) ?? eps.filter((e) => e.season === season).length + 1, title: str(o, 'title') || 'Episode', plot: first(inf, 'plot', 'description'), image: str(inf, 'movie_image') || covers[season] || null, ext: str(o, 'container_extension') || 'mp4', durationSecs: num(inf.duration_secs) || 0, url: null });
    };
    const e = r.episodes;
    if (Array.isArray(e)) { for (const x of e) { if (Array.isArray(x)) x.forEach((o) => add(o, null)); else if (x && typeof x === 'object') add(x, null); } }
    else if (e && typeof e === 'object') { for (const [k, arr] of Object.entries(e)) if (Array.isArray(arr)) arr.forEach((o) => add(o, num(k))); }
    eps.sort((a, b) => a.season - b.season || a.episode - b.episode);
    return groupSeasons(enriched, eps);
  }
  async resolve(it, ep) {
    const u = enc(this.user).replace(/\+/g, '%20'), p = enc(this.pass).replace(/\+/g, '%20');
    if (ep) return `${this.base}/series/${u}/${p}/${ep.id}.${ep.ext || 'mp4'}`;
    if (it.type === MOVIE) return `${this.base}/movie/${u}/${p}/${it.id}.${it.ext || 'mp4'}`;
    const fmt = this.settings().liveFormat === 'ts' ? 'ts' : 'm3u8';
    return `${this.base}/live/${u}/${p}/${it.id}.${fmt}`;
  }
  async epg(ch) {
    const r = await this.call(`action=get_short_epg&stream_id=${ch.id}&limit=6`).catch(() => null);
    const arr = r && r.epg_listings;
    const now = Date.now();
    if (Array.isArray(arr) && arr.length) {
      const out = [];
      for (const o of arr) {
        const start = num(o.start_timestamp), stop = num(o.stop_timestamp);
        if (start == null || stop == null || stop * 1000 < now) continue;
        out.push({ title: b64(str(o, 'title')), startMs: start * 1000, endMs: stop * 1000, description: b64(str(o, 'description')) || null });
      }
      if (out.length) return out.sort((a, b) => a.startMs - b.startMs);
    }
    return this.xmltv ? this.xmltv.forChannel(ch.epgId) : [];
  }
  playbackHeaders() { return this.profile.userAgent ? { 'User-Agent': this.profile.userAgent } : {}; }
}

function firstBackdrop(o) {
  const bp = o.backdrop_path;
  if (Array.isArray(bp)) return bp.find((x) => typeof x === 'string' && x.startsWith('http')) || null;
  if (typeof bp === 'string' && bp.startsWith('http')) return bp;
  return null;
}
function b64(s) {
  if (!s) return '';
  try { return new TextDecoder().decode(Uint8Array.from(atob(s), (c) => c.charCodeAt(0))); } catch { return s; }
}

// ---------- MAG / Stalker ----------

const STB_UA = 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3';

export function normalizeMac(mac) {
  const hex = (mac || '').toUpperCase().replace(/[^0-9A-F]/g, '');
  if (hex.length !== 12) return (mac || '').toUpperCase().trim();
  return hex.match(/../g).join(':');
}
export function randomMac() {
  const b = () => Math.floor(Math.random() * 256).toString(16).toUpperCase().padStart(2, '0');
  return `00:1A:79:${b()}:${b()}:${b()}`;
}

class AuthExpired extends Error {}

export class StalkerProvider extends Provider {
  constructor(profile) {
    super(profile);
    this.mac = normalizeMac(profile.mac);
    this.serial = (profile.serial || '').trim() || md5(this.mac).toUpperCase().slice(0, 13);
    this.deviceId = (profile.deviceId || '').trim() || sha256(this.mac).toUpperCase();
    this.deviceId2 = (profile.deviceId2 || '').trim() || this.deviceId;
    this.signature = (profile.signature || '').trim() || sha256(this.serial + this.mac).toUpperCase();
    this.ua = profile.userAgent || STB_UA;
    this.tz = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
    this.endpoint = ''; this.referer = ''; this.token = '';
    this.lim = new Semaphore(4);
    this.attempts = []; this.lastBody = '';
    this.relogging = null;
    this.hasSeriesModule = null;
    this.channelsOnce = memo(() => this.loadChannels());
    this.vodCatsOnce = memo(() => this.loadVodCats());
    this.accountCache = null;
    this.keepAlive = null;
  }

  candidatesFor(input) {
    let u = input.trim().split('?')[0].split('#')[0].replace(/\/+$/, '');
    if (!/^http/i.test(u)) u = 'http://' + u;
    const root = (/^(https?:\/\/[^/]+)/.exec(u) || [u])[0];
    const out = [];
    if (u.endsWith('.php')) out.push([u, u.slice(0, u.lastIndexOf('/')) + '/c/']);
    if (u.includes('/stalker_portal')) {
      const sp = u.split('/stalker_portal')[0] + '/stalker_portal';
      out.push([`${sp}/server/load.php`, `${sp}/c/`]);
    }
    if (u.endsWith('/c')) {
      const r = u.slice(0, -2);
      out.push([`${r}/portal.php`, `${r}/c/`], [`${r}/server/load.php`, `${r}/c/`], [`${r}/stalker_portal/server/load.php`, `${r}/stalker_portal/c/`]);
    }
    out.push([`${root}/portal.php`, `${root}/c/`], [`${root}/stalker_portal/server/load.php`, `${root}/stalker_portal/c/`], [`${root}/server/load.php`, `${root}/c/`]);
    return out;
  }
  swapScheme(u) { return u.startsWith('https://') ? 'http://' + u.slice(8) : 'https://' + u.replace(/^http:\/\//, ''); }

  async discover() {
    const typed = /^http/i.test(this.profile.url.trim()) ? this.profile.url.trim() : 'http://' + this.profile.url.trim();
    const root = (/^(https?:\/\/[^/]+)/.exec(typed) || [typed])[0];
    const starts = [...new Set([typed, `${root}/c/`, `${root}/stalker_portal/c/`])];
    const hdr = { 'User-Agent': this.ua, 'X-User-Agent': 'Model: MAG250; Link: WiFi' };
    const found = [];
    await Promise.all(starts.map(async (start) => {
      try {
        const r = await probe(start, hdr);
        if (r.finalUrl.replace(/\/+$/, '') !== start.replace(/\/+$/, '')) {
          this.attempts.push(`open ${start} → redirected to ${r.finalUrl}`);
          found.push(...this.candidatesFor(r.finalUrl));
        }
      } catch (e) { this.attempts.push(`open ${start} → ${e.message}`); }
    }));
    const all = [...found, ...this.candidatesFor(typed)];
    const swapped = all.map(([e, r]) => [this.swapScheme(e), this.swapScheme(r)]);
    const seen = new Set();
    return [...all, ...swapped].filter(([e]) => (seen.has(e) ? false : seen.add(e)));
  }

  headers(withAuth = true) {
    const h = {
      'User-Agent': this.ua, 'X-User-Agent': 'Model: MAG250; Link: WiFi', Referer: this.referer, Accept: '*/*',
      Cookie: `mac=${enc(this.mac)}; stb_lang=en; timezone=${enc(this.tz)}`,
    };
    if (withAuth && this.token) h.Authorization = `Bearer ${this.token}`;
    return h;
  }

  async rawCall(ep, params, withAuth = true) {
    const body = await fetchText(`${ep}?${params}&JsHttpRequest=1-xml`, this.headers(withAuth));
    let parsed = null;
    try { parsed = parseJsonAny(body); } catch { parsed = null; }
    if (parsed == null) {
      const i = body.indexOf('{'), j = body.lastIndexOf('}');
      if (i >= 0 && j > i) { try { parsed = JSON.parse(body.slice(i, j + 1)); } catch { parsed = null; } }
    }
    this.lastBody = body;
    if (parsed == null && /Authorization failed/i.test(body)) throw new AuthExpired();
    if (parsed && !Array.isArray(parsed) && parsed.js !== undefined && parsed.js !== null) return parsed.js;
    return parsed;
  }

  call(params) {
    return this.lim.run(async () => {
      try { return await this.rawCall(this.endpoint, params); }
      catch (e) {
        if (e instanceof AuthExpired || (e instanceof HttpError && (e.code === 401 || e.code === 403))) {
          await this.relogin();
          return this.rawCall(this.endpoint, params);
        }
        if (e instanceof HttpError) throw new ProviderError(`Portal error HTTP ${e.code}`);
        throw e;
      }
    });
  }
  async relogin() {
    this.relogging ||= (async () => { this.token = ''; await this.handshakeAndProfile(this.endpoint); })().finally(() => { this.relogging = null; });
    return this.relogging;
  }

  async connect() {
    if (this.mac.length !== 17) throw new ProviderError('MAC address must look like 00:1A:79:12:34:56');
    this.attempts = [];
    let portalError = null;
    for (const [ep, ref] of await this.discover()) {
      this.referer = ref;
      try {
        this.token = '';
        await this.handshakeAndProfile(ep);
        this.endpoint = ep;
        this.startKeepAlive();
        return;
      } catch (e) {
        const detail = e instanceof ProviderError ? e.message : e instanceof HttpError ? `HTTP ${e.code}` : e.message;
        this.attempts.push(`${ep} → ${detail}` + (!this.token ? `  [${this.lastBody.slice(0, 80).replace(/\n/g, ' ')}]` : ''));
        if (this.token && e instanceof ProviderError) { this.endpoint = ep; portalError = e.message; break; }
      }
    }
    const log = this.attempts.slice(-14).map((a) => `• ${a}`).join('\n');
    if (portalError) throw new ProviderError(`The portal rejected the login: ${portalError}\n\nDetails:\n${log}`);
    throw new ProviderError(`Couldn't find the portal. Check the portal URL and that this MAC is registered with your provider.\n\nWhat was tried:\n${log}`);
  }

  async handshakeAndProfile(ep) {
    const hs = await this.rawCall(ep, 'type=stb&action=handshake&token=&prehash=0', false);
    if (!hs || typeof hs !== 'object' || Array.isArray(hs)) throw new ProviderError('Portal handshake failed');
    const tok = str(hs, 'token');
    if (!tok) throw new ProviderError("Portal didn't return a token");
    this.token = tok;
    const random = str(hs, 'random') || sha256(String(Date.now()) + Math.random()).slice(0, 40);
    const ver = 'ImageDescription: 0.2.18-r23-250; ImageDate: Fri Jan 15 15:20:44 EET 2016; PORTAL version: 5.6.1; API Version: JS API version: 343; STB API version: 146; Player Engine version: 0x566';
    const metrics = JSON.stringify({ mac: this.mac, sn: this.serial, type: 'STB', model: 'MAG250', uid: this.deviceId, random });
    const ts = Math.floor(Date.now() / 1000);
    const params = `type=stb&action=get_profile&hd=1&ver=${enc(ver)}&num_banks=2&sn=${enc(this.serial)}&stb_type=MAG250&client_type=STB&image_version=218&video_out=hdmi&device_id=${enc(this.deviceId)}&device_id2=${enc(this.deviceId2)}&signature=${enc(this.signature)}&auth_second_step=1&hw_version=1.7-BD-00&not_valid_token=0&metrics=${enc(metrics)}&hw_version_2=${sha256(this.mac).slice(0, 40)}&timestamp=${ts}&api_signature=262&prehash=`;
    const p = await this.rawCall(ep, params);
    if (!p || typeof p !== 'object' || Array.isArray(p)) throw new ProviderError('Portal profile request failed');
    const block = str(p, 'block_msg');
    if (block) throw new ProviderError(block);
    const status = num(str(p, 'status'));
    if (!str(p, 'id') && !str(p, 'name') && status != null && status !== 0) throw new ProviderError(str(p, 'msg') || `This MAC is not activated on the portal (status ${status}).`);
  }

  startKeepAlive() {
    clearInterval(this.keepAlive);
    this.keepAlive = setInterval(() => { this.call('type=watchdog&action=get_events&cur_play_type=1&event_active_id=0&init=0').catch(() => {}); }, 110000);
  }
  close() { clearInterval(this.keepAlive); }

  async accountInfo() {
    if (this.accountCache) return this.accountCache;
    const r = await this.call('type=account_info&action=get_main_info').catch(() => null);
    if (!r || typeof r !== 'object') return null;
    return (this.accountCache = { status: str(r, 'status') || 'Active', expires: first(r, 'end_date', 'phone', 'expire_billing_date') || 'Unknown', extra: str(r, 'tariff_plan') || `MAC ${this.mac}` });
  }

  absUrl(u) {
    if (!u) return null;
    if (/^http/i.test(u)) return u;
    const root = (/^(https?:\/\/[^/]+)/.exec(this.endpoint) || [])[0];
    return root ? root + (u.startsWith('/') ? u : '/' + u) : null;
  }

  genreList(r, type, prefix) {
    const arr = Array.isArray(r) ? r : r && Array.isArray(r.data) ? r.data : [];
    return arr.map((o) => ({ id: str(o, 'id'), name: first(o, 'title', 'name'), type })).filter((c) => c.id && c.id !== '*').map((c) => ({ id: prefix + c.id, name: c.name || c.id, type }));
  }
  async loadVodCats() { return this.genreList(await this.call('type=vod&action=get_categories'), MOVIE, 'vod:'); }

  async categories(type) {
    if (type === LIVE) return this.genreList(await this.call('type=itv&action=get_genres'), LIVE, '');
    const vod = await this.vodCatsOnce();
    if (type === MOVIE) { const m = vod.filter((c) => !isSeriesCategoryName(c.name)); return m.length ? m : vod; }
    const s = await this.call('type=series&action=get_categories').then((r) => this.genreList(r, SERIES, 'series:')).catch(() => []);
    this.hasSeriesModule = s.length > 0;
    return [...s, ...vod.filter((c) => isSeriesCategoryName(c.name)).map((c) => ({ ...c, type: SERIES }))];
  }

  async loadChannels() {
    const r = await this.call('type=itv&action=get_all_channels');
    const arr = Array.isArray(r) ? r : r && Array.isArray(r.data) ? r.data : [];
    const out = [];
    for (const o of arr) {
      const id = str(o, 'id'); if (!id) continue;
      out.push(item({ id, name: str(o, 'name') || id, type: LIVE, categoryId: str(o, 'tv_genre_id') || '', poster: this.absUrl(str(o, 'logo')), url: str(o, 'cmd'), number: num(str(o, 'number')) || 0, epgId: str(o, 'xmltv_id') }));
    }
    out.sort((a, b) => (a.number > 0 ? a.number : 1e9) - (b.number > 0 ? b.number : 1e9));
    return out;
  }
  async allLive() { return this.channelsOnce(); }

  async items(type, cat, page) {
    if (type === LIVE) return { items: page === 1 ? (await this.channelsOnce()).filter((c) => c.categoryId === cat) : [], hasMore: false };
    const module = cat.split(':')[0], c = cat.slice(cat.indexOf(':') + 1);
    const r = await this.call(`type=${module}&action=get_ordered_list&category=${enc(c)}&genre=*&p=${page}&sortby=added&fav=0&hd=0&not_ended=0&abc=*&years=*`);
    if (!r || typeof r !== 'object' || Array.isArray(r)) return { items: [], hasMore: false };
    const list = this.parseVodList(r, module, cat, module === 'series' ? SERIES : null);
    const total = num(str(r, 'total_items')) || 0;
    const per = num(str(r, 'max_page_items')) || 14;
    return { items: list, hasMore: page * per < total };
  }

  parseVodList(r, module, categoryId, forceType) {
    const arr = Array.isArray(r.data) ? r.data : [];
    const out = [];
    for (const o of arr) {
      const id = str(o, 'id'); if (!id) continue;
      const isSeries = forceType === SERIES || str(o, 'is_series') === '1' || str(o, 'is_series') === 'true';
      const rating = first(o, 'rating_imdb', 'rating_kinopoisk');
      const time = str(o, 'time');
      const eps = Array.isArray(o.series) && o.series.length ? o.series : null;
      out.push(item({
        id, name: first(o, 'name', 'o_name') || id, type: isSeries ? SERIES : MOVIE, categoryId,
        poster: this.absUrl(first(o, 'screenshot_uri', 'cover_big', 'pic')), plot: str(o, 'description'), year: (str(o, 'year') || '').slice(0, 4) || null,
        rating: rating && rating !== '0' && rating !== 'N/A' ? rating : null, genre: str(o, 'genres_str'), cast: str(o, 'actors'), director: str(o, 'director'),
        duration: time && time !== '0' ? `${time} min` : null, url: str(o, 'cmd'), extra: eps ? `${module};eps=${eps.join(',')}` : module,
      }));
    }
    return out;
  }

  async search(query) {
    const q = enc(query);
    const [live, vod, series] = await Promise.all([
      this.channelsOnce().then((c) => c.filter((i) => searchMatch(i.name, query))).catch(() => []),
      this.call(`type=vod&action=get_ordered_list&search=${q}&p=1&sortby=added`).then((r) => (r && !Array.isArray(r) ? this.parseVodList(r, 'vod', 'vod:*', null) : [])).catch(() => []),
      this.hasSeriesModule === false ? [] : this.call(`type=series&action=get_ordered_list&search=${q}&p=1&sortby=added`).then((r) => (r && !Array.isArray(r) ? this.parseVodList(r, 'series', 'series:*', SERIES) : [])).catch(() => []),
    ]);
    const seen = new Set();
    return [...vod, ...series, ...live].filter((i) => { const k = i.type + i.id; return seen.has(k) ? false : seen.add(k); });
  }

  async orderedList(module, movieId, seasonId, debug, episodeId = '0') {
    const out = [];
    for (let page = 1; page <= 15; page++) {
      let r = null;
      try { r = await this.call(`type=${module}&action=get_ordered_list&movie_id=${enc(movieId)}&season_id=${enc(seasonId)}&episode_id=${enc(episodeId)}&p=${page}&sortby=added`); }
      catch (e) { debug.push(`[${module} s=${seasonId}] error ${e.message}`); }
      if (page === 1) debug.push(`[${module} s=${seasonId}] ${(r ? JSON.stringify(r) : this.lastBody).slice(0, 350)}`);
      const obj = r && !Array.isArray(r) ? r : null;
      const arr = obj ? obj.data : Array.isArray(r) ? r : null;
      if (!Array.isArray(arr)) break;
      out.push(...arr.filter((x) => x && typeof x === 'object'));
      const total = num(str(obj || {}, 'total_items')) || 0;
      const per = num(str(obj || {}, 'max_page_items')) || 14;
      if (!arr.length || page * per >= total) break;
    }
    return out;
  }

  async seriesInfo(it) {
    const extra = it.extra || 'vod';
    const module = extra.split(';')[0] || 'vod';
    const inlineEps = (extra.includes(';eps=') ? extra.split(';eps=')[1] : '').split(',').map((x) => num(x.trim())).filter((x) => x != null);
    const debug = [];
    const eps = [];
    const collect = async (mod) => {
      const level1 = await this.orderedList(mod, it.id, '0', debug);
      for (let idx = 0; idx < level1.length; idx++) {
        const s = level1[idx];
        const sid = str(s, 'id');
        const seasonNum = num(str(s, 'season_number')) ?? numberIn(first(s, 'name', 'o_name')) ?? idx + 1;
        const seriesArr = Array.isArray(s.series) ? s.series : null;
        const isEpisode = s.is_episode === true || s.series_number !== undefined || str(s, 'is_episode') === '1';
        const cmd = str(s, 'cmd');
        if (seriesArr && seriesArr.length && cmd) {
          seriesArr.forEach((x, i) => {
            const n = num(x) ?? i + 1;
            eps.push({ id: `${sid ?? seasonNum}_${n}`, seriesId: it.id, season: seasonNum, episode: n, title: `Episode ${n}`, image: this.absUrl(str(s, 'screenshot_uri')) || it.poster, url: `${mod}|${cmd}|${n}`, plot: null, ext: null, durationSecs: 0 });
          });
        } else if (isEpisode && cmd) {
          const n = num(str(s, 'series_number')) ?? numberIn(str(s, 'name')) ?? eps.length + 1;
          eps.push({ id: sid ?? `e${n}`, seriesId: it.id, season: num(str(s, 'season_number')) ?? 1, episode: n, title: first(s, 'name', 'o_name') || `Episode ${n}`, plot: str(s, 'description'), image: this.absUrl(str(s, 'screenshot_uri')) || it.poster, url: `${mod}|${cmd}|${str(s, 'series_number') ?? ''}`, ext: null, durationSecs: 0 });
        } else if (sid != null) {
          const level2 = await this.orderedList(mod, it.id, sid, debug);
          for (const e of level2) {
            const epId = str(e, 'id');
            // Ministra 5.x: episodes carry no cmd; the playable file is one level deeper (fetched at play time).
            const ecmd = str(e, 'cmd') || (epId ? `@ep:${it.id}~${sid}~${epId}` : null);
            if (!ecmd) continue;
            const n = num(str(e, 'series_number')) ?? numberIn(str(e, 'name')) ?? eps.filter((x) => x.season === seasonNum).length + 1;
            eps.push({ id: epId ?? `${sid}_${n}`, seriesId: it.id, season: seasonNum, episode: n, title: first(e, 'series_name', 'name', 'o_name') || `Episode ${n}`, plot: first(e, 'description', 'series_description'), image: this.absUrl(first(e, 'screenshot_uri', 'cover_big')) || it.poster, url: `${mod}|${ecmd}|${str(e, 'series_number') ?? ''}`, ext: null, durationSecs: (num(str(e, 'time')) || 0) * 60 });
          }
          if (!level2.length && cmd) eps.push({ id: sid, seriesId: it.id, season: seasonNum, episode: 1, title: str(s, 'name') || `Season ${seasonNum}`, image: it.poster, url: `${mod}|${cmd}|`, plot: null, ext: null, durationSecs: 0 });
        }
      }
    };
    await collect(module);
    if (!eps.length) await collect(module === 'series' ? 'vod' : 'series');
    if (!eps.length && inlineEps.length && it.url) {
      inlineEps.forEach((n) => eps.push({ id: `${it.id}_${n}`, seriesId: it.id, season: 1, episode: n, title: `Episode ${n}`, image: it.poster, url: `${module}|${it.url}|${n}`, plot: null, ext: null, durationSecs: 0 }));
    }
    if (!eps.length) throw new ProviderError(`No episodes found for ${it.name}.\n\nPortal replied:\n${debug.join('\n').slice(0, 900)}`);
    const seen = new Set();
    const uniq = eps.filter((e) => { const k = `${e.season}:${e.episode}:${e.url}`; return seen.has(k) ? false : seen.add(k); });
    uniq.sort((a, b) => a.season - b.season || a.episode - b.episode);
    return groupSeasons(it, uniq);
  }

  stripCmd(cmd) { return cmd.trim().replace(/^(ffmpeg|ffrt|ffrt2|ffrt3|auto)\s+/, '').trim(); }

  async createLink(type, cmd, series) {
    const r = await this.call(`type=${type}&action=create_link&cmd=${enc(cmd)}&series=${enc(series)}&forced_storage=undefined&disable_ad=0&download=0&force_ch_link_check=0`);
    const link = r && typeof r === 'object' ? str(r, 'cmd') : typeof r === 'string' ? r : null;
    const u = link ? this.stripCmd(link) : null;
    if (!u || !/^(http|rtmp|rtsp|udp)/.test(u)) {
      const fb = this.stripCmd(cmd);
      if (fb.startsWith('http') && !fb.includes('localhost')) return fb;
      throw new ProviderError("The portal didn't return a playable link.");
    }
    return u;
  }

  async resolve(it, ep) {
    if (ep) {
      const parts = (ep.url || '').split('|');
      const module = (parts[0] || '').split(';')[0] || 'vod';
      let cmd = parts[1];
      const series = parts[2] || '';
      if (!cmd) throw new ProviderError('Episode has no link');
      if (cmd.startsWith('@ep:')) {
        const [movieId = '', seasonId = '0', epId = '0'] = cmd.slice(4).split('~');
        const dbg = [];
        const files = await this.orderedList(module, movieId, seasonId, dbg, epId);
        const fileCmd = files.map((f) => str(f, 'cmd')).find(Boolean) || files.map((f) => str(f, 'id')).filter(Boolean).map((id) => `/media/file_${id}.mpg`)[0];
        if (!fileCmd) throw new ProviderError(`The portal didn't return a file for this episode.\n${dbg.join('\n').slice(0, 300)}`);
        try { return await this.createLink(module, fileCmd, ''); } catch { return this.createLink(module, fileCmd, series); }
      }
      try { return await this.createLink(module === 'series' ? 'vod' : module, cmd, series); }
      catch (e) { if (module === 'series') return this.createLink('series', cmd, series); throw e; }
    }
    if (!it.url) throw new ProviderError(`No link for ${it.name}`);
    return this.createLink(it.type === LIVE ? 'itv' : 'vod', it.url, '');
  }

  async epg(ch) {
    const r = await this.call(`type=itv&action=get_short_epg&ch_id=${ch.id}&size=6`).catch(() => null);
    const arr = Array.isArray(r) ? r : r && Array.isArray(r.data) ? r.data : [];
    const now = Date.now();
    const out = [];
    for (const o of arr) {
      const a = num(str(o, 'start_timestamp')), b = num(str(o, 'stop_timestamp'));
      if (a == null || b == null || b * 1000 < now) continue;
      out.push({ title: first(o, 'name', 'title') || '', startMs: a * 1000, endMs: b * 1000, description: str(o, 'descr') });
    }
    return out.sort((x, y) => x.startMs - y.startMs);
  }
  playbackHeaders() { return { 'User-Agent': this.ua }; }
}

export function createProvider(profile, settings, m3uText) {
  if (profile.type === 'M3U') return new M3uProvider(profile, m3uText);
  if (profile.type === 'XTREAM') return new XtreamProvider(profile, settings);
  return new StalkerProvider(profile);
}

export const Keys = {
  movie: (pid, id) => `${pid}|m|${id}`,
  live: (pid, id) => `${pid}|l|${id}`,
  episode: (pid, sid, eid) => `${pid}|e|${sid}|${eid}`,
};
